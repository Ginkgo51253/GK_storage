import Background from './runtime/background' //导入背景图片绘制包
import GameInfo from './runtime/gameinfo' //导入记分包
import Music from './runtime/music' //导入音效文件

const context = canvas.getContext('2d') //获得操作使用的2d画布
const screenWidth = window.innerWidth //获得荧幕宽
const screenHeight = window.innerHeight //获得荧幕高
var point_LU_x, point_LU_y //有效区域左上角绝对坐标
var point_RD_x, point_RD_y //有效区域右下角相对坐标
var color_red, color_blue, color_green //绝大多数色块的颜色
var targetBlock //唯一不同色块序号
var target_LU_x, target_LU_y, target_RD_x, target_RD_y //唯一不同色块区域表示

export default class colormain {
  constructor(that) { //构造器
    //返回主页的调用对象
    this.goback = that
    //展示默认显示
    this.default()
  }

  default () { //游戏初始化与入口
    //移除监听事件
    canvas.removeEventListener('touchstart', this.touchHandler)
    //维护当前requestAnimationFrame的id
    this.aniId = 0
    //初始化游戏维度难度
    this.difficult = 1
    //初始化游戏辨色难度
    this.ultradiff = 1
    //初始化事件绑定辨别参数，默认为未绑定
    this.hasEventBind = false
    //初始化游戏终止参数
    this.gameOver = false
    //初始化计算游戏内有效显示的色块区域
    this.getAvailableSpace(this.difficult)
    //初始化计算一组新的颜色
    this.colorPool()
    //初始化游戏记分为0分
    this.score = 0
    //初始化游戏背景
    this.bg = new Background(context)
    //初始化背景音效对象
    this.music = new Music() 
    this.music.playBgm()
    //初始化游戏信息
    this.gameinfo = new GameInfo()
    //初始化目标块位置
    targetBlock = 0
    this.differentlevel = -1
    //绑定事件循环，初始化状态并开始运行
    this.bindLoop = this.loop.bind(this)
    //如果在画面上存在动画帧，取消它（多个动画帧会导致显示速度过快不符合预取且无法计时计数）
    window.cancelAnimationFrame(this.aniId);
    //但由于main对象中的逻辑会产生变更，因此在之后的loop函数也对其进行了请求，并绑定了参数
    //使用新产生的main对象和新产生的canvas在浏览器中进行渲染
    this.aniId = window.requestAnimationFrame(this.bindLoop, canvas)
  }
  /**
   * 绘制一个矩形
   * 输入参数分别为指定的位置和指定的颜色
   */
  drawRect(a, b, c, d, red, green, blue) {
    context.fillStyle = 'rgb(' + red + ',' + green + ',' + blue + ')' // 设置矩形颜色
    context.fillRect(a, b, c, d) // 矩形左上角顶点为(a,b)，右下角相对左上角顶点为(c,d)
  }

  /**
   * 绘制色块不同的目标矩形
   * 输入参数分别为指定的位置、指定的颜色和辨色难度
   */
  drawTargetRect(a, b, c, d, red, green, blue, ultradiff) {
    var alpha = 1 - 12 / (ultradiff + 35)
    context.fillStyle = 'rgba(' + red + ',' + green + ',' + blue + ',' + alpha + ')' //设置具有透明度的矩形
    context.fillRect(a, b, c, d) //矩形左上角顶点为(a,b)，右下角相对左上角顶点为(c,d)
  }

  /**
   * 绘制所有矩形
   * 输入参数分别为阶数难度，有效范围的参数
   */
  drawAllRect(difficult, point_LU_x, point_LU_y, point_RD_x, point_RD_y) {
    var unitx = point_RD_x / (difficult * 20 + difficult - 1)
    var unity = point_RD_y / (difficult * 20 + difficult - 1)
    var aim = 0
    for (var i = 0; i < difficult; i++) {
      for (var j = 0; j < difficult; j++) {
        if (targetBlock == aim) {
          this.drawTargetRect(
            point_LU_x + unitx * 21 * j, point_LU_y + unity * 21 * i, unitx * 20, unity * 20,
            color_red, color_green, color_blue,
            this.ultradiff)
          target_LU_x = point_LU_x + unitx * 21 * j //将找到的目标矩形顺便计算其参数
          target_LU_y = point_LU_y + unity * 21 * i
          target_RD_x = unitx * 20
          target_RD_y = unity * 20
        } else {
          this.drawRect(
            point_LU_x + unitx * 21 * j, point_LU_y + unity * 21 * i, unitx * 20, unity * 20,
            color_red, color_green, color_blue)
        }
        aim++
      }
    }
  }

  /**
   * 色池，用于决定当前关使用的基准颜色
   */
  colorPool() {
    var randnum = Math.floor(Math.random() * 10)
    while(this.differentlevel==randnum){
      randnum = Math.floor(Math.random() * 10)
    }
    this.differentlevel=randnum
    switch (randnum) {
      case 0: //调色：紫色
        color_red = 169;
        color_green = 150;
        color_blue = 243;
        break
      case 1: //调色：橙色
        color_red = 255;
        color_green = 140;
        color_blue = 68;
        break
      case 2: //调色：红色
        color_red = 255;
        color_green = 51;
        color_blue = 30;
        break
      case 3: //调色：金色
        color_red = 255;
        color_green = 215;
        color_blue = 0;
        break
      case 4: //调色：绿色
        color_red = 0;
        color_green = 209;
        color_blue = 0;
        break
      case 5: //调色：蓝色
        color_red = 0;
        color_green = 152;
        color_blue = 255;
        break
      case 6: //调色：青色
        color_red = 30;
        color_green = 200;
        color_blue = 200;
        break
      case 7: //调色：褐色
        color_red = 150;
        color_green = 75;
        color_blue = 0;
        break
      case 8: //调色：珊瑚红
        color_red = 255;
        color_green = 127;
        color_blue = 80;
        break
      case 9: //调色：安卓绿
        color_red = 164;
        color_green = 198;
        color_blue = 57;
        break
      default: //默认调色：黑色
        color_red = 0;
        color_green = 0;
        color_blue = 0
    }
  }

  /**
   * 获得一个当前难度下新目标的编号
   * @param {*难度，数值在1-10之间}} difficult 
   */
  getNewTarget(difficult) {
    targetBlock = Math.floor(Math.random() * difficult * difficult)
  }
  /**
   * 计算游戏内显示色块的有效区域
   * @param {*难度，数值在1-10之间} difficult 
   */
  getAvailableSpace(difficult) {
    point_LU_x = (0.618 * screenWidth) / (difficult + 1.236)
    point_LU_y = (screenHeight - (difficult * screenWidth) / (difficult + 1.236)) / 2
    point_RD_x = difficult * screenWidth / (difficult + 1.236)
    point_RD_y = difficult * screenWidth / (difficult + 1.236)
  }

  /**
   * 游戏进行的按钮逻辑
   */
  touchEventHandler(e) {
    //e为输入对象，即一个系统响应
    e.preventDefault()
    //从该响应中获取玩家触碰的位置
    let x = e.touches[0].clientX
    let y = e.touches[0].clientY
    //如果触碰的位置为目标位置内就进入下一关
    if (x >= target_LU_x &&
      x <= target_LU_x + target_RD_x &&
      y >= target_LU_y &&
      y <= target_LU_y + target_RD_y) {
      this.eventBtn1Touched()
      this.music.playCorrect()
    }
    //如果碰触的位置为错误位置就游戏结束
    if ((x >= point_LU_x && x <= point_LU_x + point_RD_x &&
        y >= point_LU_y && y <= point_LU_y + point_RD_y) &&
      !(x >= target_LU_x && x <= target_LU_x + target_RD_x &&
        y >= target_LU_y && y <= target_LU_y + target_RD_y)) {
      this.eventBtn2Touched()
      this.music.pauseBgm()
      this.music.playGameOver()
    }
  }
  /**
   * 游戏结束的按钮逻辑
   */
  touchGameInfoHandler(e) {
    //e为输入对象，即一个系统响应
    e.preventDefault()
    //从该响应中获取玩家触碰的位置
    let x = e.touches[0].clientX
    let y = e.touches[0].clientY
    //如果触碰的位置为按钮响应位置内就返回首页
    if (x >= screenWidth / 2 - 60 &&
      x <= screenWidth / 2 + 60 &&
      y >= screenHeight / 2 + 40 &&
      y <= screenHeight / 2 + 80)
      this.eventEnder()
  }

  /**
   * 事件终结者
   * 取消当前场景中的监听
   * 清除当前场景中播放的动画
   * 调用主界面函数（相当于回到主页）
   */
  eventEnder() {
    canvas.removeEventListener('touchstart', this.touchHandler)
    window.cancelAnimationFrame(this.aniId);
    this.goback.default()
  }

  /**
   * 移除场景函数：
   * 在进入小游戏之前消除侦听动作，
   * 同时消除动画帧为接下来的小游戏动画帧做准备
   */
  removeScene() {
    canvas.removeEventListener('touchstart', this.touchHandler)
    window.cancelAnimationFrame(this.aniId);
  }
  /**
   * 按正确位置的响应
   */
  eventBtn1Touched() {
    if (this.difficult * this.difficult == this.ultradiff && this.difficult < 10) {
      this.difficult++
    } else if (this.difficult >= 10) {
      this.difficult = 10
    }
    this.ultradiff++
    this.score++
    this.colorPool()
    this.getAvailableSpace(this.difficult)
    //targetBlock=0//测试用左上角方块为正确目标
    targetBlock = Math.floor(Math.random() * this.difficult * this.difficult)
  }
  /**
   * 按错误位置的响应
   */
  eventBtn2Touched() {
    canvas.removeEventListener('touchstart', this.touchHandler)
    if (!this.gameOver) {
      this.gameOver = true
      this.touchHandler = this.touchGameInfoHandler.bind(this)
      canvas.addEventListener('touchstart', this.touchHandler)
    }
  }

  /**
   * 绘制方法：
   * 用来描绘背景的主要方法
   */
  render() {
    //清除画布的所有内容
    context.clearRect(0, 0, canvas.width, canvas.height)
    //调整背景类的渲染函数，在context上绘制背景
    this.bg.render(context)
    //绘制所有矩形
    this.drawAllRect(this.difficult, point_LU_x, point_LU_y, point_RD_x, point_RD_y)
    //更新分数记分显示
    this.gameinfo.renderGameScore(context, this.score)
    //启用游戏中的动作绑定，用于全局侦听手指触碰屏幕的动作
    if (!this.hasEventBind) {
      this.hasEventBind = true
      this.touchHandler = this.touchEventHandler.bind(this)
      canvas.addEventListener('touchstart', this.touchHandler)
    }
    //启用游戏结束时的动作绑定，监听返回主页的动作
    if (this.gameOver) {
      this.gameinfo.renderGameOver(context, this.score)
    }
  }

  /**
   * 循环函数：
   * 相当于递归运行了自己，
   * 但每次运行都等待了荧幕的刷新间隔
   */
  loop() {
    //更新游戏显示（渲染画面）
    this.render()
    //调用并准备下一帧的显示
    this.aniId = window.requestAnimationFrame(this.bindLoop, canvas)
  }
}