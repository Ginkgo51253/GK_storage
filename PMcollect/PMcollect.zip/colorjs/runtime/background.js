import Sprite from '../base/sprite'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

const BG_IMG_SRC = 'images/colorbg.png'
const BG_WIDTH = 10
const BG_HEIGHT = 10

/**
 * 游戏背景类
 * 提供update和render函数实现无限滚动的背景功能
 */
export default class BackGround extends Sprite {
  //构造器，设置图片背景的精灵，同时准备将图片绘制在荧幕上
  constructor(ctx) {
    super(BG_IMG_SRC, BG_WIDTH, BG_HEIGHT)
    this.render(ctx)
  }
  //背景图片绘制函数
  render(ctx) {
    ctx.drawImage(
      this.img,
      0, 0, this.width, this.height,
      0, 0, screenWidth, screenHeight
    )
  }
}