let instance

/**
 * 统一的音效管理器
 */
export default class Music {
  constructor() {
    if (instance)
      return instance
    instance = this

    this.bgmAudio = new Audio()
    this.bgmAudio.loop = true
    this.bgmAudio.src = 'audio/behaved.ogg'

    this.correctAudio = new Audio()
    this.correctAudio.src = 'audio/colorcorrect.ogg'
    this.correctAudio.preload = "auto"

    this.gameOverAudio = new Audio()
    this.gameOverAudio.src = 'audio/gameover.ogg'
    this.gameOverAudio.preload = "auto"
  }
  playBgm() {
    this.bgmAudio.currentTime = 0
    this.bgmAudio.play()
  }
  pauseBgm() {
    this.bgmAudio.pause()
  }
  playCorrect() {
    this.correctAudio.currentTime = 0
    this.correctAudio.play()
  }
  playGameOver() {
    this.gameOverAudio.play()
  }
}