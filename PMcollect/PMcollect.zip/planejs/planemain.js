import Player from './player/index'
import Enemy from './npc/enemy'
import BackGround from './runtime/background'
import GameInfo from './runtime/gameinfo'
import Music from './runtime/music'
import DataBus from './databus'

//在函数调用之前生成了一个2d画布
let ctx = canvas.getContext('2d')
//生成了游戏的数据总线，该总线对象独一无二
let databus = new DataBus()

/**
 * 飞机大战游戏主对象：
 * 它的实例化会使小游戏开始运行
 */
export default class planemain {
  /**
   * 构造器：
   * 用来初始化小游戏
   * @param {*主页对象，用来返回主页} that 
   */
  constructor(that) {
    // 维护当前requestAnimationFrame的id
    this.aniId = 0
    this.goback = that
    this.restart()
  }

  /**
   * 用于重新生成一个界面
   */
  restart() {
    //首先重置了数据总线的各个参数
    databus.reset()
    //移除监听事件
    canvas.removeEventListener(
      'touchstart',
      this.touchHandler
    )
    //初始化背景、玩家、游戏信息、游戏音乐对象
    this.bg = new BackGround(ctx)
    this.player = new Player()
    this.gameinfo = new GameInfo()
    this.music = new Music()
    this.music.playBgm()
    //绑定事件循环，初始化状态并开始运行
    this.bindLoop = this.loop.bind(this)
    this.hasEventBind = false
    //清除上一局的动画
    //该例中只是用了初始化的main对象更新loop函数，并将其作为刷新内容
    window.cancelAnimationFrame(this.aniId);
    //但由于main对象中的逻辑会产生变更，因此在之后的loop函数也对其进行了请求，并绑定了参数
    //使用新产生的main对象和新产生的canvas在浏览器中进行渲染
    this.aniId = window.requestAnimationFrame(this.bindLoop, canvas)
    //在实际测试当中，该刷新为每秒更新60帧
  }

  /**
   * 随着帧数变化的敌机生成逻辑
   * 帧数取模定义成生成的频率
   */
  enemyGenerate() {
    //databus.frame为游戏的帧计数器，每刷新一定次数都会生成一个敌人对象
    if (databus.frame % 30 === 0) {
      let enemy = databus.pool.getItemByClass('enemy', Enemy)
      //设定敌人初始速度
      enemy.init(7)
      //敌机生成完毕，将敌机添加到敌机对象组中
      databus.enemys.push(enemy)
    }
  }

  // 全局碰撞检测
  collisionDetection() {
    let that = this
    //判断子弹撞上敌机
    databus.bullets.forEach((bullet) => {
      //当子弹飞行时遍历敌机对象组
      for (let i = 0, il = databus.enemys.length; i < il; i++) {
        let enemy = databus.enemys[i]
        //当敌机不在爆炸状态且子弹判定与敌机判定相合，断定为子弹命中
        if (!enemy.isPlaying && enemy.isCollideWith(bullet)) {
          enemy.playAnimation()
          //当事件被触发则播放对应音效
          that.music.playExplosion()
          //将子弹设为不可见
          bullet.visible = false
          //数据总线计分加一
          databus.score += 1
          //防止多重判定，跳出循环
          break
        }
      }
    })
    //判断自机撞上敌机
    for (let i = 0, il = databus.enemys.length; i < il; i++) {
      //遍历敌机对象组
      let enemy = databus.enemys[i]
      //如果自机判定与敌机判定想和，断定自机相撞
      if (this.player.isCollideWith(enemy)) {
        //在游戏数据总线中设置游戏结束
        databus.gameOver = true
        //取消在玩家身上的各种监听事件
        this.player.removeEvent()
        //取消bgm，并播放游戏结束音效
        this.music.pauseBgm()
        this.music.playGameOver()
        break
      }
    }
  }

  // 游戏结束后的触摸事件处理逻辑
  /**
   * 用于在游戏结束后判断是否重启游戏的函数
   */
  touchEventHandler(e) {
    //e为输入对象，即一个系统响应
    e.preventDefault()
    //从该响应中获取玩家触碰的位置
    let x = e.touches[0].clientX
    let y = e.touches[0].clientY
    //设置按钮实际响应位置
    let area = this.gameinfo.btnArea
    //如果触碰的位置为按钮响应位置内就重置游戏
    if (x >= area.startX &&
      x <= area.endX &&
      y >= area.startY &&
      y <= area.endY)
      this.eventEnder()
  }

  /**
   * 事件终结者
   * 取消当前场景中的监听
   * 清除当前场景中播放的动画
   * 调用主界面函数（相当于回到主页）
   */
  eventEnder() {
    canvas.removeEventListener(
      'touchstart',
      this.touchHandler
    )
    window.cancelAnimationFrame(this.aniId);
    this.goback.default()
  }

  /**
   * canvas重绘函数
   * 每一帧重新绘制所有的需要展示的元素
   * 渲染函数，用于渲染场景，用于每次修改内容后重新渲染场景内容（每一帧调用）
   * 
   */
  render() {
    //清除画布的所有内容
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    //调整背景类的渲染函数，在ctx上绘制背景
    this.bg.render(ctx)
    //concat为js的函数，将数组连接
    //此处将bullet数组和enemys数组连接，然后将每个数组元素绘制在荧幕上
    databus.bullets
      .concat(databus.enemys)
      .forEach((item) => {
        item.drawToCanvas(ctx)
      })
    //将玩家绘制在荧幕上
    this.player.drawToCanvas(ctx)
    //将所有未播放的动画播放
    databus.animations.forEach((ani) => {
      if (ani.isPlaying) {
        ani.aniRender(ctx)
      }
    })
    if (this.player.isAutoPlay) {
      this.bg.isAIPlay = true
    } else {
      this.bg.isAIPlay = false
    }
    this.bg.drawAIButton(ctx)
    //更新分数记分显示
    this.gameinfo.renderGameScore(ctx, databus.score)
    // 游戏结束停止帧循环
    if (databus.gameOver) {
      this.gameinfo.renderGameOver(ctx, databus.score)
      //判定绑定事件，如果没有事情绑定，则将触摸事件绑定
      if (!this.hasEventBind) {
        this.hasEventBind = true
        this.touchHandler = this.touchEventHandler.bind(this)
        canvas.addEventListener('touchstart', this.touchHandler)
      }
    }
  }

  // 游戏逻辑更新主函数
  update() {
    //如果游戏已经结束，就不必再次更新
    if (databus.gameOver)
      return;
    //如果游戏还在继续，则需要更新以下内容
    //背景更新
    this.bg.update()
    //子弹、敌人的位置更新
    databus.bullets
      .concat(databus.enemys)
      .forEach((item) => {
        item.update()
      })
    //敌人的生成
    this.enemyGenerate()
    //全局碰撞的检查
    this.collisionDetection()
    //子弹的更新以及子弹音效的调用
    if (databus.frame % 25 === 0) {
      this.player.shoot()
      this.music.playShoot()
    }
    this.player.autoPlay()
  }

  // 实现游戏帧循环
  loop() {
    //游戏帧计数器加一
    databus.frame++
    //更新游戏逻辑状态
    this.update()
    //更新游戏显示（渲染画面）
    this.render()
    //调用并准备下一帧的显示
    this.aniId = window.requestAnimationFrame(
      this.bindLoop,
      canvas
    )
  }
}