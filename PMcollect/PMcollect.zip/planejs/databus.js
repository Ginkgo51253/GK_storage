import Pool from './base/pool'

/**
 * 该对象用于承载该文件中惟一的databus类，实现单例模式
 * 单例模式是一种设计模式，保证全局仅有一个该类的对象，这样能在该demo中保证全局数据的一致性
 * let创建的对象为当前代码块使用的常量
 */
let instance

/**
 * 全局状态管理器
 */
export default class DataBus {
  /**
   * 构造器，如果instance不存在就将将这个类作为对象赋值给instance
   * 但是如果instance已经存在就返回instance本身
   * 即类对象DataBus独一无二
   */
  constructor() {
    if (instance)
      return instance
    instance = this
    this.pool = new Pool()
    this.reset()
  }

  /**
   * 设置游戏的重启状态
   */
  reset() {
    this.frame = 0
    this.score = 0
    this.bullets = []
    this.enemys = []
    this.animations = []
    this.gameOver = false
  }

  /**
   * 回收敌人，进入对象池
   * 此后不进入帧循环
   * 获取enemys数组第一个元素
   * 将其设为不可见
   * 然后将其移入到名称为enemy的对象池中
   */
  removeEnemey(enemy) {
    let temp = this.enemys.shift()
    temp.visible = false
    this.pool.recover('enemy', enemy)
  }

  /**
   * 回收子弹，进入对象池
   * 此后不进入帧循环
   * 方法与移除敌机相同
   */
  removeBullets(bullet) {
    let temp = this.bullets.shift()
    temp.visible = false
    this.pool.recover('bullet', bullet)
  }
}