import Sprite from '../base/sprite'
import DataBus from '../databus'

//导入子弹图片，子弹高度和宽度
const BULLET_IMG_SRC = 'images/plane_bullet.png'
const BULLET_WIDTH = 16
const BULLET_HEIGHT = 30

//创建symbol常量
const __ = {
  speed: Symbol('speed')
}
//创建databus对象
let databus = new DataBus()

/**
 * 子弹类，继承于精灵类
 */
export default class Bullet extends Sprite {
  //构造器，用于设置子弹的图片，宽度和高度
  constructor() {
    super(BULLET_IMG_SRC, BULLET_WIDTH, BULLET_HEIGHT)
  }

  //初始化子弹的位置和速度
  init(x, y, speed) {
    //设置子弹的位置
    this.x = x
    this.y = y
    //设置子弹的速度
    this[__.speed] = speed
    //设置子弹可见
    this.visible = true
  }

  // 每一帧更新子弹位置
  update() {
    this.y -= this[__.speed]

    // 超出屏幕外回收自身
    if (this.y < -this.height)
      databus.removeBullets(this)
  }
}