import Sprite from '../base/sprite'
import Bullet from './bullet'
import DataBus from '../databus'

//利用系统函数获得荧幕的宽度和高度
const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

// 导入玩家图片，设置玩家宽度和高度
const PLAYER_IMG_SRC = 'images/plane_hero.png'
const PLAYER_WIDTH = 60
const PLAYER_HEIGHT = 60

//创建databus
let databus = new DataBus()

/**
 * 玩家类，继承于精灵类
 */
export default class Player extends Sprite {
  //构造器，初始化玩家图片，宽度和高度
  constructor() {
    super(PLAYER_IMG_SRC, PLAYER_WIDTH, PLAYER_HEIGHT)

    // 玩家默认处于屏幕底部居中位置（设定的位置仍然是图片的左上角）
    this.x = screenWidth / 2 - this.width / 2
    this.y = screenHeight - this.height - 30

    // 用于在手指移动的时候标识手指是否已经在飞机上了
    this.touched = false
    // 用于检定是否自动驾驶
    this.isAutoPlay = false
    // 设置子弹数组？
    //该对象没有找到使用位置
    this.bullets = []
    // 初始化事件监听
    this.initEvent()
  }

  /**
   * 当手指触摸屏幕的时候
   * 判断手指是否在飞机上
   * @param {Number} x: 手指的X轴坐标
   * @param {Number} y: 手指的Y轴坐标
   * @return {Boolean}: 用于标识手指是否在飞机上的布尔值
   */
  checkIsFingerOnAir(x, y) {
    //该参数设定用户手指对飞机控制范围
    const deviation = 30
    //判断手指触碰的位置是否在合理范围内
    return !!(x >= this.x - deviation &&
      y >= this.y - deviation &&
      x <= this.x + this.width + deviation &&
      y <= this.y + this.height + deviation)
  }

  /**
   * 根据手指的位置设置飞机的位置
   * 保证手指处于飞机中间
   * 同时限定飞机的活动范围限制在屏幕中
   */
  setAirPosAcrossFingerPosZ(x, y) {
    //根据玩家手指合理触碰调整飞机中心位置为玩家手触摸位置
    let disX = x - this.width / 2
    let disY = y - this.height / 2

    //控制飞机模型在荧幕内
    if (disX < 0)
      disX = 0
    else if (disX > screenWidth - this.width)
      disX = screenWidth - this.width
    if (disY <= 0)
      disY = 0
    else if (disY > screenHeight - this.height)
      disY = screenHeight - this.height
    this.x = disX
    this.y = disY
  }

  /**
   * 监听事件
   * 玩家响应手指的触摸事件
   * 改变战机的位置
   */
  initEvent() {
    //在画布上绑定一个监听事件，当玩家开始触碰荧幕时启动函数
    //该函数保证了玩家首次触碰到飞机时将飞机中心设置为用户手指触碰处
    this.touchstartHandler = this.touchstartEventHandler.bind(this)
    canvas.addEventListener('touchstart', this.touchstartHandler)
    //在画布上绑定一个监听事件，当玩家用手指在荧幕上移动时启动函数
    //该函数保证了飞机在移动过程中中心始终为玩家手指点击处
    this.moveHandler = this.moveEventHandler.bind(this)
    canvas.addEventListener('touchmove', this.moveHandler)
    //在画布上设置一个监听事件，当玩家手指不再触碰时启动
    this.touchendHandler = this.touchendEventHandler.bind(this)
    canvas.addEventListener('touchend', this.touchendHandler)
    //在画布上设置一个可让AI自动操控的按钮响应
    this.AIHandler = this.AIEventHandler.bind(this)
    canvas.addEventListener('touchstart', this.AIHandler)
  }

  touchstartEventHandler(e) {
    //先取消事件本身的动作函数
    e.preventDefault()
    //获取用户手指触碰位置
    let x = e.touches[0].clientX
    let y = e.touches[0].clientY
    //当用户手指点击控制飞机的合理范围内
    if (this.checkIsFingerOnAir(x, y)) {
      //设置当前情况为手指触碰
      this.touched = true
      //将飞机中心设置为手指触碰处
      this.setAirPosAcrossFingerPosZ(x, y)
    }
  }

  moveEventHandler(e) {
    e.preventDefault()
    let x = e.touches[0].clientX
    let y = e.touches[0].clientY
    if (this.touched)
      this.setAirPosAcrossFingerPosZ(x, y)
  }

  touchendEventHandler(e) {
    e.preventDefault()
    //将当前情况设置为未触碰
    this.touched = false
  }

  AIEventHandler(e) {
    e.preventDefault()
    let x = e.touches[0].clientX
    let y = e.touches[0].clientY
    if (x > 8 * screenWidth / 10 &&
      x < 9.5 * screenWidth / 10 &&
      y > 2 * screenHeight / 20 &&
      y < 3 * screenHeight / 20) {
      if (this.isAutoPlay) {
        this.isAutoPlay = false
      } else {
        this.isAutoPlay = true
      }
    }
  }
  removeEvent() {
    this.touched = false
    canvas.removeEventListener('touchstart', this.touchstartHandler)
    canvas.removeEventListener('touchmove', this.moveHandler)
    canvas.removeEventListener('touchend', this.touchendHandler)
    canvas.removeEventListener('touchstart', this.AIHandler)
  }

  /**
   * 玩家射击操作
   * 射击时机由外部决定
   */
  shoot() {
    //从对象池取出一个子弹
    let bullet = databus.pool.getItemByClass('bullet', Bullet)
    //子弹初始化，设置出现位置和飞行速度
    bullet.init(
      this.x + this.width / 2 - bullet.width / 2,
      this.y - 5,
      15
    )
    //将子弹添加到databus中
    databus.bullets.push(bullet)
  }

  /**
   * 简易自动控制函数
   */
  autoPlay() {
    if (this.isAutoPlay == false)
      return
    let bottom = screenHeight - this.height - 30
    let targetX = this.x
    if (databus.enemys.length > 0) {
      for (let i = 0; i < databus.enemys.length; i++) {
        if (databus.enemys[i].visible == true && databus.enemys[i].y < this.y - 30) {
          targetX = databus.enemys[i].x
          break
        }
      }
    }
    if (Math.abs(this.x - targetX) > screenWidth / 25) {
      this.x -= (this.x - targetX) / Math.abs(this.x - targetX) * screenWidth / 30
    } else {
      this.x = targetX - 7.5
    }
    if (Math.abs(this.y - bottom) > screenHeight / 70) {
      this.y -= (this.y - bottom) / Math.abs(this.y - bottom) * screenHeight / 80
    } else {
      this.y = bottom
    }
    if (this.x < 0)
      this.x = 0
    if (this.x + PLAYER_WIDTH > screenWidth)
      this.x = screenWidth - PLAYER_WIDTH
  }
}