import Sprite from '../base/sprite'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

const CLOUD1_IMG_SRC = 'images/plane_cloud1.png'
const CLOUD2_IMG_SRC = 'images/plane_cloud2.png'
const CLOUD3_IMG_SRC = 'images/plane_cloud3.png'
const CLOUD_WIDTH = 120
const CLOUD_HEIGHT = 75
const AIPLAY1_IMG_SRC = 'images/plane_AI1.png'
const AIPLAY2_IMG_SRC = 'images/plane_AI2.png'
const AIPLAY_WIDTH = 1.5 * screenWidth / 10
const AIPLAY_HEIGHT = screenHeight / 20

/**
 * 游戏背景类
 * 提供update和render函数实现无限滚动的背景功能
 */
export default class BackGround {
  constructor(ctx) {
    this.cloud1 = new Sprite(CLOUD1_IMG_SRC, CLOUD_WIDTH, CLOUD_HEIGHT, 0, -5 * CLOUD_HEIGHT)
    this.cloud2 = new Sprite(CLOUD2_IMG_SRC, CLOUD_WIDTH, CLOUD_HEIGHT, 0, -3 * CLOUD_HEIGHT)
    this.cloud3 = new Sprite(CLOUD3_IMG_SRC, CLOUD_WIDTH, CLOUD_HEIGHT, 0, -1 * CLOUD_HEIGHT)
    this.ai1 = new Sprite(AIPLAY1_IMG_SRC,
      AIPLAY_WIDTH, AIPLAY_HEIGHT,
      8 * screenWidth / 10, 2 * screenHeight / 20
    )
    this.ai2 = new Sprite(AIPLAY2_IMG_SRC,
      AIPLAY_WIDTH, AIPLAY_HEIGHT,
      8 * screenWidth / 10, 2 * screenHeight / 20
    )
    this.isAIPlay = false
    this.init()
    this.render(ctx)
  }

  init() {
    this.red = 132
    this.green = 217
    this.blue = 255
    this.count = 0
    this.shift = 1
    this.cloud1.x = Math.random() * (screenWidth - CLOUD_WIDTH)
    this.cloud2.x = Math.random() * (screenWidth - CLOUD_WIDTH)
    this.cloud3.x = Math.random() * (screenWidth - CLOUD_WIDTH)
  }

  update() {
    this.count++
    //控制背景的颜色渐变过程
    if (this.count % 18 == 0) {
      if (this.blue + 1 > 255)
        this.shift = 1
      if (this.blue - 1 < 180)
        this.shift = -1
      this.red -= this.shift * 1
      this.green -= this.shift * 2
      this.blue -= this.shift * 1
    }
    //控制3处云的运动
    this.cloud1.y++
    if (this.count % 3 == 0)
      this.cloud2.y++
    if (this.count % 5 == 0)
      this.cloud3.y++
    //控制3处云的数据重置
    if (this.cloud1.y > screenHeight) {
      this.cloud1.y = -5 * CLOUD_HEIGHT
      this.cloud1.x = Math.random() * (screenWidth - CLOUD_WIDTH)
    }
    if (this.cloud2.y > screenHeight) {
      this.cloud2.y = -3 * CLOUD_HEIGHT
      this.cloud2.x = Math.random() * (screenWidth - CLOUD_WIDTH)
    }
    if (this.cloud3.y > screenHeight) {
      this.cloud3.y = -1 * CLOUD_HEIGHT
      this.cloud3.x = Math.random() * (screenWidth - CLOUD_WIDTH)
    }
    if (this.count == 1800)
      this.count = 0
  }

  /**
   * 背景图重绘函数
   * 绘制两张图片，两张图片大小和屏幕一致
   * 第一张漏出高度为top部分，其余的隐藏在屏幕上面
   * 第二张补全除了top高度之外的部分，其余的隐藏在屏幕下面
   */
  render(ctx) {
    ctx.fillStyle = 'rgb(' + this.red + ',' + this.green + ',' + this.blue + ')' // 设置矩形颜色
    ctx.fillRect(0, 0, screenWidth, screenHeight) // 矩形左上角顶点为(a,b)，右下角相对左上角顶点为(c,d)
    this.cloud1.drawToCanvas(ctx)
    this.cloud2.drawToCanvas(ctx)
    this.cloud3.drawToCanvas(ctx)
  }

  drawAIButton(ctx) {
    if (this.isAIPlay) {
      this.ai2.drawToCanvas(ctx)
    } else {
      this.ai1.drawToCanvas(ctx)
    }
  }
}