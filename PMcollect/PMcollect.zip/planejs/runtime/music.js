let instance

/**
 * 统一的音效管理器
 */
export default class Music {
  constructor() {
    if (instance)
      return instance
    instance = this

    this.bgmAudio = new Audio()
    this.bgmAudio.loop = true
    this.bgmAudio.src = 'audio/loopbegin.ogg'

    this.shootAudio = new Audio()
    this.shootAudio.src = 'audio/bulletlaunch.ogg'
    this.shootAudio.volume = 0.5

    this.boomAudio = new Audio()
    this.boomAudio.src = 'audio/enemyboom.ogg'
    this.boomAudio.volume = 0.5

    this.gameOverAudio = new Audio()
    this.gameOverAudio.src = 'audio/gameover.ogg'
  }

  playBgm() {
    this.bgmAudio.currentTime = 0
    this.bgmAudio.play()
  }

  pauseBgm() {
    this.bgmAudio.pause()
  }

  playShoot() {
    this.shootAudio.currentTime = 0
    this.shootAudio.play()
  }

  playExplosion() {
    this.boomAudio.currentTime = 0
    this.boomAudio.play()
  }

  playGameOver() {
    this.gameOverAudio.play()
  }
}