const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

let atlas = new Image()
atlas.src = 'images/Common.png'

/**
 * 游戏信息绘制类
 */
export default class GameInfo {
  /**
   * 绘制玩家得分情况
   * @param {画布对象} ctx 
   * @param {*玩家得分参数} score 
   */
  renderGameScore(ctx, score) {
    ctx.fillStyle = "#ffffff"
    ctx.font = "25px Arial"
    ctx.fillText(
      score,
      10,
      30
    )
  }

  /**
   * 绘制游戏结束后荧幕信息
   * @param {画布对象} ctx 
   * @param {*玩家得分参数} score 
   */
  renderGameOver(ctx, score) {
    ctx.drawImage(
      atlas,
      0, 0, 128, 88,
      screenWidth / 2 - 150,
      screenHeight / 2 - 150,
      300, 300
    )

    ctx.fillStyle = "#ffffff"
    ctx.font = "20px Arial"

    ctx.fillText(
      'Game Over',
      screenWidth / 2 - 55,
      screenHeight / 2 - 105
    )

    ctx.fillText(
      'Scores ' + score,
      screenWidth / 2 - 45,
      screenHeight / 2 - 15
    )

    ctx.drawImage(
      atlas,
      1, 96, 62, 31,
      screenWidth / 2 - 60,
      screenHeight / 2 + 40,
      120, 40
    )

    ctx.fillText(
      'Back',
      screenWidth / 2 - 25,
      screenHeight / 2 + 67
    )

    /**
     * 重新开始按钮区域
     * 方便简易判断按钮点击
     */
    this.btnArea = {
      startX: screenWidth / 2 - 60,
      startY: screenHeight / 2 + 40,
      endX: screenWidth / 2 + 60,
      endY: screenHeight / 2 + 80
    }
  }
}