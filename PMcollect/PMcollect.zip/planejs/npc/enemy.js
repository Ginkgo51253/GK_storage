import Animation from '../base/animation'
import DataBus from '../databus'

//导入敌人图片，敌人高度和宽度
const ENEMY_IMG_SRC = 'images/plane_enemy.png'
const ENEMY_WIDTH = 45
const ENEMY_HEIGHT = 45

//创建symbol常量
const __ = {
  speed: Symbol('speed')
}
//创建databus对象
let databus = new DataBus()
//用于生成一个从start到end之间的随机整数
function rnd(start, end) {
  return Math.floor(Math.random() * (end - start) + start)
}

/**
 * 敌人类，继承与animation类
 */
export default class Enemy extends Animation {
  //构造器，用于设置敌人的图片，大小，以及绑定的动画初始化
  constructor() {
    super(ENEMY_IMG_SRC, ENEMY_WIDTH, ENEMY_HEIGHT)
    this.initExplosionAnimation()
  }

  //初始化敌机速度
  init(speed) {
    //敌机生成的x轴位置为左边界到右边界的随机处
    this.x = rnd(0, window.innerWidth - ENEMY_WIDTH)
    //敌机生成的y轴位置为上边界外一个机身的地方
    this.y = -this.height
    //设置敌机生成时的速度
    this[__.speed] = speed
    //将敌机设置为可见
    this.visible = true
  }

  // 预定义爆炸的帧动画
  initExplosionAnimation() {
    //设定一个数组，用来存放爆炸的每一帧动画
    let frames = []
    //设定动画每帧选取的图片位置和张数
    const EXPLO_IMG_PREFIX = 'images/plane_explosion_'
    const EXPLO_FRAME_COUNT = 19
    //逐帧将图片载入到数组中
    for (let i = 0; i < EXPLO_FRAME_COUNT; i++) {
      frames.push(EXPLO_IMG_PREFIX + (i + 1) + '.png')
    }
    //初始化帧动画
    this.initFrames(frames)
  }

  //更新逻辑位置
  update() {
    this.y += this[__.speed]

    // 如果对象离开画面，回收对象
    if (this.y > window.innerHeight + this.height)
      databus.removeEnemey(this)
  }
}