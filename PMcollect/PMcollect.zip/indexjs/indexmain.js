import Background from './runtime/background' //导入背景图片绘制包
import Music from './runtime/music' //导入背景音乐包
import collectmain from '../collectjs/collectmain' //零花钱大作战（game1）
import colormain from '../colorjs/colormain' //方框游戏（game2）
import planemain from '../planejs/planemain' //样例的打飞机游戏（game3）

const context = canvas.getContext('2d')
const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

/**
 * 主页对象：
 * 它的实例化即游戏的入口
 */
export default class Main {
  constructor() { //构造器
    //维护当前requestAnimationFrame的id
    this.aniId = 0
    //小游戏的对象，如果不新建则默认为null
    this.game1 = null
    this.game2 = null
    this.game3 = null
    this.game4 = null
    //首页展示的默认显示操作
    this.default()
  }
  default () { //建立画布
    this.aniId = 0
    this.bg = new Background(context)
    this.music =new Music()
    this.music.playBgm()
    //绑定事件循环，初始化状态并开始运行
    this.bindLoop = this.loop.bind(this)
    //启用一个动作绑定，用于全局侦听手指触碰屏幕的动作
    this.touchHandler = this.touchEventHandler.bind(this)
    canvas.addEventListener('touchstart', this.touchHandler)
    //如果在画面上存在动画帧，取消它（多个动画帧会导致显示速度过快不符合预取且无法计时计数）
    window.cancelAnimationFrame(this.aniId);
    //但由于main对象中的逻辑会产生变更，因此在之后的loop函数也对其进行了请求，并绑定了参数
    //使用新产生的main对象和新产生的canvas在浏览器中进行渲染
    this.aniId = window.requestAnimationFrame(this.bindLoop, canvas)
  }

  /**
   * 绘制方法：
   * 用来描绘背景的主要方法
   */
  render() {
    //清除画布的所有内容
    context.clearRect(0, 0, canvas.width, canvas.height)
    //调整背景类的渲染函数，在context上绘制背景
    this.bg.update()
    this.bg.render(context)
  }

  /**
   * 动作响应的捕捉函数：
   * 只要捕捉到该系统动作函数便调用，
   * 当用户手指触碰到指定的区域时执行相应的函数
   * @param {*系统提交的一个动作响应} e 
   */
  touchEventHandler(e) {
    //e为输入对象，即一个系统响应
    e.preventDefault()
    //从该响应中获取玩家触碰的位置
    let x = e.touches[0].clientX
    let y = e.touches[0].clientY
    //设置按钮实际响应位置
    let area1 = this.btnArea1
    let area2 = this.btnArea2
    let area3 = this.btnArea3
    let area4 = this.btnArea4
    //如果触碰的位置为按钮响应位置内就重置游戏
    if (x >= area1.startX &&
      x <= area1.endX &&
      y >= area1.startY &&
      y <= area1.endY) {
      this.eventBtn1Touched()
    }
    if (x >= area2.startX &&
      x <= area2.endX &&
      y >= area2.startY &&
      y <= area2.endY) {
      this.eventBtn2Touched()
    }
    if (x >= area3.startX &&
      x <= area3.endX &&
      y >= area3.startY &&
      y <= area3.endY) {
      this.eventBtn3Touched()
    }
    if (x >= area4.startX &&
      x <= area4.endX &&
      y >= area4.startY &&
      y <= area4.endY) {
      this.eventBtn4Touched()
    }
  }
  /**
   * 移除场景函数：
   * 在进入小游戏之前消除侦听动作，
   * 同时消除动画帧为接下来的小游戏动画帧做准备
   */
  removeScene() {
    canvas.removeEventListener(
      'touchstart',
      this.touchHandler
    )
    window.cancelAnimationFrame(this.aniId);
  }
  /**
   * 按钮响应函数
   * 用于执行按钮具体动作
   */
  eventBtn1Touched() {
    this.music.pauseBgm()
    this.removeScene()
    if (this.game1 == null) {
      this.game1 = new collectmain(this)
    } else {
      this.game1.default()
    }
  }
  eventBtn2Touched() {
    this.music.pauseBgm()
    this.removeScene()
    if (this.game2 == null) {
      this.game2 = new colormain(this)
    } else {
      this.game2.default()
    }
  }
  eventBtn3Touched() {
    this.music.pauseBgm()
    this.removeScene()
    if (this.game3 == null) {
      this.game3 = new planemain(this)
    } else {
      this.game3.restart()
    }
  }
  eventBtn4Touched() {
    if (this.bg.messageCount <= 0)
      this.bg.messageCount = 252
  }

  //设置按钮1区域
  btnArea1 = {
    startX: 0.2673 * screenWidth,
    startY: 0.5 * screenHeight - 0.3618 * screenWidth,
    endX: 0.7145 * screenWidth,
    endY: 0.5 * screenHeight - 0.1206 * screenWidth
  }

  //设置按钮2区域
  btnArea2 = {
    startX: 0.2673 * screenWidth,
    startY: 0.5 * screenHeight - 0.1206 * screenWidth,
    endX: 0.7145 * screenWidth,
    endY: 0.5 * screenHeight + 0.1206 * screenWidth
  }

  //设置按钮3区域
  btnArea3 = {
    startX: 0.2673 * screenWidth,
    startY: 0.5 * screenHeight + 0.1206 * screenWidth,
    endX: 0.7145 * screenWidth,
    endY: 0.5 * screenHeight + 0.3618 * screenWidth
  }

  //设置测试用停止按钮区域
  btnArea4 = {
    startX: screenWidth - 36,
    startY: screenHeight - 36,
    endX: screenWidth,
    endY: screenHeight
  }

  /**
   * 循环函数：
   * 相当于递归运行了自己，
   * 但每次运行都等待了荧幕的刷新间隔
   */
  loop() {
    //更新游戏显示（渲染画面）
    this.render()
    //调用并准备下一帧的显示
    this.aniId = window.requestAnimationFrame(this.bindLoop, canvas)
  }
}