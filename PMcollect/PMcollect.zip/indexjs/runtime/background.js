import Sprite from '../base/sprite'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

const STATIC_BG_SRC = 'images/index_static_bg.png'
const STATIC_BG_WIDTH = 400
const STATIC_BG_HEIGHT = 200
const DYNAMIC_BG_SRC = 'images/index_dynamic_bg.png'
const DYNAMIC_BG_WIDTH = 400
const DYNAMIC_BG_HEIGHT = 300
const BUTTON1_SRC = 'images/index_button1.png'
const BUTTON2_SRC = 'images/index_button2.png'
const BUTTON3_SRC = 'images/index_button3.png'
const BUTTON_WIDTH = 200
const BUTTON_HEIGHT = 108
let atlas = new Image()
atlas.src = 'images/Common.png'

/**
 * 游戏背景类
 * 提供update和render函数实现无限滚动的背景功能
 */
export default class BackGround {
  //构造器，设置图片背景的精灵，同时准备将图片绘制在荧幕上
  constructor(ctx) {
    this.staticBG = new Sprite(STATIC_BG_SRC, STATIC_BG_WIDTH, STATIC_BG_HEIGHT)
    this.dynamicBG = new Sprite(DYNAMIC_BG_SRC, DYNAMIC_BG_WIDTH, DYNAMIC_BG_HEIGHT)
    this.button1 = new Sprite(BUTTON1_SRC, BUTTON_WIDTH, BUTTON_HEIGHT)
    this.button2 = new Sprite(BUTTON2_SRC, BUTTON_WIDTH, BUTTON_HEIGHT)
    this.button3 = new Sprite(BUTTON3_SRC, BUTTON_WIDTH, BUTTON_HEIGHT)
    this.init()
    this.render(ctx)
  }

  init() {
    this.numX = Math.floor(screenWidth / DYNAMIC_BG_WIDTH) + 2
    this.numY = Math.floor(screenHeight / DYNAMIC_BG_HEIGHT) + 2
    this.moveX = 0
    this.moveY = 0
    this.count = 0
    this.messageCount = 0
  }
  update() {
    this.count++
    if (this.count >= 18000) {
      this.count = 0
    }
    if (this.count % 2 == 0) {
      this.moveX--
      this.moveY++
      if (this.moveX <= -1 * DYNAMIC_BG_WIDTH)
        this.moveX = 0
      if (this.moveY >= DYNAMIC_BG_HEIGHT)
        this.moveY = 0
    }
    if (this.messageCount > 0)
      this.messageCount--
  }

  //背景图片绘制函数
  render(ctx) {
    for (let i = 0; i < this.numX; i++) {
      for (let j = 0; j < this.numY; j++) {
        ctx.drawImage(
          this.dynamicBG.img,
          0,
          0,
          this.dynamicBG.width,
          this.dynamicBG.height,
          this.moveX + i * this.dynamicBG.width,
          this.moveY + (j - 1) * this.dynamicBG.height,
          400,
          300)
      }
    }
    ctx.drawImage(
      this.staticBG.img,
      0,
      0,
      this.staticBG.width,
      this.staticBG.height,
      0.1 * screenWidth,
      0.1 * screenWidth,
      0.8 * screenWidth,
      0.4 * screenWidth
    )
    ctx.drawImage(
      this.button1.img,
      0,
      0,
      this.button1.width,
      this.button1.height,
      0.2673 * screenWidth,
      0.5 * screenHeight - 0.3618 * screenWidth,
      0.4472 * screenWidth,
      0.2412 * screenWidth
    )
    ctx.drawImage(
      this.button2.img,
      0,
      0,
      this.button2.width,
      this.button2.height,
      0.2673 * screenWidth,
      0.5 * screenHeight - 0.1206 * screenWidth,
      0.4472 * screenWidth,
      0.2412 * screenWidth
    )
    ctx.drawImage(
      this.button3.img,
      0,
      0,
      this.button3.width,
      this.button3.height,
      0.2673 * screenWidth,
      0.5 * screenHeight + 0.1206 * screenWidth,
      0.4472 * screenWidth,
      0.2412 * screenWidth
    )
    ctx.drawImage(
      atlas,
      96, 96, 32, 32,
      screenWidth - 36,
      screenHeight - 36,
      32, 32
    )
    this.drawAuthorMessage(ctx)
  }
  drawAuthorMessage(ctx) {
    if (this.messageCount <= 0) {
      return
    } else if (this.messageCount > 216) {
      ctx.drawImage(
        atlas,
        64, 96, 32, 32,
        screenWidth + this.messageCount - 252,
        screenHeight - 36,
        36, 36
      )
    } else if (this.messageCount <= 32) {
      ctx.drawImage(
        atlas,
        64, 96, 32, 32,
        screenWidth - this.messageCount,
        screenHeight - 36,
        36, 36
      )
    } else {
      ctx.drawImage(
        atlas,
        64, 96, 32, 32,
        screenWidth - 36,
        screenHeight - 36,
        36, 36
      )
    }
  }
}