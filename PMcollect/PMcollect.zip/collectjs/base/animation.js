import DataBus from '../databus'

//画布的基本参数
const screenWidth = window.innerWidth
const screenHeight = window.innerHeight
const BLOCK_WIDTH = screenWidth * 0.95 / 11.236
const BLOCK_HEIGHT = screenWidth * 0.95 / 11.236
//生成一个databus对象
let databus = new DataBus()

//确定一个symbol对象
const __ = {
  timer: Symbol('timer'),
}

/**
 * 简易的帧动画类实现
 */
export default class Animation {
  //构造器，先用图片路径和宽高初始化精灵
  constructor() {
    //基础设置动画的初始情况
    // 当前动画是否播放中
    this.isPlaying = false
    // 动画是否需要循环播放
    this.loop = false
    // 每一帧的时间间隔
    this.interval = 1000 / 60
    // 帧定时器
    this[__.timer] = null
    // 当前播放的帧
    this.index = -1
    // 总帧数
    this.count = 0
    // 帧图片集合
    this.imgList = []
    //预加载帧动画
    this.initExplosionAnimation()
    this.default()
  }

  default (x = 0, y = 0, width = BLOCK_WIDTH, height = BLOCK_HEIGHT) {
    //动画图片的基本参数设置
    this.x = x
    this.y = y
    this.width = BLOCK_WIDTH
    this.height = BLOCK_HEIGHT
  }

  // 预定义爆炸的帧动画
  initExplosionAnimation() {
    //设定一个数组，用来存放爆炸的每一帧动画
    let frames = []
    //设定动画每帧选取的图片位置和张数
    const EXPLO_IMG_PREFIX = 'images/collect_explosion_'
    const EXPLO_FRAME_COUNT = 20
    //逐帧将图片载入到数组中
    for (let i = 0; i < EXPLO_FRAME_COUNT; i++) {
      frames.push(EXPLO_IMG_PREFIX + (i + 1) + '.png')
    }
    //初始化帧动画
    this.initFrames(frames)
  }

  /**
   * 初始化帧动画的所有帧
   * 为了简单，只支持一个帧动画
   */
  initFrames(imgList) {
    //遍历帧动画的每一帧
    imgList.forEach((imgSrc) => {
      let img = new Image()
      img.src = imgSrc
      this.imgList.push(img)
    })
    this.count = imgList.length
  }

  // 将播放中的帧绘制到canvas上
  //通过drawImage在ctx画布上显示动画的对应帧
  aniRender(ctx) {
    ctx.drawImage(
      this.imgList[this.index],
      this.x,
      this.y,
      this.width,
      this.height
    )
  }

  // 播放预定的帧动画
  playAnimation(index = 0, loop = false) {
    //设置当前动画正在播放
    this.isPlaying = true
    //将是否循环设置为输入值
    this.loop = loop
    this.index = index
    //判断是否有动画切换和帧数
    if (this.interval > 0 && this.count) {
      this[__.timer] = setInterval(
        this.frameLoop.bind(this),
        this.interval
      )
    }
  }

  // 停止帧动画播放
  stop() {
    this.isPlaying = false
    //清除原本的计时器
    if (this[__.timer])
      clearInterval(this[__.timer])
  }

  // 帧遍历
  frameLoop() {
    //设置动画的帧数加一
    this.index++
    //如果帧数大于图片数减1（因为第一张图片下标为0）
    if (this.index > this.count - 1) {
      //如果该动画需要循环，设置帧数为0
      if (this.loop) {
        this.index = 0
      }
      //否则动画停止
      else {
        //设置为最后一张
        this.index--
        this.stop()
      }
    }
  }
}