/**
 * 游戏基础的精灵类
 */
export default class Sprite {
  //构造器，根据输入的图片路径，宽度和高度，生成的位置（左上角），构造一个精灵
  constructor(imgSrc = '', width = 0, height = 0, x = 0, y = 0) {
    this.img = new Image()
    this.img.src = imgSrc

    this.width = width
    this.height = height

    this.x = x
    this.y = y
    //初始化设定精灵均可见
    this.visible = true
  }

  /**
   * 将精灵图绘制在canvas上
   */
  drawToCanvas(ctx) {
    //如果精灵不可见，直接返回不操作
    if (!this.visible)
      return
    /**
     * 如果精灵可见，在荧幕上显示该精灵
     * 该函数中的this指代对象为2d画布对象
     * 该参数中的width与height会使图片拉伸
     */
    ctx.drawImage(
      this.img,
      this.x,
      this.y,
      this.width,
      this.height
    )
  }
}