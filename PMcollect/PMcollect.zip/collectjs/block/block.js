import Sprite from '../base/sprite'
import DataBus from '../databus'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight
const BLOCK_WIDTH = screenWidth * 0.95 / 11.236
const BLOCK_HEIGHT = screenWidth * 0.95 / 11.236

let databus = new DataBus()

export default class Block {
  constructor() {
    this.default(-1)
  }

  default (isRandom) {
    this.choice = isRandom
    this.Block_IMG_SRC = ''
    this.value = null
    if (this.choice == -1)
      this.getBlock_random()
    this.getBlock_IMG_SRC(this.choice)
    this.blocksprite = []
    //当block被初始化的时候要从pool中取出一个名称为Block_IMG_SRC的精灵对象
    //但如果该名称下无可用对象，就用这个名字去初始化新建一个对象
    console.log()
    let temp = databus.pool.getSpriteByClass(this.Block_IMG_SRC)
    temp.width = BLOCK_WIDTH
    temp.height = BLOCK_HEIGHT
    this.blocksprite.push(temp)
    //实际显示位置应该用下述方法访问
    //this.blocksprite[0].x
    this.blocksprite[0].y = screenWidth / 6.9438 - screenWidth / 11.236
    //block对象下应出现的新位置
    this.NewX = 0
    this.NewY = 0
    //block对象下逻辑位置
    this.arrX = 0
    this.arrY = 0
    //移到新位置的剩余帧数
    this.step = 0
    //在消除函数中作为标记量
    this.burstTag = false
    //消除标记倒计时
    this.burning = -1
  }

  getBlock_random() {
    this.choice = Math.floor(Math.random() * 4)
  }

  getBlock_IMG_SRC(choice) {
    switch (choice) {
      case 0:
        this.Block_IMG_SRC = 'images/collect_1.png'
        this.value = 1
        break
      case 1:
        this.Block_IMG_SRC = 'images/collect_5.png'
        this.value = 5
        break
      case 2:
        this.Block_IMG_SRC = 'images/collect_10.png'
        this.value = 10
        break
      case 3:
        this.Block_IMG_SRC = 'images/collect_50.png'
        this.value = 50
        break
      case 4:
        this.Block_IMG_SRC = 'images/collect_100.png'
        this.value = 100
        break
      case 5:
        this.Block_IMG_SRC = 'images/collect_500.png'
        this.value = 500
        break
      default:
        this.Block_IMG_SRC = 'images/collect_err.png';
        break
    }
  }

  /**
   * 移除当前block身上绑定的精灵对象
   */
  removeSprite(Sprite) {
    let temp = this.blocksprite.shift()
    temp.visible = false
    databus.pool.recover(this.Block_IMG_SRC, Sprite)
  }

  /**
   * 在画布上绘制当前区块
   */
  render(ctx) {
    this.blocksprite[0].drawToCanvas(ctx)
    if (this.step > 0) {
      this.blocksprite[0].y += (this.NewY - this.blocksprite[0].y) / this.step
      this.blocksprite[0].x += (this.NewX - this.blocksprite[0].x) / this.step
      this.step--
    } else {
      this.step = 0
      this.blocksprite[0].y = this.NewY
      this.blocksprite[0].x = this.NewX
    }
  }
}