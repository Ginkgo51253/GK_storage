let instance

/**
 * 统一的音效管理器
 */
export default class Music {
  constructor() {
    if (instance)
      return instance
    instance = this

    this.bgmAudio = new Audio()
    this.bgmAudio.loop = true
    this.bgmAudio.src = 'audio/collectcoins.ogg'

    this.collectAudio = new Audio()
    this.collectAudio.src = 'audio/collectgetgive.ogg'

    this.explosionAudio = new Audio()
    this.explosionAudio.src = 'audio/collectexplosion.ogg'

    this.gameOverAudio = new Audio()
    this.gameOverAudio.src = 'audio/gameover.ogg'
  }
  playBgm() {
    this.bgmAudio.currentTime = 0
    this.bgmAudio.play()
  }
  pauseBgm() {
    this.bgmAudio.pause()
  }
  playCollect() {
    this.collectAudio.currentTime = 0
    this.collectAudio.play()
  }
  playExplosion() {
    this.explosionAudio.currentTime = 0
    this.explosionAudio.play()
  }
  playGameOver() {
    this.gameOverAudio.play()
  }
}