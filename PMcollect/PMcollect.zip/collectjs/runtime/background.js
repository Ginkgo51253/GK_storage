import Sprite from '../base/sprite'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

const BG_IMG_SRC = 'images/collect_bg.png'
const BT_right_IMG_SRC = 'images/button_right.png'
const BT_left_IMG_SRC = 'images/button_left.png'
const BT_give_IMG_SRC = 'images/button_give.png'
const BT_get_IMG_SRC = 'images/button_get.png'
const DE_CLOUD_SRC = 'images/collect_cloud.png'
const DE_CLOUD_COVER_SRC = 'images/collect_cloud_cover.png'
const DE_CLOUD_BOTTON_LINE_SRC = 'images/collect_bottom_line.png'
const BG_WIDTH = 40
const BG_HEIGHT = 70
const BT_len1 = 143.856
const BT_len2 = 75.816

/**
 * 游戏背景类
 * 提供update和render函数实现无限滚动的背景功能
 */
export default class BackGround extends Sprite {
  constructor(ctx) {
    super(BG_IMG_SRC, BG_WIDTH, BG_HEIGHT)
    this.initButton()
    this.initCloud()
    this.initOther()
    this.render(ctx)
    this.gameOver = false
  }

  initButton() {
    this.BT_right = new Sprite(BT_right_IMG_SRC, BT_len1, BT_len2)
    this.BT_right.x = 2
    this.BT_right.y = screenHeight - BT_len2
    this.BT_left = new Sprite(BT_left_IMG_SRC, BT_len2, BT_len1)
    this.BT_left.x = 0
    this.BT_left.y = screenHeight - BT_len1 - 2
    this.BT_get = new Sprite(BT_get_IMG_SRC, BT_len1, BT_len2)
    this.BT_get.x = screenWidth - BT_len1 - 2
    this.BT_get.y = screenHeight - BT_len2
    this.BT_give = new Sprite(BT_give_IMG_SRC, BT_len2, BT_len1)
    this.BT_give.x = screenWidth - BT_len2
    this.BT_give.y = screenHeight - BT_len1 - 2
  }

  initCloud() {
    this.DE_cloud = new Sprite(DE_CLOUD_SRC, 320, 200)
    this.DE_x = 0
    this.DE_count = 0
  }

  initOther() {
    this.DE_cloud_cover = new Sprite(DE_CLOUD_COVER_SRC, screenWidth, 1.7 * screenWidth / 11.236)
    this.DE_cloud_botton_line = new Sprite(DE_CLOUD_BOTTON_LINE_SRC, screenWidth, 0.01335 * screenWidth)
    this.DE_cloud_botton_line.x = 0
    this.DE_cloud_botton_line.y = 1.12 * screenWidth
  }

  drawCloud(ctx) {
    ctx.drawImage(
      this.DE_cloud.img,
      0, 0, 320, 200,
      0 - this.DE_x, screenHeight - 200, 320, 200
    )
    ctx.drawImage(
      this.DE_cloud.img,
      0, 0, 320, 200,
      320 - this.DE_x, screenHeight - 200, 320, 200
    )
    if (!this.gameOver){
      this.DE_count++
    }else{
      return
    }
    if (this.DE_count % 4 == 0) {
      this.DE_x++
      this.DE_count = 0
    }
    if (this.DE_x >= 320)
      this.DE_x = 0
  }

  /**
   * 背景图重绘函数
   */
  render(ctx) {
    ctx.drawImage(
      this.img,
      0,
      0,
      this.width,
      this.height,
      0,
      0,
      screenWidth,
      screenHeight
    )
    this.drawCloud(ctx)
    this.BT_right.drawToCanvas(ctx)
    this.BT_left.drawToCanvas(ctx)
    this.BT_get.drawToCanvas(ctx)
    this.BT_give.drawToCanvas(ctx)
    this.DE_cloud_botton_line.drawToCanvas(ctx)
  }
}