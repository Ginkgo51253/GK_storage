const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

let atlas = new Image()
atlas.src = 'images/Common.png'

/**
 * 游戏信息绘制类
 */
export default class GameInfo {
  /**
   * 绘制玩家得分情况
   * @param {画布对象} ctx 
   * @param {*玩家得分参数} score 
   */
  renderGameScore(ctx, score) {
    ctx.fillStyle = "rgb(91,53,14)"
    ctx.font = "20px Arial"
    ctx.fillText(
      score,
      7,
      22
    )
  }

  /**
   * 绘制游戏结束后荧幕信息
   * @param {画布对象} ctx 
   * @param {*玩家得分参数} score 
   */
  renderGameOver(ctx, score) {
    ctx.drawImage(
      atlas,
      0, 0, 128, 88,
      screenWidth / 2 - 150,
      screenHeight / 2 - 150,
      300, 300
    )

    ctx.fillStyle = "#ffffff"
    ctx.font = "20px Arial"

    ctx.fillText(
      'Game Over',
      screenWidth / 2 - 55,
      screenHeight / 2 - 105
    )

    ctx.fillText(
      'Scores ' + score,
      screenWidth / 2 - 45,
      screenHeight / 2 - 15
    )

    ctx.drawImage(
      atlas,
      1, 96, 62, 31,
      screenWidth / 2 - 60,
      screenHeight / 2 + 40,
      120, 40
    )

    ctx.fillText(
      'Back',
      screenWidth / 2 - 25,
      screenHeight / 2 + 67
    )
  }
}