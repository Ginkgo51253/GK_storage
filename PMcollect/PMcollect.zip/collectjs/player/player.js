import Sprite from '../base/sprite'
import DataBus from '../databus'

let databus = new DataBus()

//荧幕画布和方格单元的基本参数
const screenWidth = window.innerWidth
const screenHeight = window.innerHeight
const screenBlock = screenWidth / 11.236

//玩家精灵参数
const PLAYER_IMG_SRC = 'images/collect_player.png'
const PLAYER_WIDTH = screenWidth * 0.144
const PLAYER_HEIGHT = screenWidth / 11.236

export default class Player extends Sprite {
  constructor() {
    super(PLAYER_IMG_SRC, PLAYER_WIDTH, PLAYER_HEIGHT)
    this.tiniplayer = new Sprite(PLAYER_IMG_SRC, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3)
    this.default()
  }

  default () {
    this.playerBlock = []
    this.arrX = 3 //玩家初始位置在逻辑x轴4号处，初始值为0
    this.x = 3.618 * screenBlock - 0.31 * screenBlock
    this.y = 2 * screenBlock / 0.618 + screenBlock * 10
    this.blockNewX = this.x + 0.31 * screenBlock
    this.blockNewY = this.y - screenBlock / 2
    this.blockRestrict = false
    this.playerBlockMaxLength = 0
  }

  getPlayerBlockMaxLength() {
    if (this.playerBlock.length <= 0) {
      this.blockRestrict = false
      this.playerBlockMaxLength = 0
    } else {
      this.blockRestrict = true
      switch (this.playerBlock[0].value) {
        case 1:
          this.playerBlockMaxLength = 5;
          break;
        case 10:
          this.playerBlockMaxLength = 5;
          break;
        case 100:
          this.playerBlockMaxLength = 5;
          break;
        case 5:
          this.playerBlockMaxLength = 2;
          break;
        case 50:
          this.playerBlockMaxLength = 2;
          break;
        case 500:
          this.playerBlockMaxLength = 2;
          break;
        default:
          console.log("playerBlock error! new playerBlock")
          this.playerBlock = new Array()
          break;
      }
    }
  }

  getNewX() {
    this.x = (0.618 + this.arrX) * screenBlock - 0.31 * screenBlock
    this.blockNewX = this.x + 0.31 * screenBlock
  }

  playerBlockRender(ctx) {
    if (this.playerBlock.length >= 1) {
      for (var i = 0; i < this.playerBlock.length; i++) {
        this.playerBlock.render(ctx)
      }
    }
  }

  getTiniPlayer(ctx) {
    let x = this.arrX
    let y = databus.arrayMap[x].length
    this.tiniplayer.x = (0.618 + x) * screenBlock + 0.25 * screenBlock
    this.tiniplayer.y = screenBlock / 0.618 + screenBlock * y + 0.2 * screenBlock
    this.tiniplayer.drawToCanvas(ctx)
  }
}