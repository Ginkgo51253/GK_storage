import Player from './player/player'
import BackGround from './runtime/background'
import GameInfo from './runtime/gameinfo'
import Music from './runtime/music'
import DataBus from './databus'
import Block from './block/block'
import Animation from './base/animation'

//在函数调用之前生成了一个2d画布
let context = canvas.getContext('2d')
//生成了游戏的数据总线，该总线对象独一无二
let databus = new DataBus()
//获取荧幕参数
const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

/**
 * 零花钱大作战主要对象
 * 它的实例化会使小游戏开始运行
 */
export default class collectmain {
  constructor(that) {
    this.aniId = 0
    this.goback = that
    this.player = new Player()
    this.blockSpeed = 12 //全局方块移动速度为12帧到目标位置
    this.default()
  }

  default () {
    this.aniId = 0
    //游戏各项内容初始化
    databus.reset() //数据总线初始化
    this.bg = new BackGround(context) //生成新的背景对象
    this.player.default() //玩家对象内各数据初始化
    this.music = new Music() //音效控制初始化
    this.music.playBgm()
    this.gameinfo = new GameInfo()
    this.newLineBlock() //游戏开始时即产生一行方块
    this.touchHandlerCheck = false
    //玩家移动按钮响应
    this.touchHandler_move = this.touchEventHandler_move.bind(this)
    canvas.addEventListener('touchstart', this.touchHandler_move)
    //玩家拿去和放回方块按钮响应
    this.touchHandler_click = this.touchEventHandler_click.bind(this)
    canvas.addEventListener('touchstart', this.touchHandler_click)
    //绑定事件循环，初始化状态
    this.bindLoop = this.loop.bind(this)
    //清除上一局的动画
    //该例中只是用了初始化的main对象更新loop函数，并将其作为刷新内容
    window.cancelAnimationFrame(this.aniId);
    //但由于main对象中的逻辑会产生变更，因此在之后的loop函数也对其进行了请求，并绑定了参数
    //使用新产生的main对象和新产生的canvas在浏览器中进行渲染
    this.aniId = window.requestAnimationFrame(this.bindLoop, canvas)
    //在实际测试当中，该刷新为每秒更新60帧
  }

  /**
   * 在arrayMap矩阵第一行添加新对象
   */
  newLineBlock() {
    for (var i = 0; i < 10; i++) {
      let block = databus.pool.getItemByClass('block', Block)
      block.default(-1)
      var a = databus.pointLU_x + i * databus.x
      block.blocksprite[0].x = a
      databus.arrayMap[i].unshift(block)
    }
    //更新所有方块的新目标位置
    for (var i = 0; i < databus.arrayMap.length; i++) {
      for (var j = 0; j < databus.arrayMap[i].length; j++) {
        var a = databus.pointLU_x + i * databus.x
        var b = databus.pointLU_y + j * databus.x
        databus.arrayMap[i][j].arrX = i
        databus.arrayMap[i][j].arrY = j
        databus.arrayMap[i][j].NewX = a
        databus.arrayMap[i][j].NewY = b
        databus.arrayMap[i][j].step = this.blockSpeed
      }
    }
  }

  /**
   * 测试用返回主页侦听响应函数
   * @param {*系统响应-点击} e 
   */
  touchEventHandler_back(e) {
    //e为输入对象，即一个系统响应
    e.preventDefault()
    //从该响应中获取玩家触碰的位置
    let x = e.touches[0].clientX
    let y = e.touches[0].clientY
    //如果触碰的位置为目标位置内就回到首页
    if (x >= screenWidth / 2 - 60 &&
      x <= screenWidth / 2 + 60 &&
      y >= screenHeight / 2 + 40 &&
      y <= screenHeight / 2 + 80) {
      this.eventEnder()
    }
  }

  /**
   * 玩家拿去-放回方块点击侦听响应函数
   * @param {*系统响应-点击} e 
   */
  touchEventHandler_click(e) {
    e.preventDefault()
    //从该响应中获取玩家触碰的位置
    let x = e.touches[0].clientX
    let y = e.touches[0].clientY
    if ((x < y - screenHeight + screenWidth &&
        x >= screenWidth - 61.56) ||
      Math.pow(x - screenWidth + 97.848, 2) + Math.pow(y - screenHeight + 23, 2) <= Math.pow(51.6, 2)) {
      this.playerGetBlock()
    }
    if ((x > y - screenHeight + screenWidth &&
        y >= screenHeight - 61.56) ||
      Math.pow(x - screenWidth + 23, 2) + Math.pow(y - screenHeight + 97.848, 2) <= Math.pow(51.6, 2)) {
      this.playerGiveBlock()
    }
  }

  /**
   * 玩家移动侦听响应函数
   * @param {*系统响应-点击} e 
   */
  touchEventHandler_move(e) {
    e.preventDefault()
    //从该响应中获取玩家触碰的位置
    let x = e.touches[0].clientX
    let y = e.touches[0].clientY
    if ((x < -y + screenHeight &&
        y >= screenHeight - 61.56) ||
      Math.pow(x - 23, 2) + Math.pow(y - screenHeight + 97.848, 2) <= Math.pow(51.6, 2)) {
      this.playerMoveLeft()
    }
    if ((x > -y + screenHeight &&
        x <= 61.56) ||
      Math.pow(x - 97.848, 2) + Math.pow(y - screenHeight + 23, 2) <= Math.pow(51.6, 2)) {
      this.playerMoveRight()
    }
    this.player.playerBlock.forEach(block => {
      block.NewX = this.player.blockNewX
      block.NewY = this.player.blockNewY
    })
  }

  /**
   * 事件终结者
   * 取消当前场景中的监听
   * 清除当前场景中播放的动画
   * 调用主界面函数（相当于回到主页）
   */
  eventEnder() {
    databus.removeAllArray()
    canvas.removeEventListener('touchstart', this.touchHandler_back)
    window.cancelAnimationFrame(this.aniId);
    this.goback.default()
  }

  //计算玩家左右移动函数
  playerMoveLeft() {
    if (this.player.arrX > 0) {
      this.player.arrX--
    } else {
      this.player.arrX = 0
    }
    this.player.getNewX()
  }
  playerMoveRight() {
    if (this.player.arrX < 9) {
      this.player.arrX++
    } else {
      this.player.arrX = 9
    }
    this.player.getNewX()
  }
  //玩家从版面上获取方块
  playerGetBlock() {
    if (!this.player.blockRestrict &&
      databus.arrayMap[this.player.arrX].length > 0) {
      let temp = databus.arrayMap[this.player.arrX].pop()
      temp.step = this.blockSpeed
      this.player.playerBlock.push(temp)
      this.player.getPlayerBlockMaxLength()
      this.music.playCollect()
    }
    while (databus.arrayMap[this.player.arrX].length > 0 &&
      this.player.playerBlock[0].value ==
      databus.arrayMap[this.player.arrX][(databus.arrayMap[this.player.arrX].length) - 1].value &&
      this.player.playerBlock.length <
      this.player.playerBlockMaxLength) {
      this.music.playCollect()
      let temp = databus.arrayMap[this.player.arrX].pop()
      temp.step = this.blockSpeed
      this.player.playerBlock.push(temp)
    }
    this.player.playerBlock.forEach(block => {
      block.NewX = this.player.blockNewX
      block.NewY = this.player.blockNewY
    })
  }
  //玩家将方块从手中放回
  playerGiveBlock() {
    if (this.player.playerBlock.length > 0) {
      this.music.playCollect()
      while (this.player.playerBlock.length >= 1) {
        let temp = this.player.playerBlock.pop()
        let i = this.player.arrX
        let j = databus.arrayMap[this.player.arrX].length
        let a = databus.pointLU_x + i * databus.x
        let b = databus.pointLU_y + j * databus.x
        temp.arrX = i
        temp.arrY = j
        temp.NewX = a
        temp.NewY = b
        temp.step = this.blockSpeed
        databus.arrayMap[this.player.arrX].push(temp)
      }
      this.player.blockRestrict = false
      if (databus.arrayMap[this.player.arrX].length > 0)
        this.blockCheck()
    }
  }

  /**玩家将方块放回后检查消除 */
  blockCheck() {
    let burstX = this.player.arrX
    let burstY = databus.arrayMap[burstX].length - 1
    if (typeof (databus.arrayMap[burstX][burstY]) == "undefined")
      return
    let burstValue = databus.arrayMap[burstX][burstY].value
    let limit = 0
    databus.burstCount = 0
    this.blockCheckFun(burstX, burstY, databus.arrayMap[burstX][burstY].value)
    limit = this.blockCheckLimit(databus.arrayMap[burstX][burstY].value)
    if (databus.burstCount >= limit) {
      this.music.playExplosion()
      for (let i = 0; i < databus.arrayMap.length; i++) {
        for (let j = 0; j < databus.arrayMap[i].length; j++) {
          if (databus.arrayMap[i][j].burstTag == true) {
            let temp = databus.arrayMap[i].splice(j, 1).pop()
            temp.burning = 12
            databus.score += temp.value
            databus.bonus.push(temp)
            databus.hold = this.blockSpeed
            j--
          }
        }
      }
      /**在被消除列最后添加一块更高等级的 */
      let choice = this.blockCheckReplace(burstValue)
      if (choice != -1) {
        let block = databus.pool.getItemByClass('block', Block)
        block.default(choice)
        let a = databus.pointLU_x + burstX * databus.x
        let b = databus.pointLU_y + burstY * databus.x
        block.blocksprite[0].x = a
        block.blocksprite[0].y = b
        block.blocksprite[0].visible = false
        databus.arrayMap[burstX].push(block)
      }
      for (let i = 0; i < databus.arrayMap.length; i++) {
        for (let j = 0; j < databus.arrayMap[i].length; j++) {
          var a = databus.pointLU_x + i * databus.x
          var b = databus.pointLU_y + j * databus.x
          databus.arrayMap[i][j].arrX = i
          databus.arrayMap[i][j].arrY = j
          databus.arrayMap[i][j].NewX = a
          databus.arrayMap[i][j].NewY = b
          databus.arrayMap[i][j].step = this.blockSpeed
        }
      }
      databus.comboTime = 33
    } else {
      for (let i = 0; i < databus.arrayMap.length; i++) {
        for (let j = 0; j < databus.arrayMap[i].length; j++) {
          databus.arrayMap[i][j].burstTag = false
        }
      }
    }
  }

  /**遍历arrMap查看与爆发块相同的方块并标记 */
  blockCheckFun(X, Y, value) {
    if (typeof (databus.arrayMap[X][Y]) != "undefined" &&
      databus.arrayMap[X][Y].value == value &&
      !databus.arrayMap[X][Y].burstTag) {
      databus.burstCount++
      databus.arrayMap[X][Y].burstTag = true
      if (Y > 0)
        this.blockCheckFun(X, Y - 1, value)
      if (X > 0)
        this.blockCheckFun(X - 1, Y, value)
      if (X < 9)
        this.blockCheckFun(X + 1, Y, value)
      this.blockCheckFun(X, Y + 1, value)
    }
  }

  /**根据爆发块获取爆发阀数值 */
  blockCheckLimit(value) {
    if (value == 1 || value == 10 || value == 100) {
      return 5
    } else {
      return 2
    }
  }
  /**方块爆发后替换为更高级的方块 */
  blockCheckReplace(value) {
    switch (value) {
      case 1:
        return 1
      case 5:
        return 2
      case 10:
        return 3
      case 50:
        return 4
      case 100:
        return 5
      case 500:
        databus.score += 1000;
        return -1
      default:
        return -1
    }
  }

  difficultControl() {
    let dataframe = databus.frame
    let datascore = databus.score
    dataframe *= (1 - 1 / (0.0003 * datascore + 1))
    if (dataframe >= 0 && dataframe < 19800) {
      databus.difficultTime = (100 / (dataframe / 3600 + 8.5) - 3.7) * 60
    } else if (dataframe >= 19800) {
      databus.difficultTime = (0.3848 / (dataframe / 3600 - 4.6314) + 3) * 60
    } else { //此为异常情况定时，防止逻辑错误
      databus.difficultTime = 240
    }
  }

  /**
   * 帧渲染函数
   */
  render() {
    this.bg.render(context)
    this.player.getTiniPlayer(context)
    for (let i = 0; i < databus.arrayMap.length; i++) {
      for (let j = 0; j < databus.arrayMap[i].length; j++) {
        if (databus.hold > 0) {
          databus.arrayMap[i][j].blocksprite[0].drawToCanvas(context)
        } else {
          databus.arrayMap[i][j].blocksprite[0].visible = true
          databus.arrayMap[i][j].render(context)
        }
      }
    }
    this.player.playerBlock.forEach(block => {
      if (!block.blocksprite[0].visible)
        block.blocksprite[0].visible = true
      block.render(context)
    })
    this.player.drawToCanvas(context)
    databus.bonus.forEach(block => {
      block.burning--
      if (block.burning <= 0)
        block.blocksprite[0].visible = false
      block.render(context)
    })
    databus.animations.forEach(anime => {
      if (anime.isPlaying)
        anime.aniRender(context)
    })
    this.bg.DE_cloud_cover.drawToCanvas(context)

    //更新分数记分显示
    this.gameinfo.renderGameScore(context, databus.score)
    if (databus.gameOver) {
      this.gameinfo.renderGameOver(context, databus.score)
      //测试用返回按钮
      if (!this.touchHandlerCheck) {
        this.touchHandler_back = this.touchEventHandler_back.bind(this)
        canvas.addEventListener('touchstart', this.touchHandler_back)
        this.touchHandlerCheck = true
      }
    }
    this.update()
  }

  /**帧逻辑更新 */
  update() {
    if (databus.gameOver) {
      return
    }
    if (databus.hold > 0)
      databus.hold--
    databus.frame++
    if (databus.comboTime > 0 && databus.comboTime <= 33) {
      if (databus.comboTime <= 18 && databus.comboTime % 2 == 1) {
        this.blockCheck()
      }
      databus.comboTime--
    }
    while (databus.bonus.length > 0 &&
      !databus.bonus[0].blocksprite[0].visible) {
      let anime = databus.pool.getItemByClass('anime', Animation)
      anime.default(databus.bonus[0].blocksprite[0].x, databus.bonus[0].blocksprite[0].y)
      anime.playAnimation()
      databus.animations.push(anime)
      databus.removeBlock()
    }
    while (databus.animations.length > 0 &&
      !databus.animations[0].isPlaying) {
      databus.removeAnime()
    }

    //产生新方块工作逻辑
    if (databus.difficultTime <= 0) {
      this.newLineBlock()
      this.difficultControl()
    }
    databus.difficultTime--
    //如果画面上总方块少于1行，databus.difficultTime计数减少速度额外增加
    let maxlength = 0
    databus.arrayMap.forEach(col => {
      if (col.length > maxlength) {
        maxlength = col.length
      }
    })
    if (maxlength <= 1) {
      databus.difficultTime--
    } else if (maxlength > 11) {
      databus.gameOver = true
      this.music.pauseBgm()
      this.music.playGameOver()
      this.bg.gameOver = true
      canvas.removeEventListener('touchstart', this.touchHandler_move)
      canvas.removeEventListener('touchstart', this.touchHandler_click)
    }
  }

  /**
   * 实现游戏的帧循环
   */
  loop() {
    this.render()
    this.aniId = window.requestAnimationFrame(
      this.bindLoop,
      canvas
    )
  }
}