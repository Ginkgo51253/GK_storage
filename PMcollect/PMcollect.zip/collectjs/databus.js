import Pool from './base/pool'

let instance

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

export default class DataBus {
  constructor() {
    if (instance)
      return instance
    instance = this
    this.pool = new Pool()
    //游戏荧幕基础数据信息初始化
    this.getAvailableSpace()
    this.reset()
  }
  /**
   * 设置游戏的重启状态
   */
  reset() {
    this.frame = 0
    this.score = 0
    this.animations = []
    this.gameOver = false
    this.arrayMap = []
    this.arrayMapInit()
    this.bonus = []
    //方块爆发计数
    this.burstCount = 0
    //等待动画结束倒计时
    this.hold = 0
    //combo倒计时
    this.comboTime = 0
    //游戏难度倒计时
    this.difficultTime = 0
  }

  /**
   * 初始化arrayMap的二维数组格式
   * 一共10列，每列逐一添加元素
   */
  arrayMapInit() {
    for (var i = 0; i < 10; i++) {
      this.arrayMap[i] = []
    }
  }

  /**
   * 先从bonus对象组上取出一个对象
   * 从block对象上移除绑定的sprite
   * 然后才能回收该block
   */
  removeBlock() {
    let temp = this.bonus.shift()
    temp.removeSprite(temp.blocksprite[0])
    temp.visible = false
    this.pool.recover("block", temp)
  }

  removeAllArray() {
    for (let i = 0; i < this.arrayMap.length; i++) {
      while (this.arrayMap[i].length > 0) {
        this.bonus.push(this.arrayMap[i].shift())
      }
    }
    while (this.bonus.length > 0) {
      this.removeBlock()
    }
    while (this.animations.length > 0) {
      this.removeAnime()
    }
  }

  removeAnime() {
    let temp = this.animations.shift()
    this.pool.recover('anime', temp)
  }

  getAvailableSpace() {
    this.x = screenWidth / 11.236
    this.y = 0.618 * this.x
    this.z = this.x / 0.618
    this.pointLU_x = this.y
    this.pointLU_y = this.z
    this.pointRD_x = this.y + 10 * this.x
    this.pointRD_y = this.z + 11 * this.x
  }
}