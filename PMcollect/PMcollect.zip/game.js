import './libs/weapp-adapter' //全局依赖，对小游戏的支持
import './libs/symbol' //全局依赖，ES6对symbol的极简兼容

import indexmain from './indexjs/indexmain' //自建的首页样例

new indexmain() //实例化，即程序的入口