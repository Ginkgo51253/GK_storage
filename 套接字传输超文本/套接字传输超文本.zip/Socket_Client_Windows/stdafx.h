//
// Created by 24758 on 2020/5/19.
//

/**
 * 标准引用头文件
 */
#ifndef READFILE_STDAFX_H
#define READFILE_STDAFX_H
#define MAXLENGTH 1024

#include<iostream>
#include<fstream>
#include<direct.h>
#include<vector>
#include<afxres.h>
#include<sstream>
//#include<cstdlib>
//#include<string>
//#include<ctype>
//#include<unistd.h>//我认为windows平台并不能使用这个头文件

#endif //READFILE_STDAFX_H
