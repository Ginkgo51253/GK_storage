#include"stdafx.h"
#include "cmake-build-debug/cpp/Commandoperation.h"
#include "cmake-build-debug/cpp/Getstruct.h"

int main() {
    Commandoperation commandoperation{};
    char inputbuffer[MAXLENGTH];
    while(strcmp("Ginkgo",inputbuffer) != 0){
        std::cin.getline(inputbuffer,MAXLENGTH);
        commandoperation.getCommandParam(inputbuffer,Getstruct::commandparams);
        commandoperation.doCommand(Getstruct::commandparams);
        Getstruct::commandparams.clear();
    }
    return 0;
}
