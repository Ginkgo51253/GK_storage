//
// Created by 24758 on 2020/5/25.
//

#ifndef SOCKET_CLIENT_WINDOWS_HEADER_H
#define SOCKET_CLIENT_WINDOWS_HEADER_H

#include "cmake-build-debug/cpp/Getstruct.h"
#include "cmake-build-debug/cpp/Modeall.h"
#include "cmake-build-debug/cpp/Modenone.h"
#include "cmake-build-debug/cpp/Modectoc.h"
#include "cmake-build-debug/cpp/Modectos.h"
#include "cmake-build-debug/cpp/Transmission.h"
Getstruct getstruct{};
Modeall modeall{};
Modenone modenone{};
Modectoc modectoc{};
Modectos modectos{};
Transmission transmission{};

#endif //SOCKET_CLIENT_WINDOWS_HEADER_H
