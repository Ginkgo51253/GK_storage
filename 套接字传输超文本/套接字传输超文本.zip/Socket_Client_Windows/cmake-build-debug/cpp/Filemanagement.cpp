//
// Created by 24758 on 2020/5/21.
//
/**
 * 本段函数库文件依赖
 * #include<vector> #include<afxres.h> #include<direct.h> #include<fstream>
 */
#include "../../stdafx.h"
#include "Filemanagement.h"

char Filemanagement::localpath[MAXLENGTH];

Filemanagement::Filemanagement(){
    getcwd(localpath, MAXLENGTH);
}

/**
 * 在指定目录下创建指定名称的文件夹
 * @param path 指定目录名称
 * @param fileName 指定文件名称
 * @return 0成功，1已存在，-1建立失败
 */
int Filemanagement::createDir(const char *path, const char *fileName) {
    char folderPath[strlen(path)+strlen(fileName)];
    strcpy(folderPath,path);
    strcat(folderPath,"/");
    strcat(folderPath,fileName);
    if (0 != access(folderPath, 0)) {
        return mkdir(folderPath);//换成 ::_mkdir  ::_access 也行，不知道什么意思
    }else{
        return 1;
    }
}

/**
 * 用于检测目录/文件是否存在
 * @param path 目录路径
 * @param fileName 文件名称，如果不需要则输入""
 * @return 0 不存在 1 存在
 */
bool Filemanagement::dirExist(const char *path, const char *fileName){
    char folderPath[strlen(path)+strlen(fileName)];
    strcpy(folderPath,path);
    strcat(folderPath,"/");
    strcat(folderPath,fileName);
    return 0 == access(folderPath, 0);
}

/**
 * 在指定路径下创建一个指定文件
 * @param path 路径名
 * @param fileName 文件名
 * @return 0 文件存在或正常创建 -1 创建错误
 */
int Filemanagement::createFile(const char *path, const char *fileName){
    char folderPath[strlen(path)+strlen(fileName)];
    strcpy(folderPath,path);
    strcat(folderPath,"/");
    strcat(folderPath,fileName);
    std::ifstream file;
    file.open(folderPath, std::ios::in|std::ios::app );
    if(!file){
        return -1;
    }
    file.close();
    return 0;
}

/**
 * 浏览指定目录下的全部文件
 * @param path 指定目录名
 * @param files 用来存放文件信息的字符串容器
 */
void Filemanagement::reviewAllFiles(const std::string& path,std::vector<std::string>& files){
    //文件句柄
    long   hFile   =   0;
    //文件信息
    struct _finddata_t fileInfo{};
    std::string p;
    if((hFile = _findfirst(p.assign(path).append("\\*").c_str(),&fileInfo)) !=  -1)
    {
        do
        {
            //如果是目录,迭代之
            //如果不是,加入列表
            if((fileInfo.attrib &  _A_SUBDIR))
            {
                if(strcmp(fileInfo.name,".") != 0  &&  strcmp(fileInfo.name,"..") != 0)
                    Filemanagement::reviewAllFiles( p.assign(path).append("\\").append(fileInfo.name), files );
            }
            else
            {
                files.push_back(p.assign(path).append("\\").append(fileInfo.name) );
            }
        }while(_findnext(hFile, &fileInfo)  == 0);
        _findclose(hFile);
    }
}

/**
 * 设置当前操作路径
 * @param path 路径名
 * @return 0 设置成功 -1 设置失败并将默认路径作为设置路径
 */
int Filemanagement::setPath(const char *path){
    if(Filemanagement::dirExist(path,"")){
        SetCurrentDirectory(path);
        return 0;
    }
    SetCurrentDirectory(localpath);
    return -1;
}