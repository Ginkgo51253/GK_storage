//
// Created by 24758 on 2020/5/24.
//

#ifndef SOCKET_CLIENT_WINDOWS_MODENONE_H
#define SOCKET_CLIENT_WINDOWS_MODENONE_H


class Modenone {
public:
    static void closeSocket();

    static int waitSocket();

    static void openSocket(std::vector<std::string> &commandparam);

    static int connetSocket(std::vector<std::string> &commandparam);

    static int dologin();
};


#endif //SOCKET_CLIENT_WINDOWS_MODENONE_H
