//
// Created by 24758 on 2020/5/20.
//

#ifndef READFILE_GETSTRUCT_H
#define READFILE_GETSTRUCT_H


class Getstruct {
public:
    Getstruct();
    struct user {
        char *username;
        char *password;
    } user_info{};
    static std::vector<std::string> commandparams;
    enum mode {
        none, CtoC, CtoS
    } wmode;
    static int port;
    static char *portip;
    static int connect;
    static char *connectip;
    static int beserver;
};


#endif //READFILE_GETSTRUCT_H
