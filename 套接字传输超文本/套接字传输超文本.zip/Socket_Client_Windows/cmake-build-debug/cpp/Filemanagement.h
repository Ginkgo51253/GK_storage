//
// Created by 24758 on 2020/5/21.
//

#ifndef READFILE_FILEMANAGEMENT_H
#define READFILE_FILEMANAGEMENT_H

class Filemanagement {
private:
    static char localpath[MAXLENGTH];
public:
    Filemanagement();

    static int createDir(const char *path, const char *fileName);

    static bool dirExist(const char *path, const char *fileName);

    static int createFile(const char *path, const char *fileName);

    static void reviewAllFiles(const std::string& path, std::vector<std::string>& files);

    static int setPath(const char *path);
};


#endif //READFILE_FILEMANAGEMENT_H
