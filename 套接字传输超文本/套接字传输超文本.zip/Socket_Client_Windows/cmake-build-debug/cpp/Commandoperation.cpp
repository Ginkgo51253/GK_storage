//
// Created by 24758 on 2020/5/23.
//

#include "../../stdafx.h"
#include "../../header.h"
#include "Commandoperation.h"

bool Commandoperation::commandfound;

Commandoperation::Commandoperation() {
    commandfound = false;
}

/**
 * 从输入区获得输入命令
 * 并按空格分隔并存入容器
 * @param str 来自控制台的命令字符串
 * @param commandparam 存放结果的容器
 */
void Commandoperation::getCommandParam(const char *str, std::vector<std::string> &commandparam) {
    if(strlen(str)==0){
        commandparam.emplace_back("no_params");
    }
    char *tempch = (char *) calloc(1, MAXLENGTH);
    std::string tempstr;
    strcpy(tempch, (const char *) str);
    tempch = strtok(tempch, " ");
    while (tempch) {
        tempstr = tempch;//char* to string
        commandparam.push_back(tempstr);
        tempch = strtok(nullptr, " ");
    }
}

/**
 * 识别与执行命令
 * @param commandparam 存放命令的容器
 * @return
 */
int Commandoperation::doCommand(std::vector<std::string> &commandparam) {
    std::string command = commandparam[0];
    //通用命令
    if ("help" == command) {
        commandfound = true;
        if (commandparam.size() != 1) {
            std::cout << "command wrong! should be 'help'" << std::endl;
        } else {
            Modeall::getHelp();//获取命令帮助
            std::cout<<"mode:"<<getstruct.wmode<<std::endl;
        }
    } else if ("status" == command) {
        commandfound = true;
        if (commandparam.size() != 1) {
            std::cout << "command wrong! should be 'status'" << std::endl;
        } else {
            Modeall::getstatus();//获取当前主动开启的端口号
            std::cout << "mode:" << getstruct.wmode;
            std::cout << " 0-none 1-CtoC 2-CtoS" <<std::endl;
        }
    } else if ("disconnect" == command) {
        commandfound = true;
        if (commandparam.size() != 1) {
            std::cout << "command wrong! should be 'disconnect'" << std::endl;
        } else {
            Modeall::disconnect();//断开当前已经产生的连接
            getstruct.wmode=getstruct.none;
        }
    } else if ("exit" == command) {
        commandfound = true;
        if (commandparam.size() != 1) {
            std::cout << "command wrong! should be 'exit'" << std::endl;
        } else {
            Modeall::exitprogram();//标准退出函数
        }
    }
    //none模式专有命令
    if ("open" == command) {
        commandfound = true;
        if(getstruct.wmode!=getstruct.none){
            std::cout<<"this command only works in 'mode:none'!"<<std::endl;
        }else if (commandparam.size() != 3 || isNum(commandparam[2].c_str()) != 0) {
            std::cout << "command wrong! Should be 'open (string)ip (int)port'"<<std::endl;
        } else {
            Modenone::openSocket(commandparam);
        }
    } else if ("close" == command) {
        commandfound = true;
        if(getstruct.wmode!=getstruct.none){
            std::cout<<"this command only works in 'mode:none'!"<<std::endl;
        }else if (commandparam.size() != 1) {
            std::cout << "command wrong! should be 'close'" << std::endl;
        } else {
            Modenone::closeSocket();
        }
    } else if ("connect" == command) {
        commandfound = true;
        if(getstruct.wmode!=getstruct.none){
            std::cout<<"this command only works in 'mode:none'!"<<std::endl;
        }else if (commandparam.size() != 3 || isNum(commandparam[2].c_str()) != 0) {
            std::cout << "command wrong! Should be 'connect (string)ip (int)port'"<<std::endl;
        } else {
            int check=Modenone::connetSocket(commandparam);
            if(check==1){
                getstruct.wmode=getstruct.CtoC;
            }else if(check==2){
                getstruct.wmode=getstruct.CtoS;
            }else{
                getstruct.wmode=getstruct.none;
            }
        }
    } else if ("wait" == command) {
        commandfound = true;
        if(getstruct.wmode!=getstruct.none){
            std::cout<<"this command only works in 'mode:none'!"<<std::endl;
        }else if (commandparam.size() != 1) {
            std::cout << "command wrong! should be 'wait'" << std::endl;
        } else {
            if(!Modenone::waitSocket()){
                getstruct.wmode=getstruct.CtoC;
            }
        }
    }
    //C-C模式专有命令
    if ("sendfile" == command) {
        commandfound = true;
        if(getstruct.wmode!=getstruct.CtoC){
            std::cout<<"this command only works in 'mode:CtoC'!"<<std::endl;
        }else if (commandparam.size() != 2) {
            std::cout << "command wrong! should be 'sendfile (string)filename'" << std::endl;
        } else {
            Modectoc::getSendFile(commandparam);
        }
    } else if ("renew" == command) {
        commandfound = true;
        if(getstruct.wmode!=getstruct.CtoC){
            std::cout<<"this command only works in 'mode:CtoC'!"<<std::endl;
        }else if (commandparam.size() != 1) {
            std::cout << "command wrong! should be 'renew'" << std::endl;
        } else {
            if(Modectoc::getRenew()==-1){
                getstruct.wmode=getstruct.none;
            }
        }
    }
    //C-S模式专有命令
    if ("upload" == command) {
        commandfound = true;
        if(getstruct.wmode!=getstruct.CtoS){
            std::cout<<"this command only works in 'mode:CtoS'!"<<std::endl;
        }else if (commandparam.size() != 2) {
            std::cout << "command wrong! should be 'upload (string)filename'" << std::endl;
        } else {
            Modectos::doUpload(commandparam[1]);
        }
    } else if ("download" == command) {
        commandfound = true;
        if(getstruct.wmode!=getstruct.CtoS){
            std::cout<<"this command only works in 'mode:CtoS'!"<<std::endl;
        }else if (commandparam.size() != 2) {
            std::cout << "command wrong! should be 'download (string)filename'" << std::endl;
        } else {
            Modectos::doDownload(commandparam[1]);
        }
    } else if ("list" == command) {
        commandfound = true;
        if(getstruct.wmode!=getstruct.CtoS){
            std::cout<<"this command only works in 'mode:CtoS'!"<<std::endl;
        }else if (commandparam.size() != 1) {
            std::cout << "command wrong! should be 'list'" << std::endl;
        } else {
            Modectos::doList();
        }
    } else if ("friends" == command) {
        commandfound = true;
        if(getstruct.wmode!=getstruct.CtoS){
            std::cout<<"this command only works in 'mode:CtoS'!"<<std::endl;
        }else if (commandparam.size() != 1) {
            std::cout << "command wrong! should be 'friends'" << std::endl;
        } else {
            Modectos::doFriends();
        }
    } else if ("share" == command) {
        commandfound = true;
        if(getstruct.wmode!=getstruct.CtoS){
            std::cout<<"this command only works in 'mode:CtoS'!"<<std::endl;
        }else if (commandparam.size() != 3) {
            std::cout << "command wrong! should be 'share (string)filename (string)friend'" << std::endl;
        } else {
            Modectos::doShare(commandparam);
        }
    } else if ("remove" == command) {
        commandfound = true;
        if(getstruct.wmode!=getstruct.CtoS){
            std::cout<<"this command only works in 'mode:CtoS'!"<<std::endl;
        }else if (commandparam.size() != 2) {
            std::cout << "command wrong! should be 'remove (string)filename'" << std::endl;
        } else {
            Modectos::doRemove(commandparam);
        }
    }

    if ("Ginkgo" == command) {//特殊终结字符
        commandfound = true;
        std::cout << "hello author!" << std::endl;
    }
    if (!commandfound) {//命令语句输入错误，提示输入help获取帮助
        std::cout << "input command not found! enter 'help' for info." << std::endl;
    }
    commandfound = false;
    return 0;
}

/**
 * 用于鉴别一个字符串是否是个数字
 * @param str 字符串
 * @return 0 该字符串是数字 -1该字符串包含非数字字符
 */
int Commandoperation::isNum(const char *str) {
    std::string temp = str;
    for (char i : temp) {
        if (!isdigit(i)) {
            return -1;
        }
    }
    return 0;
}