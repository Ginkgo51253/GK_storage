//
// Created by 24758 on 2020/5/27.
//

#include "../../stdafx.h"
#include "Transmission.h"
#include "Modectos.h"
#include "Filemanagement.h"
#include "Getstruct.h"

void Modectos::doList(){
    char buffer[MAXLENGTH] = {0};  //缓冲区
    send(Transmission::getClientSocket(), "list", strlen("list") + sizeof(char), 0);
    recv(Transmission::getClientSocket(), buffer, MAXBYTE, 0);
    std::cout<<buffer<<std::endl;
}

void Modectos::doFriends(){
    char buffer[MAXLENGTH] = {0};  //缓冲区
    send(Transmission::getClientSocket(), "friends", strlen("friends") + sizeof(char), 0);
    recv(Transmission::getClientSocket(), buffer, MAXBYTE, 0);
    std::cout<<buffer<<std::endl;
}

void Modectos::doUpload(const std::string& filename){
    if(!checkFileExist(filename)){//先检测文件是否存在
        std::cout<<"file cannot found! (check the path)"<<std::endl;
        return;
    }
    char buffer[MAXLENGTH] = {0};  //缓冲区
    send(Transmission::getClientSocket(), "upload", strlen("upload") + sizeof(char), 0);
    recv(Transmission::getClientSocket(), buffer, MAXBYTE, 0);
    if(strcmp("sendname",buffer)==0){
        std::string newname;
        std::cout<<"input file newname, do not contain '/' or space!"<<std::endl;
        std::cin>>newname;
        while(strchr(newname.c_str(),'/')!= nullptr&&strchr(newname.c_str(),' ')!= nullptr){
            std::cout<<"input file newname, do not contain '/' or space!"<<std::endl;
            std::cin>>newname;
        }
        send(Transmission::getClientSocket(), newname.c_str(), strlen(newname.c_str()) + sizeof(char), 0);
        recv(Transmission::getClientSocket(), buffer, MAXBYTE, 0);
        if(strcmp("sendfile",buffer)==0){
            doSend(filename);
        }else if(strcmp("exist",buffer)==0){
            std::cout<<"file exist! if you want to overwrite it, remove it first! return"<<std::endl;
            return;
        }else{
            std::cout<<"unknown error! return"<<std::endl;
            return;
        }
    }
}

void Modectos::doDownload(const std::string& filename){
    char buffer[MAXLENGTH] = {0};  //缓冲区
    send(Transmission::getClientSocket(), "download", strlen("download") + sizeof(char), 0);
    recv(Transmission::getClientSocket(), buffer, MAXBYTE, 0);
    if(strcmp("sendname",buffer)==0){
        send(Transmission::getClientSocket(), filename.c_str(), strlen(filename.c_str()) + sizeof(char), 0);
        recv(Transmission::getClientSocket(), buffer, MAXBYTE, 0);
        if(strcmp("setname",buffer)==0){
            std::string newname;
            std::cout << "input filename" << std::endl;
            std::cin >> newname;
            while (checkFileExist(newname)) {
                std::cout << "file exist! (change another name)" << std::endl;
                std::cin >> newname;
            }
            send(Transmission::getClientSocket(), "sendfile", strlen("sendfile") + sizeof(char), 0);
            doReceive(newname);
        }else if(strcmp("notexist",buffer)==0){
            std::cout<<"file cannot found! return"<<std::endl;
            return;
        }else{
            std::cout<<"unknown error! return"<<std::endl;
            return;
        }
    }
}

/**
 * 用于简单校验该类filename文件对象是否存在
 * @return true 文件存在 false 文件不存在
 */
bool Modectos::checkFileExist(const std::string &filename) {
    bool check = false;
    std::ifstream file;
    file.open(filename, std::ios::in);
    if (file) {
        check = true;
    }
    file.close();
    return check;
}

/**
 * 执行发送操作
 * @param filename
 */
void Modectos::doSend(const std::string &filename) {
    char name[strlen(filename.c_str())];  //文件名
    strcpy(name, filename.c_str());
    FILE *fp = fopen(name, "rb");  //以二进制方式打开文件
    char buffer[MAXLENGTH] = {0};  //缓冲区
    int nCount,packcount = 1;
    while ((nCount = fread(buffer, 1, MAXLENGTH, fp)) > 0) {
        send(Transmission::getClientSocket(), buffer, nCount, 0);
        std::cout << "pack No." << packcount++ << " size:" << nCount << std::endl;//传输过程反馈
    }
    shutdown(Transmission::getClientSocket(), SD_BOTH);
    std::cout << "transfer success" << std::endl;
    std::cin.getline(buffer, MAXLENGTH);
    fclose(fp);
    Transmission::getConnection(Getstruct::connectip, fnInttoString(Getstruct::connect));
}

/**
 * 执行接收操作
 * @param filename
 */
void Modectos::doReceive(const std::string &filename) {
    FILE *fp = fopen(filename.c_str(), "wb");//以二进制方式打开（创建）文件
    //循环接收数据，直到文件传输完毕
    char buffer[MAXLENGTH] = {0};  //文件缓冲区
    int nCount, packcount = 1;
    while ((nCount = recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0)) > 0) {
        fwrite(buffer, nCount, 1, fp);
        std::cout << "pack No." << packcount++ << " size:" << nCount << std::endl;//传输过程反馈
    }
    shutdown(Transmission::getClientSocket(), SD_BOTH);  //文件读取完毕，断开输出流，向客户端发送FIN包
    fclose(fp);
    std::cout << "transfer success" << std::endl;
    std::cin.getline(buffer, MAXLENGTH);
    Transmission::getConnection(Getstruct::connectip, fnInttoString(Getstruct::connect));
}

/**
 * 将整型转换为字符型
 * @param n 整型
 * @return 字符型
 */
std::string Modectos::fnInttoString(int n) {
    std::ostringstream stream;
    stream << n; //n为int类型
    return stream.str();
}

void Modectos::doShare(const std::vector<std::string>& commandparam){
    send(Transmission::getClientSocket(), "share", strlen("share") + sizeof(char), 0);
    char buffer[MAXLENGTH] = {0};  //文件缓冲区
    recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
    if(strcmp("sendfilename",buffer)==0){
        send(Transmission::getClientSocket(), commandparam[1].c_str(), strlen(commandparam[1].c_str()) + sizeof(char), 0);
        recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
        if(strcmp("friendname",buffer)==0){
            send(Transmission::getClientSocket(), commandparam[2].c_str(), strlen(commandparam[2].c_str()) + sizeof(char), 0);
        }
        recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
        if(strcmp("filenotexist",buffer)==0){
            std::cout<<"file not exist!"<<std::endl;
        }else if(strcmp("clientnotexist",buffer)==0){
            std::cout<<"client not exist!"<<std::endl;
        }else if(strcmp("successful",buffer)==0){
            std::cout<<"file shared successfully!"<<std::endl;
        }
    }
}

void Modectos::doRemove(const std::vector<std::string>& commandparam){
    send(Transmission::getClientSocket(), "remove", strlen("remove") + sizeof(char), 0);
    char buffer[MAXLENGTH] = {0};  //文件缓冲区
    recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
    if(strcmp("sendfilename",buffer)==0){
        send(Transmission::getClientSocket(), commandparam[1].c_str(), strlen(commandparam[1].c_str()) + sizeof(char), 0);
        recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
        if(strcmp("illegalfile",buffer)==0){
            std::cout<<"illegal filename!"<<std::endl;
        }else if(strcmp("filenotexist",buffer)==0){
            std::cout<<"file not exist!"<<std::endl;
        }else if(strcmp("successful",buffer)==0){
            std::cout<<"file removed successfully!"<<std::endl;
        }
    }
}