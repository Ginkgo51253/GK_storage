//
// Created by 24758 on 2020/5/24.
//

#include "../../stdafx.h"
#include "Modectoc.h"
#include "Transmission.h"
#include "Getstruct.h"

/**
 * 查看端口连接状态
 * 主要是看连接方是否有发送新的请求
 * @return
 */
int Modectoc::getRenew() {
    char buffer[MAXLENGTH] = {0};  //缓冲区
    int timeout = 1000;//将recv()的阻塞超时设置为1秒
    setsockopt(Transmission::getClientSocket(), SOL_SOCKET, SO_RCVTIMEO,
               reinterpret_cast<const char *>(&timeout), sizeof(timeout));
    int nCount = 0;
    nCount = recv(Transmission::getClientSocket(), buffer, MAXBYTE, 0);
    timeout = 0;//将recv()的超时设置为一直阻塞
    setsockopt(Transmission::getClientSocket(), SOL_SOCKET, SO_RCVTIMEO,
               reinterpret_cast<const char *>(&timeout), sizeof(timeout));
    if (nCount <= 0) {//从套接字获取不到信息
        std::cout << "nothing new" << std::endl;
        return 0;
    } else {//从套接字获取到信息（该信息由sendmsg/sendfile发送）
        if (!strcmp("sendfile", buffer)) {
            std::cout << "client is sending file" << std::endl;
            std::cout << "receive?[Y/N]" << std::endl;
            std::string answer;
            while (true) {
                std::cin >> answer;
                if ("Y" == answer || "y" == answer) {
                    char filename[MAXLENGTH] = {0};
                    std::cout << "input filename" << std::endl;
                    std::cin >> filename;
                    while (checkFileExist(filename)) {
                        std::cout << "file exist! (change another name)" << std::endl;
                        std::cin >> filename;
                    }
                    if (strlen(filename) > 0) {
                        send(Transmission::getClientSocket(), "Y", strlen("Y") + sizeof(char), 0);
                        doReceive(filename);
                    }
                    break;
                } else if ("N" == answer || "n" == answer) {
                    send(Transmission::getClientSocket(), "N", strlen("N") + sizeof(char), 0);
                    std::cin.getline(buffer,MAXLENGTH);
                    break;
                } else {
                    std::cout << "please enter[Y/N]" << std::endl;
                }
            }
            return 1;
        } else if (!strcmp("Fin_msg_from_client_Ginkgo_2020", buffer)) {//特殊终结字符
            Transmission::doShutdown();
            Getstruct::connect = 0;
            std::cout<<"client disconnected!"<<std::endl;
            return -1;
        }
    }
    return -1;
}

/**
 * 传输方准备发送文件
 * @param commandparam
 */
void Modectoc::getSendFile(std::vector<std::string> &commandparam) {
    if (!checkFileExist(commandparam[1])) {
        std::cout << "file cannot found! (check the path)" << std::endl;
        return;
    }
    char str[] = "sendfile";
    send(Transmission::getClientSocket(), str, strlen(str) + sizeof(char), 0);
    char buffer[MAXLENGTH] = {0};  //缓冲区
    recv(Transmission::getClientSocket(), buffer, MAXBYTE, 0);
    if (strcmp("Y", buffer) == 0) {
        doSend(commandparam[1]);
        return;
    } else if (strcmp("N", buffer) == 0) {
        std::cout << "client didn't receive" << std::endl;
        return;
    }
}

/**
 * 执行发送操作
 * @param filename
 */
void Modectoc::doSend(const std::string &filename) {
    char name[strlen(filename.c_str())];  //文件名
    strcpy(name, filename.c_str());
    FILE *fp = fopen(name, "rb");  //以二进制方式打开文件
    char buffer[MAXLENGTH] = {0};  //缓冲区
    int nCount;
    while ((nCount = fread(buffer, 1, MAXLENGTH, fp)) > 0) {
        send(Transmission::getClientSocket(), buffer, nCount, 0);
    }
    shutdown(Transmission::getClientSocket(), SD_BOTH);
    std::cout << "transfer success" << std::endl;
    fclose(fp);
    reConnect(Getstruct::beserver);
}

/**
 * 执行接收操作
 * @param filename
 */
void Modectoc::doReceive(const std::string &filename) {
    FILE *fp = fopen(filename.c_str(), "wb");//以二进制方式打开（创建）文件
    //循环接收数据，直到文件传输完毕
    char buffer[MAXLENGTH] = {0};  //文件缓冲区
    int nCount, packcount = 1;
    while ((nCount = recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0)) > 0) {
        fwrite(buffer, nCount, 1, fp);
        std::cout << "pack No." << packcount++ << " size:" << nCount << std::endl;//传输过程反馈
    }
    shutdown(Transmission::getClientSocket(), SD_BOTH);  //文件读取完毕，断开输出流，向客户端发送FIN包
    fclose(fp);
    std::cout << "transfer success" << std::endl;
    std::cin.getline(buffer, MAXLENGTH);
    reConnect(Getstruct::beserver);
}

/**
 * 用于简单校验该类filename文件对象是否存在
 * @return true 文件存在 false 文件不存在
 */
bool Modectoc::checkFileExist(const std::string &filename) {
    bool check = false;
    std::ifstream file;
    file.open(filename, std::ios::in);
    if (file) {
        check = true;
    }
    file.close();
    return check;
}

/**
 * 当传输完文件后
 * 传输连接关闭，此时重建即可
 * @param beserver 标注当前为作为服务器或客户端的参数
 */
void Modectoc::reConnect(const int beserver) {
    switch (beserver) {
        case 0:
            Transmission::getConnection(Getstruct::connectip, fnInttoString(Getstruct::connect));
            break;
        case 1:
            Transmission::getlisten();
            break;
        default:
            std::cout << "connect lost! (please reconnect)" << std::endl;
            break;
    }
}

/**
 * 将整型转换为字符型
 * @param n 整型
 * @return 字符型
 */
std::string Modectoc::fnInttoString(int n) {
    std::ostringstream stream;
    stream << n; //n为int类型
    return stream.str();
}