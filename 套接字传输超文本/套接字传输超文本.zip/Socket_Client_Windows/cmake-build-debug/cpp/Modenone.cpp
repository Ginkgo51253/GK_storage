//
// Created by 24758 on 2020/5/24.
//

#include "../../stdafx.h"
#include "Modenone.h"
#include "Transmission.h"
#include "Getstruct.h"

void Modenone::openSocket(std::vector<std::string> &commandparam) {
    if (Transmission::getSocket(commandparam[1], commandparam[2]) != 0) {
        std::cout << "failed to create socket! (port may be used)" << std::endl;
    } else {
        strcpy(Getstruct::portip, commandparam[1].c_str());
        Getstruct::port = atoi(commandparam[2].c_str());
        std::cout << "port open on " << Getstruct::port << std::endl;
    }
}

/**
 * 关闭当前主动开启的端口
 */
void Modenone::closeSocket() {
    Transmission::closeSocket();
    std::cout << "port " << Getstruct::port << " closed" << std::endl;
    Getstruct::port = 0;
}

/**
 * 连接到指定端口
 * @param commandparam 输入的IP与端口
 * @return 0 无连接 1 连接对象为客户 2 连接对象为服务器
 */
int Modenone::connetSocket(std::vector<std::string> &commandparam) {
    if (Transmission::getConnection(commandparam[1], commandparam[2]) != 0) {
        std::cout << "failed to connect!" << std::endl;
        return 0;
    } else {
        strcpy(Getstruct::connectip, commandparam[1].c_str());
        Getstruct::connect = atoi(commandparam[2].c_str());
        Getstruct::beserver = 0;
        std::cout << "connect to " << Getstruct::connect << std::endl;
        char szBuffer[6] = {0};
        recv(Transmission::getClientSocket(), szBuffer, MAXBYTE, 0);
        //比对接收到的数据
        if (!strcmp("client", szBuffer)) {//客户-客户连接
            std::cout << "it is a client!" << std::endl;
            return 1;
        } else if (!strcmp("server", szBuffer)) {//客户-服务器连接
            std::cout << "it is a server!" << std::endl;
            if(dologin()==0){
                return 2;
            }else{
                return 0;
            }
        } else {//未知连接,关闭客户连接使用套接字
            Transmission::doShutdown();
            return 0;
        }
    }
}

/**
 * 在当前开启的端口上开启监听
 * 0 连接成功 -1 连接失败
 */
int Modenone::waitSocket() {
    std::cout << "program start listening" << std::endl;
    int check = Transmission::getlisten();
    if (check == 0) {
        std::cout << "client found!" << std::endl;
        //向客户端发送数据
        char str[] = "client";
        send(Transmission::getClientSocket(), str, strlen(str) + sizeof(char), 0);
        strcpy(Getstruct::connectip, Getstruct::portip);
        Getstruct::connect = Getstruct::port;
        Getstruct::beserver = 1;
        return 0;
    } else {
        std::cout << "no port opened" << std::endl;
        std::cout << "listen stopped" << std::endl;
        return -1;
    }
}

/**
 * 连接服务器登录操作
 * @return
 */
int Modenone::dologin() {
    std::cout << "please login or create new account!" << std::endl;
    std::cout << "input 'login' or 'new'. ('back' to disconnect) " << std::endl;
    char strtemp[127]={0};
    std::cin.getline(strtemp,127);
    if (strcmp("login",strtemp)==0) {
        char buffer[MAXLENGTH] = {0};  //缓冲区
        while(strcmp("clientfound",buffer)!=0){
            send(Transmission::getClientSocket(), "login", strlen("login") + sizeof(char), 0);
            recv(Transmission::getClientSocket(), buffer, MAXBYTE, 0);
            if (strcmp("sendname",buffer)==0) {
                std::cout << "username:" << std::endl;
                char username[13]={0};
                std::cin.getline(username,13);
                send(Transmission::getClientSocket(), username, strlen(username) + sizeof(char), 0);
            }
            recv(Transmission::getClientSocket(), buffer, MAXBYTE, 0);
            if (strcmp("sendpasswd",buffer)==0) {
                std::cout << "password:" << std::endl;
                char password[13]={0};
                std::cin.getline(password,13);
                send(Transmission::getClientSocket(), password, strlen(password) + sizeof(char), 0);
            }
            recv(Transmission::getClientSocket(), buffer, MAXBYTE, 0);
            if(strcmp("noclientfound",buffer)==0){
                std::cout<<"username or password wrong!"<<std::endl;
            }
        }
        std::cout<<"login successful!"<<std::endl;
        return 0;
    } else if (strcmp("new",strtemp)==0) {
        char buffer[MAXLENGTH] = {0};  //缓冲区
        send(Transmission::getClientSocket(), "new", strlen("new") + sizeof(char), 0);
        recv(Transmission::getClientSocket(), buffer, MAXBYTE, 0);
        if (strcmp("sendname",buffer)==0) {
            std::cout << "new username:" << std::endl;
            char username[127] = {0};
            while(strlen(username)<1||strlen(username)>12||strchr(username,' ')!=nullptr){
                std::cout<<"No1.length of username should between 1-12 No2.username cannot contain space"<<std::endl;
                std::cin.getline(username, 127);
            }
            send(Transmission::getClientSocket(), username, strlen(username) + sizeof(char), 0);
        }
        recv(Transmission::getClientSocket(), buffer, MAXBYTE, 0);
        if (strcmp("sendpasswd",buffer)==0) {
            std::cout << "new password:" << std::endl;
            char password[127] = {0};
            while(strlen(password)<1||strlen(password)>12||strchr(password,' ')!=nullptr) {
                std::cout<<"No1.length of username should between 1-12 No2.username cannot contain space"<<std::endl;
                std::cin.getline(password, 127);
                send(Transmission::getClientSocket(), password, strlen(password) + sizeof(char), 0);
            }
        }
        std::cout<<"end of create account!"<<std::endl;
        dologin();
    } else if (strcmp("back",strtemp)==0){
        char str[] = "Fin_msg_from_client_Ginkgo_2020";
        send(Transmission::getClientSocket(), str, strlen(str)+sizeof(char), 0);
        Transmission::doShutdown();
        Getstruct::connect=0;
        return 1;
    }
    return -1;
}