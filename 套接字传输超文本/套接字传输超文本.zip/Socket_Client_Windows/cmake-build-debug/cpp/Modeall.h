//
// Created by 24758 on 2020/5/24.
//

#ifndef READFILE_MODEALL_H
#define READFILE_MODEALL_H


class Modeall {
public:
    static void getHelp();

    static void getstatus();

    static void disconnect();

    static void exitprogram();

};


#endif //READFILE_MODEALL_H
