//
// Created by 24758 on 2020/5/20.
//
#include "../../stdafx.h"
#include "Getstruct.h"

std::vector<std::string> Getstruct::commandparams;

int Getstruct::port;//服务器申请开启的端口

char* Getstruct::portip;//用于重建连接的ip记录

int Getstruct::connect;//实际投入使用的端口

char* Getstruct::connectip;//用于重建连接的ip记录

int Getstruct::beserver;//客户作为开启端口的一方

Getstruct::Getstruct() {
    //用户名与密码的字符长度应该小于等于12
    user_info.username = (char *) calloc(1, 13);
    user_info.password = (char *) calloc(1, 13);
    connectip = (char *)calloc(1,strlen("255.255.255.255"));
    portip = (char *)calloc(1,strlen("255.255.255.255"));
    wmode = none;
    port = 0;
    connect = 0;
    beserver = 0;
}