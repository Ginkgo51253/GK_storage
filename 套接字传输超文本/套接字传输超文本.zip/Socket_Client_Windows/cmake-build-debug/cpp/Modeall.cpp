//
// Created by 24758 on 2020/5/24.
//

#include "../../stdafx.h"
#include "Modeall.h"
#include "Getstruct.h"
#include "Transmission.h"

/**
 * 显示帮助
 * 调用后在标准输出设备输出指定文字
 * todo:编写帮助
 */
void Modeall::getHelp(){
    char buffer[]="Mode-all:\n"
                  "\thelp\t@get all commands.\n"
                  "\tstatus\t@get current status.\n"
                  "\texit\t@turn of the program.\n"
                  "\tdisconnect\t@cut of the connect between clients or client and server.\n"
                  "Mode-none:\n"
                  "\topen (string)ip (int)port\t@open a port on your pc.\n"
                  "\tclose\t@close the port that you opened.\n"
                  "\tconnect(string)ip (int)port\t@connect to a client or server.\n"
                  "\twait\t@after open a port,start waiting for client's connection.\n"
                  "Mode-ctoc(Client to Client):\n"
                  "\tsendfile (string)filename\t@send a file to the other\n"
                  "\trenew\t@check the movement of the client on the port\n"
                  "Mode-ctos(Client to Server):\n"
                  "\tlist\t@show all files under your name\n"
                  "\tfriends\t@show all clients on the server\n"
                  "\tupload (string)filename\t@upload a file to server\n"
                  "\tdownload (string)filename\t@download a file from sever\n"
                  "\tshare (string)filename (string)friend'sname\t@share a file to a friend\n"
                  "\tremove (string)filename\t@remove a file under your name\n"
                  ;
    std::cout<<buffer<<std::endl;
}

/**
 * 显示本进程开启的端口
 * 调用后在标准输出设备输出指定文字
 */
void Modeall::getstatus(){
    std::cout<<"port:"<<Getstruct::port<<"  "<<"connection:"<<Getstruct::connect<<std::endl;
}

/**
 * 断开本程序与目标设备端口的连接
 * 如果没有连接则不执行操作
 * 断开连接后不影响套接字
 */
void Modeall::disconnect(){
    if(Getstruct::connect==0){
        std::cout<<"No connect right now!"<<std::endl;
        return;
    }else{
        //向对方发送数据
        char str[] = "Fin_msg_from_client_Ginkgo_2020";
        send(Transmission::getClientSocket(), str, strlen(str)+sizeof(char), 0);
        Transmission::doShutdown();
        Getstruct::connect=0;
        std::cout<<"disconnect!"<<std::endl;
    }
}

void Modeall::exitprogram(){
    std::string answer;
    std::cout<<"exit?[Y/N]"<<std::endl;
    while(true){
        std::cin>>answer;
        if("Y"==answer||"y"==answer){
            exit(0);
        }else if("N"==answer||"n"==answer){
            char buffer[MAXLENGTH]={0};
            std::cin.getline(buffer,MAXLENGTH);
            return;
        }else{
            std::cout<<"please enter[Y/N]"<<std::endl;
        }
    }

}