//
// Created by 24758 on 2020/5/27.
//

#ifndef SOCKET_CLIENT_WINDOWS_MODECTOS_H
#define SOCKET_CLIENT_WINDOWS_MODECTOS_H


class Modectos {
public:
    static void doList();

    static void doFriends();

    static void doUpload(const std::string& filename);

    static void doDownload(const std::string& filename);

    static bool checkFileExist(const std::string &filename);

    static std::string fnInttoString(int n);

    static void doReceive(const std::string &filename);

    static void doSend(const std::string &filename);

    static void doShare(const std::vector<std::string>& commandparam);

    static void doRemove(const std::vector<std::string>& commandparam);
};


#endif //SOCKET_CLIENT_WINDOWS_MODECTOS_H
