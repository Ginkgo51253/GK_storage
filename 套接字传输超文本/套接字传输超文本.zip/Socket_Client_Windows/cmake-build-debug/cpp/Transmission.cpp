//
// Created by 24758 on 2020/5/24.
//

#include "../../stdafx.h"
#include "Transmission.h"

/**
 * windows需要加载DLL
 */
Transmission::Transmission() {
    //初始化 DLL
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);
}

/**
 * windows需要回收DLL的使用
 */
Transmission::~Transmission() {
    //终止 DLL 的使用
    WSACleanup();
}

SOCKET Transmission::servSock;//用户作为服务器申请的套接字
SOCKADDR Transmission::clntaddr;//服务器为访客声明的地址信息
SOCKET Transmission::clntSock;//服务器为访客声明的套接字;也是用户作为客户申请的套接字

/**
 * 获取一个Socket连接
 * @param ip 指定IP地址
 * @param port 指定端口
 * @return 0 创建和绑定成功 -1 创建或绑定失败
 */
int Transmission::getSocket(const std::string &ip, const std::string &port) {
    //创建套接字设置模式为TCP流式连接，使用TCP协议
    servSock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    //绑定套接字
    sockaddr_in sockAddr{};
    memset(&sockAddr, 0, sizeof(sockAddr));  //每个字节都用0填充
    sockAddr.sin_family = PF_INET;  //使用IPv4地址
    sockAddr.sin_addr.s_addr = inet_addr(ip.c_str());  //具体的IP地址
    sockAddr.sin_port = htons(atoi(port.c_str()));  //端口
    return bind(servSock, (SOCKADDR *) &sockAddr, sizeof(SOCKADDR));
}

/**
 * 关闭套接字
 */
void Transmission::closeSocket() {
    closesocket(servSock);
}

/**
 * 生成一个客户端socket
 * 用于连接到目标端口
 * （当端口存在socket正在listen时即可连接成功，但不清楚对方是何程序）
 * @param ip 指定IP地址
 * @param port 指定端口
 * @return 0 连接成功 -1 连接失败
 */
int Transmission::getConnection(const std::string &ip, const std::string &port) {
    //创建套接字
    clntSock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    //向服务器发起请求
    sockaddr_in sockAddr{};
    memset(&sockAddr, 0, sizeof(sockAddr));  //每个字节都用0填充
    sockAddr.sin_family = PF_INET;
    sockAddr.sin_addr.s_addr = inet_addr(ip.c_str());
    sockAddr.sin_port = htons(atoi(port.c_str()));
    return connect(clntSock, (SOCKADDR *) &sockAddr, sizeof(SOCKADDR));
}

/**
 * 让服务器在指定端口开启监听
 * @return 0 接收到接收方 -1 接收出现异常
 */
int Transmission::getlisten() {
    //进入监听状态
    listen(servSock, 20);
    //接收客户端请求
    int nSize = sizeof(SOCKADDR);
    clntSock = accept(servSock, (SOCKADDR *) &clntaddr, &nSize);
    if (clntSock != -1)
        return 0;
    else
        return -1;
}

/**
 * 关闭用于传输信息的套接字
 */
void Transmission::doShutdown() {
    shutdown(clntSock, 2);//先断开连接
    closesocket(clntSock);//然后回收客户连接使用的套接字
}

/**
 * 获取传输使用的客户套接字
 * @return 返回私有套接字参数clntSock
 */
SOCKET Transmission::getClientSocket() {
    return clntSock;
}

