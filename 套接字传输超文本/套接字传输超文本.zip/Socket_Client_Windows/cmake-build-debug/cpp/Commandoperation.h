//
// Created by 24758 on 2020/5/23.
//

#ifndef READFILE_COMMANDOPERATION_H
#define READFILE_COMMANDOPERATION_H

class Commandoperation {
private:
    static bool commandfound;
public:
    Commandoperation();

    static void getCommandParam(const char *str, std::vector<std::string> &commandparam);

    static int isNum(const char *str);

    static int doCommand(std::vector<std::string> &commandparam);
};


#endif //READFILE_COMMANDOPERATION_H
