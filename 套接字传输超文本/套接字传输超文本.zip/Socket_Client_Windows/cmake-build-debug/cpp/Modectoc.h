//
// Created by 24758 on 2020/5/24.
//

#ifndef SOCKET_CLIENT_WINDOWS_MODECTOC_H
#define SOCKET_CLIENT_WINDOWS_MODECTOC_H


class Modectoc {
public:
    static int getRenew();

    static void getSendFile(std::vector<std::string> &commandparam);

    static bool checkFileExist(const std::string &filename);

    static void doSend(const std::string &filename);

    static void doReceive(const std::string &filename);

    static std::string fnInttoString(int n);

    static void reConnect(const int beserver);
};


#endif //SOCKET_CLIENT_WINDOWS_MODECTOC_H
