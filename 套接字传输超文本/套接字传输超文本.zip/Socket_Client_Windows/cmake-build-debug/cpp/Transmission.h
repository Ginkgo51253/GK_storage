//
// Created by 24758 on 2020/5/24.
//

#ifndef SOCKET_CLIENT_WINDOWS_TRANSMISSION_H
#define SOCKET_CLIENT_WINDOWS_TRANSMISSION_H


class Transmission {
private:
    static SOCKET servSock;
    static SOCKADDR clntaddr;
    static SOCKET clntSock;
public:
    Transmission();

    ~Transmission();

    static int getSocket(const std::string &ip, const std::string &port);

    static void closeSocket();

    static int getConnection(const std::string &ip, const std::string &port);

    static int getlisten();

    static void doShutdown();

    static SOCKET getClientSocket();
};


#endif //SOCKET_CLIENT_WINDOWS_TRANSMISSION_H
