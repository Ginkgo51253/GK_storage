//
// Created by 24758 on 2020/5/27.
//

#ifndef SOCKET_SERVER_LINUX_HEADER_H
#define SOCKET_SERVER_LINUX_HEADER_H

#include "cmake-build-debug/cpp/Getstruct.h"
#include "cmake-build-debug/cpp/Filemanagement.h"
#include "cmake-build-debug/cpp/Fileoperation.h"
#include "cmake-build-debug/cpp/Getfile.h"
#include "cmake-build-debug/cpp/Transmission.h"
Getstruct getstruct{};

#endif //SOCKET_SERVER_LINUX_HEADER_H
