#include "stdafx.h"
#include "cmake-build-debug/cpp/Commandoperation.h"
#include "cmake-build-debug/cpp/Getstruct.h"

int main() {
    Commandoperation commandoperation{};
    std::cout<<"waiting for input"<<std::endl;
    char input[MAXLENGTH] = {0};
    while(strcmp("Ginkgo",input) != 0){
        std::cin.getline(input,MAXLENGTH);
        Commandoperation::doCommand(input);
    }
    return 0;
}
