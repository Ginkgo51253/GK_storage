//
// Created by 24758 on 2020/5/20.
//
#include "../../stdafx.h"
#include "Getstruct.h"

std::vector<std::string> Getstruct::commandparams;//需要程序进行处理的输入变量

std::vector<std::string> Getstruct::answerparams;//需要用户进行查看的字符常量

std::string Getstruct::answerstring;

int Getstruct::port;//服务器申请开启的端口

char* Getstruct::portip;//用于重建连接的ip记录

int Getstruct::connect;//实际投入使用的端口

char* Getstruct::connectip;//用于重建连接的ip记录

int Getstruct::beserver;//客户作为开启端口的一方

char* Getstruct::workroute;//服务器读取文件的默认路径

Getstruct::Getstruct() {
    //用户名与密码的字符长度应该小于等于12
    user_info.username = (char *) calloc(1, 13);
    user_info.password = (char *) calloc(1, 13);
    connectip = (char *)calloc(1,strlen("255.255.255.255"));
    portip = (char *)calloc(1,strlen("255.255.255.255"));
    workroute = (char *)calloc(1,MAXLENGTH);
    port = 0;
    connect = 0;
    beserver = 0;
}