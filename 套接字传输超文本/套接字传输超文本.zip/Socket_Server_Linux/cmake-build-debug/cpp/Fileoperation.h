//
// Created by 24758 on 2020/5/19.
//

#ifndef READFILE_FILEOPERATION_H
#define READFILE_FILEOPERATION_H


class Fileoperation {
private:

public:
    static void readLineData(const char *fileName, int lineNum, char *data);

    static void readLineData(const char *fileName, int lineNum, char *data,int length);

    static void delLineData(const char *fileName, int lineNum);

    static void modifyLineData(const char *fileName, int lineNum, const char *lineData);

    static void divideLineData(const char *lineData, char *data1, char *data2);

    static void divideLineData(const char *lineData, int length, char *data1, char *data2);

    static bool clientExist(const char *fileName, const char *username);

    static bool clientExist(const char *fileName, const char *username, const char *password);

    static void getClientName(const char *fileName, char *str);

    static int getFileLength(const char *fileName);
};


#endif //READFILE_FILEOPERATION_H
