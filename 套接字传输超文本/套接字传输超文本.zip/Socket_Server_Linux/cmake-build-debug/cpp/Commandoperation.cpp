//
// Created by 24758 on 2020/5/27.
//
#include "../../stdafx.h"
#include "../../header.h"
#include "Commandoperation.h"

bool Commandoperation::commandfound;

/**
 * 读取当前目录下的workroute文件，指定工作目录
 */
Commandoperation::Commandoperation() {
    basicSetting();
    portStartUp();
    std::cout << "program ready!" << std::endl;
}

Commandoperation::~Commandoperation() {
    Transmission::closeSocket();
}

/**
 * 基础设置
 * 切换工作目录，创建缺失的文件等
 */
void Commandoperation::basicSetting() {
    if (!Filemanagement::dirExist(".", "workroute")) {
        std::cout << "no 'workroute'! new 'workroute' created!" << std::endl;
        Filemanagement::createFile("./", "workroute");
    }
    Fileoperation::readLineData("workroute", 1, getstruct.workroute, 1024);
    while (!Filemanagement::dirExist(getstruct.workroute, "") ||
           strlen(getstruct.workroute) < 1) {
        std::cout << "renew route! (route cannot found)" << std::endl;
        std::cin.getline(getstruct.workroute, 1024);
        std::ofstream out;
        out.open("workroute", std::ios::trunc | std::ios::out);
        out.flush();
        out << getstruct.workroute;
        out.close();
    }
    std::cout << "path found! change to " << getstruct.workroute << std::endl;
    Filemanagement::setPath(getstruct.workroute);
    if (!Filemanagement::dirExist(getstruct.workroute, "user")) {
        std::cout << "no 'user'! new 'user' created!" << std::endl;
        Filemanagement::createFile("./", "user");
    }
    if (!Filemanagement::dirExist(getstruct.workroute, "conf")) {
        std::cout << "no 'conf'! new 'conf' created!" << std::endl;
        Filemanagement::createFile("./", "conf");
    }
}

/**
 * 服务器端自动开启端口
 */
void Commandoperation::portStartUp() {
    char strtemp[strlen("255.255.255.255 65535")] = {0};
    Fileoperation::readLineData("conf", 1, strtemp, 1024);
    char strip[strlen("255.255.255.255")] = {0};
    char strport[strlen("65535")];
    Fileoperation::divideLineData(strtemp, strlen("255.255.255.255 65535"), strip, strport);
    strcpy(getstruct.portip, strip);
    getstruct.port = atoi(strport);
    while (Transmission::getSocket(strip, strport)) {
        std::cout << "cannot read ip&port, input '(string)ip (int)port'" << std::endl;
        std::cin.getline(strtemp, strlen("255.255.255.255 65535"));
        Fileoperation::divideLineData(strtemp, strlen("255.255.255.255 65535"), strip, strport);
        strcpy(getstruct.portip, strip);
        getstruct.port = atoi(strport);
    }
    std::cout << "port open on:" << getstruct.port << std::endl;
}

void Commandoperation::doCommand(char *commandstr) {
    if (strcmp("exit", commandstr) == 0) {
        commandfound = true;
        std::cout << "program exit?[Y/N]" << std::endl;
        std::string answer;
        while (true) {
            std::cin >> answer;
            if ("Y" == answer || "y" == answer) {
                exit(0);
            } else if ("N" == answer || "n" == answer) {
                return;
            } else {
                std::cout << "please enter[Y/N]" << std::endl;
            }
        }
    }
    if (strcmp("wait", commandstr) == 0) {
        commandfound = true;
        if(waitSocket()==0){
            doClientCommand();
        }else{
            std::cout<<"something wrong with socket connection. program return"<<std::endl;
            return;
        }
    }
    if (strcmp("daemon",commandstr)==0){
        commandfound = true;
        initDeamon();
        if(waitSocket()==0){
            doClientCommand();
        }else{
            exit(1);
        }
    }
    if (strcmp("Ginkgo", commandstr) == 0) {//特殊终结字符
        commandfound = true;
        std::cout << "hello author!" << std::endl;
    }
    if (!commandfound) {//命令语句输入错误，提示输入help获取帮助
        std::cout << "input command not found! enter 'help' for info." << std::endl;
    }
}

/**
 * 罗列当前路径下的所有文件
 */
void Commandoperation::listAllFiles() {
    Filemanagement::reviewAllFiles(".", getstruct.answerparams);
    getStringAnswer(getstruct.answerparams, getstruct.answerstring);
    std::cout << getstruct.answerstring << std::endl;
}

/**
 * 将存放在容器中的字符串连接成为一个字符串
 * 方便输出
 * @param answerparams
 * @param answerstring
 */
void Commandoperation::getStringAnswer(std::vector<std::string> &answerparams, std::string &answerstring) {
    answerstring = "";
    for (const auto &answerparam : answerparams) {
        answerstring.append(answerparam);
        answerstring.append("\n");
    }
}

/**
 * 罗列所有用户
 */
void Commandoperation::listAllFriends() {
    char str[MAXLENGTH] = {0};
    Fileoperation::getClientName("user", str);
    std::cout << str << std::endl;
}

/**
 * 设置工作路径
 */
void Commandoperation::setWorkingRoute(char *route) {
    if (!strcmp("default", route)) {//切换到默认路径
        Filemanagement::setPath(getstruct.workroute);
    } else {//切换到指定用户目录下
        Filemanagement::setPath(route);
    }
}

/**
 * let program start listening
 * @return 0 success -1 failure
 */
int Commandoperation::waitSocket() {
    std::cout << "program start listening" << std::endl;
    int check = Transmission::getlisten();
    if (check == 0) {
        std::cout << "client found!" << std::endl;
        //向客户端发送数据
        char str[] = "server";
        send(Transmission::getClientSocket(), str, strlen(str) + sizeof(char), 0);
        strcpy(Getstruct::connectip, Getstruct::portip);
        Getstruct::connect = Getstruct::port;
        Getstruct::beserver = 1;
        return 0;
    } else {
        std::cout << "no port opened" << std::endl;
        std::cout << "listen stopped" << std::endl;
        return -1;
    }
}

void Commandoperation::doClientCommand(){
    static char buffer[MAXLENGTH] = {0};  //缓冲区
    static char str[MAXLENGTH] = {0};
    while(strcmp("exit",buffer)!=0){
        recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
        if(strcmp("login",buffer)==0){
            strcpy(str,"sendname");
            send(Transmission::getClientSocket(), str, strlen(str) + sizeof(char), 0);
            recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
            char username[13]={0};
            strcpy(username,buffer);
            strcpy(str,"sendpasswd");
            send(Transmission::getClientSocket(), str, strlen(str) + sizeof(char), 0);
            recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
            char password[13]={0};
            strcpy(password,buffer);
            if(Fileoperation::clientExist("user", username,password)){
                strcpy(str,"clientfound");
                send(Transmission::getClientSocket(), str, strlen(str) + sizeof(char), 0);
                Filemanagement::setPath(username);
            }else{
                strcpy(str,"noclientfound");
                send(Transmission::getClientSocket(), str, strlen(str) + sizeof(char), 0);
            }
        }
        if(strcmp("new",buffer)==0){
            strcpy(str,"sendname");
            send(Transmission::getClientSocket(), str, strlen(str) + sizeof(char), 0);
            recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
            char username[13]={0};
            strcpy(username,buffer);
            strcpy(str,"sendpasswd");
            send(Transmission::getClientSocket(), str, strlen(str) + sizeof(char), 0);
            recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
            char password[13]={0};
            strcpy(password,buffer);
            std::ofstream out;
            out.open("user", std::ios::app);
            out.flush();
            out << username << " " << password << " \n";
            out.close();
            Filemanagement::createDir(".",username);
        }
        if(strcmp("list",buffer)==0){
            Filemanagement::reviewAllFiles(".",Getstruct::answerparams);
            getStringAnswer(Getstruct::answerparams,Getstruct::answerstring);
            strcpy(str,Getstruct::answerstring.c_str());
            send(Transmission::getClientSocket(), str, strlen(str) + sizeof(char), 0);
            Getstruct::answerparams.clear();
            Getstruct::answerstring.clear();
        }
        if(strcmp("friends",buffer)==0){
            Fileoperation::getClientName("../user",str);
            send(Transmission::getClientSocket(), str, strlen(str) + sizeof(char), 0);
        }
        if(strcmp("upload",buffer)==0){
            doReceive();
        }
        if(strcmp("download",buffer)==0){
            doSend();
        }
        if(strcmp("share",buffer)==0){
            doShare();
        }
        if(strcmp("remove",buffer)==0){
            doRemove();
        }
        if(strcmp("Fin_msg_from_client_Ginkgo_2020",buffer)==0){
            Transmission::doShutdown();
            Filemanagement::setPath(getstruct.workroute);
            waitSocket();
        }
        strcpy(str,"");
        strcpy(buffer,"");
    }
}

void Commandoperation::doReceive(){
    send(Transmission::getClientSocket(), "sendname", strlen("sendname") + sizeof(char), 0);
    char buffer[MAXLENGTH] = {0};  //缓冲区
    recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
    std::string filename=buffer;
    if(Filemanagement::dirExist(".",filename.c_str())){
        send(Transmission::getClientSocket(), "exist", strlen("exist") + sizeof(char), 0);
    }else{
        send(Transmission::getClientSocket(), "sendfile", strlen("sendfile") + sizeof(char), 0);
        doServerReceive(filename);
    }
}

void Commandoperation::doSend(){
    send(Transmission::getClientSocket(), "sendname", strlen("sendname") + sizeof(char), 0);
    char buffer[MAXLENGTH] = {0};  //缓冲区
    recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
    std::string filename=buffer;
    if(Filemanagement::dirExist(".",filename.c_str())){
        send(Transmission::getClientSocket(), "setname", strlen("setname") + sizeof(char), 0);
        recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
        if(strcmp("sendfile",buffer)==0){
            doServerSend(filename);
        }
    }else{
        send(Transmission::getClientSocket(), "notexist", strlen("notexist") + sizeof(char), 0);
    }
}

/**
 * 执行发送操作
 * @param filename
 */
void Commandoperation::doServerSend(const std::string &filename) {
    char name[strlen(filename.c_str())];  //文件名
    strcpy(name, filename.c_str());
    FILE *fp = fopen(name, "rb");  //以二进制方式打开文件
    char buffer[MAXLENGTH] = {0};  //缓冲区
    int nCount;
    while ((nCount = fread(buffer, 1, MAXLENGTH, fp)) > 0) {
        send(Transmission::getClientSocket(), buffer, nCount, 0);
    }
    std::cout << "transfer success" << std::endl;
    shutdown(Transmission::getClientSocket(), SHUT_RDWR);
    Transmission::getlisten();
}

/**
 * 执行接收操作
 * @param filename
 */
void Commandoperation::doServerReceive(const std::string &filename) {
    FILE *fp = fopen(filename.c_str(), "wb");//以二进制方式打开（创建）文件
    //循环接收数据，直到文件传输完毕
    char buffer[MAXLENGTH] = {0};  //文件缓冲区
    int nCount;
    while ((nCount = recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0)) > 0) {
        fwrite(buffer, nCount, 1, fp);
    }
    shutdown(Transmission::getClientSocket(), SHUT_RDWR);  //文件读取完毕，断开输出流，向客户端发送FIN包
    fclose(fp);
    std::cout << "transfer success" << std::endl;
    Transmission::getlisten();
}

void Commandoperation::doShare(){
    char buffer[MAXLENGTH] = {0};  //文件缓冲区
    send(Transmission::getClientSocket(), "sendfilename", strlen("sendfilename") + sizeof(char), 0);
    recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
    char filename[63]={0};
    strcpy(filename,buffer);
    send(Transmission::getClientSocket(), "friendname", strlen("friendname") + sizeof(char), 0);
    recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
    char friendname[13]={0};
    strcpy(friendname,buffer);
    if(!Filemanagement::dirExist(".",filename)){
        send(Transmission::getClientSocket(), "filenotexist", strlen("filenotexist") + sizeof(char), 0);
        return;
    }
    if(!Fileoperation::clientExist("../user",friendname)){
        send(Transmission::getClientSocket(), "clientnotexist", strlen("clientnotexist") + sizeof(char), 0);
        return;
    }
    std::string command="cp ";
    command.append(filename);
    command.append(" ../");
    command.append(friendname);
    system(command.c_str());
    send(Transmission::getClientSocket(), "successful", strlen("successful") + sizeof(char), 0);
}

void Commandoperation::doRemove(){
    char buffer[MAXLENGTH] = {0};  //文件缓冲区
    send(Transmission::getClientSocket(), "sendfilename", strlen("sendfilename") + sizeof(char), 0);
    recv(Transmission::getClientSocket(), buffer, MAXLENGTH, 0);
    char filename[63]={0};
    strcpy(filename,buffer);
    if(strchr(filename,'*')!= nullptr&&strchr(filename,'/')&&strchr(filename,'~')){
        send(Transmission::getClientSocket(), "illegalfile", strlen("illegalfile") + sizeof(char), 0);
        return;
    }
    if(!Filemanagement::dirExist(".",filename)){
        send(Transmission::getClientSocket(), "filenotexist", strlen("filenotexist") + sizeof(char), 0);
        return;
    }
    std::string command="rm -rf ";
    command.append(filename);
    system(command.c_str());
    send(Transmission::getClientSocket(), "successful", strlen("successful") + sizeof(char), 0);
}

/**
 * 启动守护进程
 */
void Commandoperation::initDeamon(){
    int pid;
    int i;

    // 1）屏蔽一些控制终端操作的信号  
    signal(SIGTTOU,SIG_IGN);
    signal(SIGTTIN,SIG_IGN);
    signal(SIGTSTP,SIG_IGN);
    signal(SIGHUP,SIG_IGN);

    // 2）在后台运行  
    pid = fork();
    if(pid){// 父进程  
        exit(0);//结束父进程，子进程继续  
    }else if(pid<0){// 出错  
        perror("fork");
        exit(EXIT_FAILURE);
    }

    // 3）脱离控制终端、登录会话和进程组  
    setsid();

    // 4）禁止进程重新打开控制终端  
    pid = fork();
    if(pid){// 父进程  
        exit(0);    // 结束第一子进程，第二子进程继续（第二子进程不再是会话组长）   
     }else if(pid<0){// 出错  
        perror("fork");
        exit(EXIT_FAILURE);
    }

    // 5）关闭标准输出
    close(1);

    // 6）设置当前工作目录  
    //chdir("./");

    // 7）重设文件创建掩码
    umask(0);

    // 8）处理 SIGCHLD 信号  
    signal(SIGCHLD,SIG_IGN);
}