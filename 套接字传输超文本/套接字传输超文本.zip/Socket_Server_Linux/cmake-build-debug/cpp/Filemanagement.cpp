//
// Created by 24758 on 2020/5/21.
//
/**
 * 本段函数库文件依赖
 * #include<vector> #include<afxres.h> #include<direct.h> #include<fstream>
 */
#include "../../stdafx.h"
#include "Filemanagement.h"
#include "Getstruct.h"

Filemanagement::Filemanagement()= default;

/**
 * 在指定目录下创建指定名称的文件夹
 * @param path 指定目录名称
 * @param fileName 指定文件名称
 * @return 0成功，1已存在，-1建立失败
 */
int Filemanagement::createDir(const char *path, const char *fileName) {
    char folderPath[strlen(path)+strlen(fileName)];
    strcpy(folderPath,path);
    strcat(folderPath,"/");
    strcat(folderPath,fileName);
    if (0 != access(folderPath, 0)) {
        return mkdir(folderPath,S_IRWXU|S_IRWXG);//换成 ::_mkdir  ::_access 也行，不知道什么意思
    }else{
        return 1;
    }
}

/**
 * 用于检测文件是否存在
 * @param path 目录路径
 * @param fileName 文件名称，如果不需要则输入""
 * @return 0 不存在 1 存在
 */
bool Filemanagement::dirExist(const char *path, const char *fileName){
    char folderPath[strlen(path)+strlen(fileName)];
    strcpy(folderPath,path);
    strcat(folderPath,"/");
    strcat(folderPath,fileName);
    return 0 == access(folderPath, 0);
}

/**
 * 在指定路径下创建一个指定文件
 * @param path 路径名
 * @param fileName 文件名
 * @return 0 文件存在或正常创建 -1 创建错误
 */
int Filemanagement::createFile(const char *path, const char *fileName){
    char folderPath[strlen(path)+strlen(fileName)];
    strcpy(folderPath,path);
    strcat(folderPath,"/");
    strcat(folderPath,fileName);
    std::ifstream file;
    file.open(folderPath, std::ios::in|std::ios::app );
    if(!file){
        return -1;
    }
    file.close();
    return 0;
}

/**
 * 浏览指定目录下的全部文件
 * @param path 指定目录名
 * @param files 用来存放文件信息的字符串容器
 */
void Filemanagement::reviewAllFiles(const std::string& path,std::vector<std::string>& files)
{
    if (path.empty()) { return; } //字符串判断

    const int iRecursiveTimes = 3;      //目标递归层数
    static int s_iRecursiveTimes = 0;   //当前递归层数

    //文件夹判断
    struct stat stFolderStat{};
    stat(path.c_str(), &stFolderStat);
    if (!S_ISDIR(stFolderStat.st_mode)) { return; }

    DIR* open_dir = opendir(path.c_str());
    if (NULL == open_dir) { return; }   //打开失败

    dirent* pDirent = nullptr;
    while( (pDirent = readdir(open_dir)) != nullptr) {
        struct stat stFileStata{};
        if (pDirent->d_name[0] != '.') {
            std::string name = path+std::string("/")+std::string(pDirent->d_name);
            stat(name.c_str(), &stFileStata);

            if (S_ISDIR(stFileStata.st_mode)) {//是目录就进行递归
                if(iRecursiveTimes == s_iRecursiveTimes) { continue; }
                else{ s_iRecursiveTimes++; }
                reviewAllFiles(name,files);
                s_iRecursiveTimes--;
            }
            else if (S_ISREG(stFileStata.st_mode)) {
                files.push_back(name);
            }
        }
    }
    closedir(open_dir);
}

/**
 * 设置当前操作路径
 * @param path 路径名
 * @return 0 设置成功 -1 设置失败并将默认路径作为设置路径
 */
int Filemanagement::setPath(const char *path){
    if(Filemanagement::dirExist(path,"")){
        chdir(path);
        return 0;
    }
    chdir(Getstruct::workroute);
    return -1;
}

