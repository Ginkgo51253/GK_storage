//
// Created by 24758 on 2020/5/27.
//

#ifndef SOCKET_SERVER_LINUX_COMMANDOPERATION_H
#define SOCKET_SERVER_LINUX_COMMANDOPERATION_H


class Commandoperation {
private:
    static bool commandfound;
public:
    Commandoperation();
    ~Commandoperation();

    static void getStringAnswer(std::vector<std::string> &answerparams, std::string &answerstring);

    static void listAllFiles();

    static void listAllFriends();

    static void setWorkingRoute(char *route);

    static void basicSetting();

    static void portStartUp();

    static void doCommand(char *commandstr);

    static int waitSocket();

    static void doClientCommand();

    static void doReceive();

    static void doSend();

    static void doServerReceive(const std::string &filename);

    static void doServerSend(const std::string &filename);

    static void doShare();

    static void doRemove();

    static void initDeamon();
};


#endif //SOCKET_SERVER_LINUX_COMMANDOPERATION_H
