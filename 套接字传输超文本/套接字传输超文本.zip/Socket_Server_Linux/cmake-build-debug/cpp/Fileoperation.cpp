//
// Created by 24758 on 2020/5/19.
//
/**
 * 本段函数库文件依赖
 * #include<fstream>
 */
#include "../../stdafx.h"
#include "Fileoperation.h"

/**
 * 指定长度地通过行遍历获取当前行全部字符
 * @param fileName 文件名
 * @param lineNum 指定行
 * @param data 取出改行所有文本内容置于该对象中
 */
void Fileoperation::readLineData(const char *fileName, int lineNum, char *data,const int length) {
    std::ifstream in;
    in.open(fileName);
    int line = 1;
    while (in.getline(data, length)) {
        if (lineNum == line) {
            break;
        }
        line++;
    }
    in.close();
}

/**
 * 通过行遍历获取当前行全部字符
 * @param fileName 文件名
 * @param lineNum 指定行
 * @param data 取出改行所有文本内容置于该对象中
 */
void Fileoperation::readLineData(const char *fileName, int lineNum, char *data) {
    std::ifstream in;
    in.open(fileName);
    int line = 1;
    while (in.getline(data, 26)) {
        if (lineNum == line) {
            break;
        }
        line++;
    }
    in.close();
}

/**
 * 字符串加法
 * @param contentChar
 * @return
 */
std::string charToStr(const char *contentChar) {
    std::string tempStr;
    for (int i = 0; contentChar[i] != '\0'; i++) {
        tempStr += contentChar[i];
    }
    return tempStr;
}

/**
 * 删除一行数据，所有行数据需要读取和重写
 * @param fileName 文件名
 * @param lineNum 指定行
 */
void Fileoperation::delLineData(const char *fileName, int lineNum) {
    std::ifstream in;
    in.open(fileName);
    std::string strFileData;
    int line = 1;
    char lineData[26] = {0};
    while (in.getline(lineData, sizeof(lineData))) {
        if (line == lineNum) {
            strFileData += "\n";
        } else {
            strFileData += charToStr(lineData);
            strFileData += "\n";
        }
        line++;
    }
    in.close();    //写入文件
    std::ofstream out;
    out.open(fileName);
    out.flush();
    out << strFileData;
    out.close();
}

/**
 * 自定义写入的数据，所有行数据进行重写
 * @param fileName 文件名
 * @param lineNum 指定行
 * @param lineData 添加的文本内容
 */
void Fileoperation::modifyLineData(const char *fileName, int lineNum, const char *lineData) {
    std::ifstream in;
    in.open(fileName);
    std::string strFileData;
    int line = 1;
    char tmpLineData[26] = {0};
    while (in.getline(tmpLineData, sizeof(tmpLineData))) {
        if (line == lineNum) {
            strFileData += charToStr(lineData);
            strFileData += "\n";
        } else {
            strFileData += charToStr(tmpLineData);
            strFileData += "\n";
        }
        line++;
    }
    in.close();    //写入文件
    std::ofstream out;
    out.open(fileName);
    out.flush();
    out << strFileData;
    out.close();
}

/**
 * 将特定规则的每行数据分割为两部分
 * 本例中分割为用户名 密码
 * @param lineData 行数据
 * @param data1 用户名
 * @param data2 密码
 */
void Fileoperation::divideLineData(const char *lineData, char *data1, char *data2) {
    char *temp = (char *) calloc(1, 26);
    strcpy(temp, lineData);
    temp = strtok(temp, " ");
    strcpy(data1, temp);
    temp = strtok(nullptr, " ");
    strcpy(data2, temp);
}

/**
 * 将特定规则的每行数据分割为两部分
 * @param lineData 行数据
 * @param data1 数据1
 * @param data2 数据2
 */
void Fileoperation::divideLineData(const char *lineData,int length, char *data1, char *data2) {
    char *temp = (char *) calloc(1, length);
    strcpy(temp, lineData);
    temp = strtok(temp, " ");
    strcpy(data1, temp);
    temp = strtok(nullptr, " ");
    strcpy(data2, temp);
}

/**
 * 这是一个重载函数
 * 打开按照格式书写的用户列表
 * 用于检测用户名是否已经存在
 * @param fileName 文件名
 * @param username 用户名
 * @return
 */
bool Fileoperation::clientExist(const char *fileName, const char *username) {
    std::ifstream file;
    file.open(fileName);
    bool found = false;
    char *data = (char *) calloc(1, 26);
    char *name = (char *) calloc(1, 13);
    char *pwd = (char *) calloc(1, 13);
    while (file.getline(data, 26)) {
        Fileoperation::divideLineData(data, name, pwd);
        if (strcmp(name, username) != 0) {
            continue;
        }
        found = true;
        break;
    }
    file.close();
    return found;
}

/**
 * 这是一个重载函数
 * 打开按照格式书写的用户列表
 * 用于检测用户名与密码是否正确
 * @param fileName 文件名
 * @param username 用户名
 * @prarm password 密码
 * @return
 */
bool Fileoperation::clientExist(const char *fileName, const char *username, const char *password) {
    std::ifstream file;
    file.open(fileName);
    bool found = false;
    char *data = (char *) calloc(1, 26);
    char *name = (char *) calloc(1, 13);
    char *pwd = (char *) calloc(1, 13);
    while (file.getline(data, 26)) {
        Fileoperation::divideLineData(data, name, pwd);
        if (strcmp(name, username) != 0) {
            continue;
        }
        if (strcmp(pwd, password) != 0) {
            continue;
        }
        found = true;
        break;
    }
    file.close();
    return found;
}

/**
 * 获取所有用户名称
 * 需要和“获取文本内容长度”的函数一起使用
 * @param fileName 文件名
 * @param str 用于存放获取名称的字符串（需要提供拥有足够长度的字符串）
 */
void Fileoperation::getClientName(const char *fileName,char* str){
    std::ifstream file;
    file.open(fileName);
    char *data = (char *) calloc(1, 26);
    char *name = (char *) calloc(1, 13);
    char *pwd = (char *) calloc(1, 13);
    int i=1;
    while (file.getline(data, 26)) {
        Fileoperation::divideLineData(data, name, pwd);
        strcat(str,name);
        strcat(str,"\n");
    }
    strcat(str,"\0");
    file.close();
}

/**
 * 获取文本内容长度
 * @param fileName 文件名
 * @return 文本长度（int）
 */
int Fileoperation::getFileLength(const char *fileName){
    std::ifstream file;
    file.open(fileName);
    file.seekg(0, std::ios::end);
    std::streampos count = file.tellg();//读取文件指针的位置
    file.close();
    return count;
}