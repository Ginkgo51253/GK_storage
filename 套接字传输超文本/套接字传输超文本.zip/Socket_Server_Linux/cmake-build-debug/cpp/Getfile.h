//
// Created by 24758 on 2020/5/19.
//

#ifndef READFILE_GETFILE_H
#define READFILE_GETFILE_H

class Getfile {
private:
    static char filename[MAXLENGTH];
    static char path[MAXLENGTH];
public:
    Getfile();

    static bool getfileAlarm;

    static void setFileName(char *);

    static void setPath(char *);

    static bool fileExist();

    static char *getFileName();
};

#endif //READFILE_GETFILE_H
