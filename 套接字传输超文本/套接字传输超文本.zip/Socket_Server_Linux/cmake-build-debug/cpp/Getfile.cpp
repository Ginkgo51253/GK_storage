//
// Created by 24758 on 2020/5/19.
//
/**
 * 本段函数库文件依赖
 * #include<cstdlib> #include<cstring> #include<fstream>
 */
#include "../../stdafx.h"
#include "Getfile.h"

bool Getfile::getfileAlarm;
char Getfile::filename[MAXLENGTH];
char Getfile::path[MAXLENGTH];

/**
 * 构造函数
 * 参数初始化
 */
Getfile::Getfile() {
    Getfile::getfileAlarm = false;
    wmemset(reinterpret_cast<wchar_t *>(Getfile::filename), 0, MAXLENGTH);
    wmemset(reinterpret_cast<wchar_t *>(Getfile::path), 0, MAXLENGTH);
    strcpy(Getfile::path, "./");
}

/**
 * 用于设置检索的起始位置
 * 如果该函数不引用或填入为空，默认即为当前目录
 * 这段填写应该由程序来完成
 * @param str
 */
void Getfile::setPath(char *str) {
    strcpy(Getfile::path, str);
}

/**
 * 用于设置当前类filename所对应的文件
 * @param str 指定文件的路径
 */
void Getfile::setFileName(char *str) {
    if (strlen(str) > 0) {
        strcpy(Getfile::filename, str);
    } else {
        Getfile::getfileAlarm = true;
    }
    //std::cout << "[" << Getfile::filename << "]" << std::endl;
}

/**
 * 用于简单校验该类filename文件对象是否存在
 * @return 布尔值
 */
bool Getfile::fileExist() {
    bool check = false;
    std::ifstream file;
    char temp[strlen(Getfile::path)];
    strcpy(temp, Getfile::path);
    strcat(temp, Getfile::filename);
    file.open(temp, std::ios::in);
    if (file) {
        check = true;
    }
    file.close();
    return check;
}

/**
 * 简单实现对文件名称的拼接
 * 该函数应该在执行fileExist()结果为true之后再进行调用
 * @return 程序使用的文件路径
 */
char *Getfile::getFileName() {
    char *name = (char *) calloc(1, strlen(Getfile::path));
    strcpy(name, Getfile::path);
    strcat(name, Getfile::filename);
    return name;
}