//
// Created by 24758 on 2020/5/28.
//

#ifndef SOCKET_SERVER_LINUX_TRANSMISSION_H
#define SOCKET_SERVER_LINUX_TRANSMISSION_H


class Transmission {
private:
    static int servSock;
    static struct sockaddr_in clntaddr;
    static int clntSock;
public:
    static int getSocket(const std::string &ip, const std::string &port);

    static void closeSocket();

    static int getlisten();

    static void doShutdown();

    static int getClientSocket();
};


#endif //SOCKET_SERVER_LINUX_TRANSMISSION_H
