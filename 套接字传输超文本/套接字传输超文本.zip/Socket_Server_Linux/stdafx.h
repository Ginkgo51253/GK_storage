//
// Created by 24758 on 2020/5/19.
//

/**
 * 标准引用头文件
 */
#ifndef READFILE_STDAFX_H
#define READFILE_STDAFX_H
#define MAXLENGTH 1024

#include<iostream>
#include<fstream>
#include<dirent.h>
#include<vector>
//#include<afxres.h>
#include<sstream>
//#include<cstdlib>
#include<cstring>
//#include<ctype>
#include<unistd.h>//我认为windows平台并不能使用这个头文件
#include <sys/stat.h>
#include <sys/types.h>
#include <cstdlib>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/param.h>

#endif //READFILE_STDAFX_H
