﻿using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

[ExecuteInEditMode]//如要在编辑器模型下正常工作，这个特性依然不可少
public class CustomRenderPassFeature : ScriptableRendererFeature
{
    class CustomRenderPass : ScriptableRenderPass
    {
        private string m_CustomRPName;
        private Material m_Material1;
        private Material m_Material2;
        private Material m_Material3;
        private RenderTargetIdentifier sourceColor;

        //这两个玩意TODO
        private RenderTexture m_tempRT1;
        private RenderTargetIdentifier m_tempRTID1;
        private RenderTexture m_tempRT2;
        private RenderTargetIdentifier m_tempRTID2;

        public CustomRenderPass(string name)
        {
            m_CustomRPName = name;
            if (m_tempRT1 == null)
            {
                m_tempRT1 = new RenderTexture(2560, 1920, 24);
                m_tempRTID1 = new RenderTargetIdentifier(m_tempRT1);
            }
            if (m_tempRT2 == null)
            {
                m_tempRT2 = new RenderTexture(2560, 1920, 24);
                m_tempRTID2 = new RenderTargetIdentifier(m_tempRT2);
            }
        }

        // This method is called before executing the render pass.
        // It can be used to configure render targets and their clear state. Also to create temporary render target textures.
        // When empty this render pass will render to the active camera render target.
        // You should never call CommandBuffer.SetRenderTarget. Instead call <c>ConfigureTarget</c> and <c>ConfigureClear</c>.
        // The render pipeline will ensure target setup and clearing happens in an performance manner.
        /// <summary>
        /// 每帧调用
        /// 这个方法在执行渲染通道之前执行
        /// 留空时渲染通道会应用给激活的相机渲染对象
        /// </summary>
        public override void Configure(CommandBuffer cmd, RenderTextureDescriptor cameraTextureDescriptor)
        {
            //Debug.LogWarning("Configure");

        }

        // Here you can implement the rendering logic.
        // Use <c>ScriptableRenderContext</c> to issue drawing commands or execute command buffers
        // https://docs.unity3d.com/ScriptReference/Rendering.ScriptableRenderContext.html
        // You don't have to call ScriptableRenderContext.submit, the render pipeline will call it at specific points in the pipeline.
        /// <summary>
        /// 每帧调用
        /// </summary>
        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            CommandBuffer cmd = CommandBufferPool.Get(m_CustomRPName);
            //public void Blit(//Blit原型
            //    CommandBuffer cmd, 
            //    RenderTargetIdentifier source, 
            //    RenderTargetIdentifier destination, 
            //    Material material = null, 
            //    int passIndex = 0);
            if (m_Material1 != null && m_Material2 != null)
            {
                Blit(cmd, sourceColor, m_tempRTID1, m_Material1);
                if (m_Material3 != null)
                {
                    Blit(cmd, sourceColor, m_tempRTID2, m_Material3);
                }
                else
                {
                    Blit(cmd, sourceColor, m_tempRTID2);
                }
                m_Material2.SetTexture("_ExtraTex", m_tempRT1);
                m_Material2.SetTexture("_MainTex",m_tempRT2);
                Blit(cmd, m_tempRT2, sourceColor, m_Material2, 0);
            }
            else
            {
                Blit(cmd, sourceColor, sourceColor, m_Material2, 0);
            }

            context.ExecuteCommandBuffer(cmd);
            CommandBufferPool.Release(cmd);
            Debug.LogWarning("My PostProcess is Executing!");
        }

        /// Cleanup any allocated resources that were created during the execution of this render pass.
        /// <summary>
        /// 每帧调用
        /// 这个方法用于清理每帧产生的缓存资源
        /// </summary>
        public override void FrameCleanup(CommandBuffer cmd)
        {
            //Debug.LogWarning("FrameCleanup");
        }

        public void Settings(
            Material m1,
            Material m2,
            Material m3,
            RenderTargetIdentifier renderTargetIdentifier1)
        {
            m_Material1 = m1;
            m_Material2 = m2;
            m_Material3 = m3;
            sourceColor = renderTargetIdentifier1;
        }
    }

    public Material material1;
    public Material material2;
    public Material material3;

    private CustomRenderPass m_ScriptablePass;

    /// <summary>
    /// 这个方法用于参数的初始化
    /// 根据控制台的表现，这个方法可能在启用和关闭的时候各调用一次
    /// </summary>
    public override void Create()
    {
        m_ScriptablePass = new CustomRenderPass(name);

        // Configures where the render pass should be injected.
        //根据样版的写法，这句设置renderPassEvent或许是可以省略的
        m_ScriptablePass.renderPassEvent = RenderPassEvent.AfterRenderingOpaques;
        //Debug.LogWarning("Create");
    }

    // Here you can inject one or multiple render passes in the renderer.
    // This method is called when setting up the renderer once per-camera.
    /// <summary>
    /// 每帧调用
    /// 这个方法会为每个相机设置一次
    /// </summary>
    /// <param name="renderer"></param>
    /// <param name="renderingData"></param>
    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        m_ScriptablePass.Settings(
            material1,
            material2,
            material3,
            renderer.cameraColorTarget);//将暴露给外部的材质参数传送给Pass
        renderer.EnqueuePass(m_ScriptablePass);
        //Debug.LogWarning("AddRenderPasses");
    }
}


