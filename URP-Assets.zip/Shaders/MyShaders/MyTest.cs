﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class MyTest : MonoBehaviour
{
    [ContextMenu("release memory")]
    public void MyTestReleaseMemory()
    {
        long memlog1,memlog2;
        memlog1 = System.GC.GetTotalMemory(false);
        memlog2 = System.GC.GetTotalMemory(true);
        Debug.LogWarning("已释放 " + ((memlog1 - memlog2)/1048576) + "("+(memlog1-memlog2)+")");
    }
}
