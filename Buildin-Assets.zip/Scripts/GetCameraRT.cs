﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 这份脚本用于获取该摄像机的最终渲染图片
/// </summary>
[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
public class GetCameraRT : MonoBehaviour
{
    public RenderTexture finalRT;
    public Vector2Int widthAndHeight = new Vector2Int(2560,1920);

    private void OnEnable()
    {
        finalRT = new RenderTexture(widthAndHeight.x, widthAndHeight.y, 24);
    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        finalRT.Release();
        Graphics.Blit(source, finalRT);
        Graphics.Blit(source, destination);
    }
}
