﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
[RequireComponent(typeof(ReflectionProbe))]
public class MyReflectionProbeUpdate : MonoBehaviour
{
    public bool isUpdateEveryFrame = false;
    void Update()
    {
        if (isUpdateEveryFrame)
        {
            transform.GetComponent<ReflectionProbe>().RenderProbe();
        }
    }
}
