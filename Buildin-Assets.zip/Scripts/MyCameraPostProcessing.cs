﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
public class MyCameraPostProcessing : MonoBehaviour
{
    #region public
    [Header("原型")]
    public Material theDepthToAreaMat;
    public Material theExternalContourMat;
    public Camera certainObject_Camera2;
    public Material theMergeMat;
    public CameraRenderChoice cameraRenderChoice = CameraRenderChoice.default_2560x1920;

    [Header("克隆")]
    public Material theDepthToAreaMatClone;
    public Material theExternalContourMatClone;
    public Material theMergeMatClone;
    #endregion

    private Camera thisCamera;
    private DepthTextureMode testCameraDepthTextureMode = DepthTextureMode.DepthNormals;
    private RenderTexture activeTextureCopy;//原画面RT的拷贝
    private RenderTexture finRenderTexture;//用来混合/叠加的目标RT
    private RenderTexture tempRT;//临时RT，使用前先release
                                 //RenderTexture.Release()方法的官方解释是
                                 //使用Release释放RT使用的硬件资源，但并不会直接销毁它，再次使用的时候会自动重新生成
                                 //因为不属于正常的资源回收循环，所以需要注意释放和使用的时机
                                 //先前疑似是递归的操作使Unity前后至少崩溃3次，现象为内存溢出

    private Texture2D thisTex;

    public static readonly int[] width = { 2560, 256, 5120 };//图片长度
    public static readonly int[] height = { 1920, 192, 3840 };//图片宽度
    public static readonly TextureFormat textureFormat = TextureFormat.ARGB32;//24位rgb带alpha通道，即argb32

    #region Unity消息
    private void OnEnable()
    {
        thisCamera = GetComponent<Camera>();
        thisTex = new Texture2D(width[(int)cameraRenderChoice], height[(int)cameraRenderChoice], TextureFormat.ARGB32, false);
        //创建一个Texture2对象，用于保存Render Texture信息
        DoRefreshAllTemporaryRenderTexture();//刷新临时材质
        DoCloneAllMaterial();//将材质转换为实际使用的克隆
    }

    /// <summary>
    /// 在渲染前设置
    /// </summary>
    private void OnPreRender()
    {
        if (GetComponent<Camera>().activeTexture != null)//防止相机将图像直接渲染到scene视图
        {
            if (thisCamera.depthTextureMode != testCameraDepthTextureMode)
            {
                thisCamera.depthTextureMode = testCameraDepthTextureMode;
                Debug.LogWarning(gameObject.name+" 深度材质模式：" + testCameraDepthTextureMode.ToString());
            }
        }
        if (certainObject_Camera2 != null && theMergeMatClone != null)
        {
            //在官方的手册中明确注明了不要在一个相机渲染的时候做另一个相机的渲染，但没有注明原因和导致的情况
            //这里遇到了可能是这种错误操作导致的现象，并且有可能只会发生在背景透明的图片导出情况上
            //当这个子相机的渲染时机处于当前相机渲染的过程中，似乎会导致图片额外做一次预乘处理
            //直观现象是半透明的阴影都变得更加透明了，仔细观察发现其他半透明位置都受到了影响
            //所以将它的渲染位置提前，安排在当前相机开始渲染之前先对子相机进行一次渲染，在后续当前相机渲染的时候去获取它的RT
            certainObject_Camera2.GetComponent<Camera>().Render();
        }
    }

    /// <summary>
    /// 这个方法可以取出相机当前渲染的画面
    /// 然后做一定的处理再次输出
    /// 这个方法可能可以做一些拓展性的改写
    /// </summary>
    /// <param name="source">数据源</param>
    /// <param name="destination">目标</param>
    private void OnRenderObject()
    {
        if (GetComponent<Camera>().activeTexture != null)//防止相机将图像直接渲染到scene视图
        {
            activeTextureCopy.Release();
            finRenderTexture.Release();
            Graphics.Blit(thisCamera.activeTexture, activeTextureCopy);
            Graphics.Blit(activeTextureCopy, finRenderTexture);
            //模型后处理渲染流程 模块1：
            if (theDepthToAreaMatClone != null && theExternalContourMatClone != null)
            {
                //第一份材质用于生成区域
                tempRT.Release();
                Graphics.Blit(activeTextureCopy, tempRT, theDepthToAreaMatClone);//testCamera.activeTexture//RenderTexture.active
                theExternalContourMatClone.SetTexture("_ExtraTex", tempRT);
                //第二份材质用于生成原图和描边
                Graphics.Blit(activeTextureCopy, finRenderTexture, theExternalContourMatClone);
                //Graphics.Blit(tempRT,finRenderTexture);
            }
            //将图像输出至常规相机输出
            Graphics.Blit(finRenderTexture, thisCamera.activeTexture);
        }
    }

    private void OnPostRender()
    {
    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (GetComponent<Camera>().activeTexture != null)//防止相机将图像直接渲染到scene视图
        {
            activeTextureCopy.Release();
            finRenderTexture.Release();
            Graphics.Blit(source, activeTextureCopy);
            Graphics.Blit(activeTextureCopy, finRenderTexture);
            //图像后处理渲染流程 模块1：
            if (certainObject_Camera2 != null && theMergeMatClone != null)
            {
                //certainObject_Camera2.Render();//用来触发该相机上RT状态的更新//这一句会直接导致阴影材质的表现异常
                theMergeMatClone.SetTexture("_ExtraTex", certainObject_Camera2.GetComponent<GetCameraRT>().finalRT);
                Graphics.Blit(activeTextureCopy, finRenderTexture, theMergeMatClone);
                //Graphics.Blit(certainObject_Camera2.GetComponent<GetCameraRT>().finalRT, finRenderTexture);
            }
            //将图像输出至常规相机输出
            Graphics.Blit(finRenderTexture, destination);
        }
    }
    #endregion

    #region 基础功能
    /// <summary>
    /// 刷新全部临时材质
    /// </summary>
    private void DoRefreshAllTemporaryRenderTexture()
    {
        if (activeTextureCopy != null)
        {
            activeTextureCopy.Release();
        }
        else
        {
            //这份材质用于拷贝基础画面
            activeTextureCopy = new RenderTexture(width[(int)cameraRenderChoice], height[(int)cameraRenderChoice], 24);
        }

        if (finRenderTexture != null)
        {
            finRenderTexture.Release();
        }
        else
        {
            //这份材质用于存放混合画面
            finRenderTexture = new RenderTexture(width[(int)cameraRenderChoice], height[(int)cameraRenderChoice], 24);
        }

        if (tempRT != null)
        {
            tempRT.Release();
        }
        else
        {
            //这份材质用于存放临时画面
            tempRT = new RenderTexture(width[(int)cameraRenderChoice], height[(int)cameraRenderChoice], 24);
        }
    }

    /// <summary>
    /// 克隆全部材质
    /// </summary>
    private void DoCloneAllMaterial()
    {
        theDepthToAreaMatClone = CloneMatrerial(theDepthToAreaMat);
        theExternalContourMatClone = CloneMatrerial(theExternalContourMat);
        theMergeMatClone = CloneMatrerial(theMergeMat);
    }

    /// <summary>
    /// 克隆材质
    /// </summary>
    /// <param name="theMaterial">原材质材质</param>
    /// <param name="theMaterialClone">材质克隆</param>
    private Material CloneMatrerial(Material theMaterial)
    {
        //对于每一份脚本，使用的材质资源应该是独立的，因为所有相机都是激活的
        //使用同一份原本的话画面内容会串
        if (theMaterial == null)
        {
            return null;
        }
        else
        {
            Material newMat = new Material(theMaterial);
            newMat.name = newMat.name + "(Clone)";
            return newMat;
        }
    }

    #endregion

    #region 扩展功能
    /// <summary>
    /// 让当前相机绘制深度法线图
    /// </summary>
    [ContextMenu("SetDepthNormalMode")]
    private void SetCameraRenderDepthAndNormalTexture()
    {
        thisCamera.depthTextureMode = DepthTextureMode.DepthNormals;
    }

    /// <summary>
    /// 让当前相机临时绘制一张图片
    /// 是不包含代码打点计算的原图
    /// </summary>
    [ContextMenu("DoRender")]
    public void DoRender()
    {
        RenderTexture.active = finRenderTexture;//设置当前激活的RenderTexture的捕获对象为指定画布//renderTexture2//finRenderTexture//testCamera.activeTexture
        thisTex.ReadPixels(new Rect(0, 0, width[(int)cameraRenderChoice], height[(int)cameraRenderChoice]), 0, 0);//从当前激活的视口读取像素
        thisCamera.targetTexture = null;//重置截图相机的targetTexture
        RenderTexture.active = null;//关闭RenderTexture的激活状态
        thisTex.Apply();
        WritePNG(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\\", DateTime.Now.ToString("HHmmssffff") + ".png", thisTex);//写入PNG图片
    }

    /// <summary>
    /// 写入PNG图片
    /// </summary>
    /// <param name="pngName"></param>
    /// <param name="pngTex"></param>
    private static void WritePNG(string pathName, string pngName, Texture2D pngTex)
    {
        byte[] bytes = pngTex.EncodeToPNG();//将纹理数据，转换成一个png图片
        File.WriteAllBytes(pathName + pngName, bytes);//写入数据
    }

    [ContextMenu("SetCameraDisplayTo(-1)")]
    private void SetCameraDisplayMinusOne()
    {
        thisCamera.targetDisplay = -1;
    }
    #endregion
}
