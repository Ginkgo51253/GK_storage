﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class MyAutoRotate : MonoBehaviour
{
    public Vector3 objOriRotation;
    public float rotateSpeed = 0;

    private void OnEnable()
    {
        transform.localEulerAngles = objOriRotation;
    }

    private void Update()
    {
        Vector3 currentEularAngle = transform.localEulerAngles;
        currentEularAngle.y += rotateSpeed;
        transform.localEulerAngles = currentEularAngle;
    }
}
