﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnityCameraRender
{
    public static readonly int[] width = { 2560, 512, 5120, 256 };//图片长度
    public static readonly int[] height = { 1920, 384, 3840, 192 };//图片宽度
    public static readonly TextureFormat textureFormat = TextureFormat.ARGB32;//24位rgb带alpha通道，即argb32

    private Texture2D thisTex;
    private RenderTexture renderTexture;
    private CameraRenderChoice cameraRenderChoice;
    private int renderWidth, renderHeight;//用于寄存渲染图像的长宽

    /// <summary>
    /// 使用原设定的参数进行渲染
    /// </summary>
    /// <param name="cameraRenderChoice"></param>
    public UnityCameraRender(CameraRenderChoice cameraRenderChoice = CameraRenderChoice.default_2560x1920)
    {
        this.cameraRenderChoice = cameraRenderChoice;
        renderWidth = width[(int)cameraRenderChoice];
        renderHeight = height[(int)cameraRenderChoice];

        renderTexture = new RenderTexture(renderWidth, renderHeight, 24);//创建一个RenderTexture对象,即创建画布，这里值得注意的一点，24表示的位深度在Buildin中并不会有影响，但至少在URP管线下会存在深度显示问题
        //renderTexture.antiAliasing = 16;//Unity自己的抗锯齿，但看不出效果
        thisTex = new Texture2D(renderWidth, renderHeight, TextureFormat.ARGB32, false);//创建一个Texture2对象，用于保存Render Texture信息//原来用的TextureFormat.ARGB32
    }

    /// <summary>
    /// 使用自定义的参数进行渲染
    /// </summary>
    /// <param name="width"></param>
    /// <param name="height"></param>
    public UnityCameraRender(int width, int height)
    {
        this.cameraRenderChoice = CameraRenderChoice.custom_Resolusion;
        renderWidth = width;
        renderHeight = height;

        renderTexture = new RenderTexture(width, height, 24);
        thisTex = new Texture2D(width, height, TextureFormat.ARGB32, false);
    }

    ~UnityCameraRender()
    {
        Object.Destroy(thisTex);
        Object.Destroy(renderTexture);
    }

    /// <summary>
    /// 获取视口参数
    /// </summary>
    /// <param name="cCamera"></param>
    /// <returns></returns>
    public Texture2D GetViewData(Camera cCamera)
    {
        Texture2D tex = CameraCapture(cCamera, renderWidth, renderHeight);
        tex = SimpleInverseAlphaBlend(tex);//预乘还原
        ////tex = SimpleAntiAliasing0(tex, width[(int)cameraRenderChoice], height[(int)cameraRenderChoice]);//简易抗锯齿
        //tex = SimpleAntiAliasing1(tex, renderWidth, renderHeight);//带权平滑抗锯齿
        tex.Apply();//保存材质
        return tex;
    }

    /// <summary>
    /// 捕获相机视图
    /// 使用自定义长宽参数
    /// </summary>
    /// <param name="viewCamera"></param>
    /// <param name="width"></param>
    /// <param name="height"></param>
    /// <returns></returns>
    private Texture2D CameraCapture(Camera viewCamera, int width, int height)
    {
        viewCamera.gameObject.SetActive(true);//启用截图相机
        renderTexture.Release();
        viewCamera.targetTexture = renderTexture;//将相机的渲染结果输出到指定画布上
        viewCamera.Render();//手动开启相机渲染
        RenderTexture.active = renderTexture;//设置当前激活的RenderTexture的捕获对象为指定画布
        thisTex.ReadPixels(new Rect(0, 0, width, height), 0, 0);//从当前激活的视口读取像素
        viewCamera.targetTexture = null;//重置截图相机的targetTexture
        RenderTexture.active = null;//关闭RenderTexture的激活状态
        return thisTex;
    }

    /// <summary>
    /// unity相机透明色混合还原算法
    /// 相机的背景颜色需要首先置为黑色透明（不是唯一解，但计算最方便）
    /// </summary>
    /// <param name="tex"></param>
    /// <returns></returns>
    private Texture2D SimpleInverseAlphaBlend(Texture2D tex)
    {
        //新方法 渲染单图不到100毫秒
        byte[] bytes = tex.GetRawTextureData();//2毫秒
        for (int i = 0; i < bytes.Length / 4; i++)//循环单句大约15毫秒 bytes.length = 2560*1920*4
        {
            if (bytes[i * 4] == 0)//A值为空直接跳过
            {
                continue;
            }

            //这三句大约30毫秒，反预乘的计算原理，RawRGB = RGB / A
            int r = bytes[i * 4 + 1] * 255 / bytes[i * 4];
            int g = bytes[i * 4 + 2] * 255 / bytes[i * 4];
            int b = bytes[i * 4 + 3] * 255 / bytes[i * 4];
            int a = bytes[i * 4];//A值不动

            //HDR色彩处理
            int maxRGB = GetMaxRGB(r, g, b);
            if (maxRGB > 255)
            {
                r = r * 255 / maxRGB;
                g = g * 255 / maxRGB;
                b = b * 255 / maxRGB;

                float alphaModify = (float)maxRGB / 255;//相当于HDR的Intensity
                a = (int)(a * alphaModify);
                if (a > 255)
                {
                    a = 255;
                }
            }

            bytes[i * 4] = (byte)a;//a
            bytes[i * 4 + 1] = (byte)r;//r
            bytes[i * 4 + 2] = (byte)g;//g
            bytes[i * 4 + 3] = (byte)b;//b
        }
        tex.LoadRawTextureData(bytes);//3-8毫秒

        //老方法 单图大约1800毫秒
        //for (int y = 0; y < tex.height; y++)
        //{
        //    for (int x = 0; x < tex.width; x++)
        //    {
        //
        //        Color pixColor = tex.GetPixel(x, y);//循环中用时大约0.9秒
        //        //Debug.Log(pixColor.r + " " + pixColor.g + " " + pixColor.b + " " + pixColor.a);
        //        float r = pixColor.r / pixColor.a;
        //        float g = pixColor.g / pixColor.a;
        //        float b = pixColor.b / pixColor.a;
        //        float a = pixColor.a;
        //
        //        float maxRGB = GetMaxRGB(r, g, b);
        //        if (maxRGB > 1)
        //        {
        //            r = r * 1 / maxRGB;
        //            g = g * 1 / maxRGB;
        //            b = b * 1 / maxRGB;
        //
        //            float alphaModify = maxRGB;
        //            a *= alphaModify;
        //            if(a > 1)
        //            {
        //                a = 1;
        //            }
        //        }
        //        pixColor.r = r;
        //        pixColor.g = g;
        //        pixColor.b = b;
        //        pixColor.a = a;
        //        tex.SetPixel(x, y, pixColor);//循环中用时大约0.9秒
        //    }
        //}

        return tex;
    }


    /// <summary>
    /// 只针对图片边缘进行的简易抗锯齿
    /// </summary>
    /// <param name="tex"></param>
    /// <returns></returns>
    private Texture2D SimpleAntiAliasing0(Texture2D tex, int width, int height)
    {
        byte[] bytes = tex.GetRawTextureData();
        if (width * height * 4 != bytes.Length)
        {
            return tex;
        }
        byte[] tbytes = new byte[bytes.Length];
        for (int i = 1; i < height - 1; i++)
        {
            for (int j = 1; j < width - 1; j++)
            {
                if (bytes[i * width * 4 + (j) * 4] == 0 && (bytes[i * width * 4 + (j - 1) * 4] != 0 || bytes[i * width * 4 + (j + 1) * 4] != 0 || bytes[(i - 1) * width * 4 + j * 4] != 0 || bytes[(i + 1) * width * 4 + j * 4] != 0))
                {
                    for (int k = 0; k < 4; k++)
                    {
                        tbytes[i * width * 4 + j * 4 + k] =
                            (byte)
                            (
                                (
                                    bytes[i * width * 4 + (j) * 4 + k] +
                                    bytes[i * width * 4 + (j - 1) * 4 + k] +
                                    bytes[i * width * 4 + (j + 1) * 4 + k] +
                                    bytes[(i - 1) * width * 4 + j * 4 + k] +
                                    bytes[(i + 1) * width * 4 + j * 4 + k]
                                ) / 5
                             );
                    }
                }
                else
                {
                    tbytes[i * width * 4 + j * 4] = bytes[i * width * 4 + (j) * 4];
                    tbytes[i * width * 4 + j * 4 + 1] = bytes[i * width * 4 + (j) * 4 + 1];
                    tbytes[i * width * 4 + j * 4 + 2] = bytes[i * width * 4 + (j) * 4 + 2];
                    tbytes[i * width * 4 + j * 4 + 3] = bytes[i * width * 4 + (j) * 4 + 3];
                }
            }
        }
        tex.LoadRawTextureData(tbytes);

        return tex;
    }

    /// <summary>
    /// 只针对除最外围一圈进行的加权抗锯齿
    /// 效果比不加权的更清晰，同时具有一定的平滑度（性能损失一般）
    /// </summary>
    /// <param name="tex"></param>
    /// <param name="width"></param>
    /// <param name="height"></param>
    /// <returns></returns>
    private Texture2D SimpleAntiAliasing1(Texture2D tex, int width, int height)
    {
        byte[] bytes = tex.GetRawTextureData();
        if (width * height * 4 != bytes.Length)
        {
            return tex;
        }
        byte[] tbytes = new byte[bytes.Length];
        for (int i = 1; i < height - 1; i++)
        {
            for (int j = 1; j < width - 1; j++)
            {
                for (int k = 0; k < 4; k++)
                {
                    tbytes[i * width * 4 + j * 4 + k] =
                        (byte)
                        (
                            (
                                bytes[i * width * 4 + (j) * 4 + k] * 6 +
                                bytes[i * width * 4 + (j - 1) * 4 + k] +
                                bytes[i * width * 4 + (j + 1) * 4 + k] +
                                bytes[(i - 1) * width * 4 + j * 4 + k] +
                                bytes[(i + 1) * width * 4 + j * 4 + k]
                            ) / 10
                         );
                }
            }
        }
        tex.LoadRawTextureData(tbytes);
        return tex;
    }

    /// <summary>
    /// 三数求最大
    /// </summary>
    private int GetMaxRGB(int R, int G, int B)
    {
        int temp = R;
        temp = temp > G ? temp : G;
        temp = temp > B ? temp : B;
        return temp;
    }

    private float GetMaxRGB(float R, float G, float B)
    {
        float temp = R;
        temp = temp > G ? temp : G;
        temp = temp > B ? temp : B;
        return temp;
    }

    /// <summary>
    /// 供外部获取和查看渲染类型
    /// </summary>
    /// <returns></returns>
    public CameraRenderChoice GetCameraRenderChoice()
    {
        return cameraRenderChoice;
    }

    /// <summary>
    /// 供外部获取和查看长宽信息
    /// </summary>
    /// <returns></returns>
    public Vector2Int GetWidthAndHeight()
    {
        return new Vector2Int(renderWidth, renderHeight);
    }
}

/// <summary>
/// 默认的图像大小配置
/// </summary>
public enum CameraRenderChoice
{
    default_2560x1920,
    small_256x192,
    large_5120x3840,
    custom_Resolusion
}

/*//这个计时方法先留一留，晚点做性能方面的测试
 * System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
        sw.Start();
sw.Stop();
 */