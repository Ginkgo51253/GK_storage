﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class CameraProtractorForOld : EditorWindow
{
    private static CameraProtractorForOld thisWindow;
    private static Rect windowRect = new Rect(10, 50, 580, 250);//窗口大小，暂时不作只读
    private static Vector2 floatInputField = new Vector2(240, 20);//向量输入框

    //用于存放每帧调用的方法
    private static Action frameFn = null;

    //脚本信息
    private static string m_scriptMessage = "只读脚本消息";

    //相机
    private static GameObject cCameraGameObject;//相机根
    private static List<Camera> cCameras;
    private static Camera c01;
    private static Camera c02;
    private static Camera c03;
    private static Camera c04;
    private static Camera c05;
    private static Camera c06;
    private static Camera c07;
    private static Camera c08;

    //相机的位置与角度
    private static Vector3[] cameraPos = new Vector3[8];
    private static Vector3[] cameraEularAngle = new Vector3[8];

    //静态参数
    private static float cDistance = 6f;//视点到相机的距离，使用这个控制相机的拍摄范围

    #region 脚本UI与初始化
    [MenuItem("Tools/CameraProtractorForOld")]
    static void CameraProtractor_Start()
    {
        ScriptInit();
        thisWindow = (CameraProtractorForOld)GetWindowWithRect(typeof(CameraProtractorForOld), windowRect, true, "CameraProtractorForOld");//new Rect(10, 10, 600, 425)
        thisWindow.Show();
    }

    /// <summary>
    /// 编辑器扩展UI
    /// </summary>
    private void OnGUI()
    {
        //==============================================//模块1：相机
        GUILayout.BeginArea(new Rect(5, 5, 600, 300));
        GUI.Label(new Rect(0, 0, 60, 20), "名称 方向");
        GUI.Label(new Rect(70, 0, 100, 20), "欧拉角度(可写)");//注意8向等量的原则，一般只修改垂直角度
        GUI.Label(new Rect(320, 0, 100, 20), "三维坐标(只读)");//这个参数主要用于展示的，我强烈不建议修改

        GUI.Label(new Rect(0, 20, 60, 20), "c01 下");
        //cameraMatrix[0,0] = EditorGUI.FloatField(new Rect(70, 20, 60, 20), "", cameraMatrix[0, 0]);
        cameraEularAngle[0] = EditorGUI.Vector3Field(new Rect(new Vector2(70, 20), floatInputField), "", cameraEularAngle[0]);
        EditorGUI.Vector3Field(new Rect(new Vector2(320, 20), floatInputField), "", cameraPos[0]);

        GUI.Label(new Rect(0, 40, 60, 20), "c02 右下");
        cameraEularAngle[1] = EditorGUI.Vector3Field(new Rect(new Vector2(70, 40), floatInputField), "", cameraEularAngle[1]);
        EditorGUI.Vector3Field(new Rect(new Vector2(320, 40), floatInputField), "", cameraPos[1]);

        GUI.Label(new Rect(0, 60, 60, 20), "c03 右");
        cameraEularAngle[2] = EditorGUI.Vector3Field(new Rect(new Vector2(70, 60), floatInputField), "", cameraEularAngle[2]);
        EditorGUI.Vector3Field(new Rect(new Vector2(320, 60), floatInputField), "", cameraPos[2]);

        GUI.Label(new Rect(0, 80, 60, 20), "c04 右上");
        cameraEularAngle[3] = EditorGUI.Vector3Field(new Rect(new Vector2(70, 80), floatInputField), "", cameraEularAngle[3]);
        EditorGUI.Vector3Field(new Rect(new Vector2(320, 80), floatInputField), "", cameraPos[3]);

        GUI.Label(new Rect(0, 100, 60, 20), "c05 上");
        cameraEularAngle[4] = EditorGUI.Vector3Field(new Rect(new Vector2(70, 100), floatInputField), "", cameraEularAngle[4]);
        EditorGUI.Vector3Field(new Rect(new Vector2(320, 100), floatInputField), "", cameraPos[4]);

        GUI.Label(new Rect(0, 120, 60, 20), "c06 左上");
        cameraEularAngle[5] = EditorGUI.Vector3Field(new Rect(new Vector2(70, 120), floatInputField), "", cameraEularAngle[5]);
        EditorGUI.Vector3Field(new Rect(new Vector2(320, 120), floatInputField), "", cameraPos[5]);

        GUI.Label(new Rect(0, 140, 60, 20), "c07 左");
        cameraEularAngle[6] = EditorGUI.Vector3Field(new Rect(new Vector2(70, 140), floatInputField), "", cameraEularAngle[6]);
        EditorGUI.Vector3Field(new Rect(new Vector2(320, 140), floatInputField), "", cameraPos[6]);

        GUI.Label(new Rect(0, 160, 60, 20), "c08 左下");
        cameraEularAngle[7] = EditorGUI.Vector3Field(new Rect(new Vector2(70, 160), floatInputField), "", cameraEularAngle[7]);
        EditorGUI.Vector3Field(new Rect(new Vector2(320, 160), floatInputField), "", cameraPos[7]);

        if (GUI.Button(new Rect(0, 200, 60, 30), "参数导出"))
        {
            m_scriptMessage = BuildCameraPosStr();
        }
        GUI.Label(new Rect(70, 190, 60, 20), "脚本消息");
        GUI.TextField(new Rect(70, 210, 490, 20), m_scriptMessage);
        GUILayout.EndArea();
    }

    private void Update()
    {
        if (frameFn == null)
        {
            frameFn = () => { };
        }
        else
        {
            frameFn();
        }
    }

    private void OnDestroy()
    {
        if (frameFn != null)
        {
            frameFn -= CameraStatusSync;
        }
    }

    /// <summary>
    /// 脚本初始化
    /// </summary>
    private static void ScriptInit()
    {
        if (thisWindow != null)
        {
            thisWindow.position = windowRect;
        }
        c01 = GetCameraByName("c01");
        c02 = GetCameraByName("c02");
        c03 = GetCameraByName("c03");
        c04 = GetCameraByName("c04");
        c05 = GetCameraByName("c05");
        c06 = GetCameraByName("c06");
        c07 = GetCameraByName("c07");
        c08 = GetCameraByName("c08");

        if (cCameras == null)
        {
            cCameras = new List<Camera>();
        }
        cCameras.Clear();
        cCameras.Add(c01);
        cCameras.Add(c02);
        cCameras.Add(c03);
        cCameras.Add(c04);
        cCameras.Add(c05);
        cCameras.Add(c06);
        cCameras.Add(c07);
        cCameras.Add(c08);

        for (int i = 0; i < cCameras.Count; i++)
        {
            cameraPos[i] = cCameras[i].transform.position;
            cameraEularAngle[i] = cCameras[i].transform.eulerAngles;
        }

        frameFn = () => { };
        frameFn += CameraStatusSync;
    }
    #endregion

    #region 脚本扩展功能

    /// <summary>
    /// 依据名称获取相机
    /// </summary>
    /// <param name="name"></param>
    /// <returns></returns>
    private static Camera GetCameraByName(string name)
    {
        if (cCameraGameObject != null && cCameraGameObject.activeSelf)
        {
            foreach (Transform theTransform in cCameraGameObject.GetComponentsInChildren<Transform>())
            {
                if (theTransform.GetComponent<Camera>() != null && theTransform.name.Equals(name))
                {
                    return theTransform.GetComponent<Camera>();
                }
            }
        }
        else
        {
            cCameraGameObject = GameObject.Find("RenderBox");
            if (cCameraGameObject != null)
            {
                return GetCameraByName(name);
            }
        }
        foreach (Camera theCamera in Camera.allCameras)//直接从非指定名称的相机中寻找目标
        {
            if (theCamera.name.Equals(name))
            {
                return theCamera;
            }
        }
        m_scriptMessage = "场景中的相机阵列不符合渲染要求！！";
        return null;
    }

    /// <summary>
    /// 相机同步
    /// </summary>
    private static void CameraStatusSync()
    {
        for (int i = 0; i < cCameras.Count; i++)
        {
            float groundProjection = cDistance * Mathf.Cos(Mathf.PI * cameraEularAngle[i].x / 180);
            float x = -groundProjection * Mathf.Sin(Mathf.PI * cameraEularAngle[i].y / 180);
            float y = cDistance * Mathf.Sin(Mathf.PI * cameraEularAngle[i].x / 180);
            float z = -groundProjection * Mathf.Cos(Mathf.PI * cameraEularAngle[i].y / 180);

            cCameras[i].transform.localPosition = cameraPos[i] = new Vector3(x, y, z);
        }
    }

    /// <summary>
    /// 构建相机位置的字符串数据
    /// </summary>
    /// <returns></returns>
    private static string BuildCameraPosStr()
    {
        string str = "字符串构建完成，请键入全选复制！" + DateTime.Now.ToString("HH:mm:ss") + "\n{\n";
        for (int i = 0; i < cCameras.Count; i++)
        {
            Vector3 vector3 = cCameras[i].transform.position;
            str += "{ " + vector3.x + "," + vector3.y + "," + vector3.z + " },\n";
        }
        str += "}";
        return str;
    }
    //    {//参考
    //        { 0,44.88f,96.36f },
    //        { 68.148f,44.88f,68.148f},
    //        { 96.36f,44.88f,0},
    //        { 68.148f,44.88f,-68.148f},
    //        { 0,44.88f,-96.36f},
    //        { -68.148f,44.88f,-68.148f},
    //        { -96.36f,44.88f,0},
    //        { -68.148f,44.88f,68.148f},
    //    }
	
	//	  {//旧宠物相机组参考
	//	  	  { 0,3,5.196152 },
	//	  	  { 3.674235,3,3.674234 },
	//	  	  { 5.196152,3,0 },
	//	  	  { 3.674233,3,-3.674236 },
	//	  	  { 0,3,-5.196152 },
	//	  	  { -3.674234,3,-3.674234 },
	//	  	  { -5.196152,3,0 },
	//	  	  { -3.674234,3,3.674234 },
	//	  }
    #endregion
}
