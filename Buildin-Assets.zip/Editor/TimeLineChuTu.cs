using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UniRx;
using UnityEditor;
using UnityEngine;
using UnityEngine.Playables;

public class TimeLineChuTu : EditorWindow
{
    //UI���ڲ���
    private static EditorWindow thisWindow;
    private static Rect windowRect = new Rect(10, 10, 300, 120);

    //�������
    private static GameObject cCameraGameObject;//����Ⱦ�������
    private static string txtInputOutputAddress = "";//���Ŀ¼
    private static float startTime = 0;//��Ⱦ��ʼʱ��
    private static float endTime = 0;//��Ⱦ�ս�ʱ��
    private static GameObject targetGameObject;//����Ⱦ����
    private static int renderWidth = 1024,renderHeight = 1024;//��Ⱦ��������

    //���ڲ���
    private static readonly string historyPath = "C:\\Users\\Public\\Documents\\unityTimeLineChuTuHistory.txt";//����ļ��洢��һ�ν�����Ⱦ������
    private static string m_scriptMessage = "ֻ���ű���Ϣ";
    private static Action myUpdate;//��֡��Ⱦʹ�õ�ί��
    private static bool texWorkIsDone = true;//��֡��ȡTex2D��ϱ�ʶ��
    private static List<Texture2D> cameraTex2D = new List<Texture2D>();//��ʱ���Tex2D���б�
    private const float maxTimeStep = 0.01666f;//ÿһ֡��Ⱦ�ļ��
    private static float sysTimeStep = 0.3f;//����ԭϵͳ��Ⱦ�ļ��
    private static int updateCount = 0;//���´���

    #region �ű�UI���ʼ��
    [MenuItem("Tools/TimeLineChuTu #t")]
    static void unityChaoJiChuTu_Start()
    {
        ScriptInit();
        thisWindow = (TimeLineChuTu)GetWindowWithRect(typeof(TimeLineChuTu), windowRect, true, "TimeLineChuTu");//new Rect(10, 10, 300,200)
        thisWindow.Show();
    }

    private void OnGUI()
    {
        GUILayout.BeginArea(new Rect(5, 5, 290, 190));
        GUI.Label(new Rect(0, 0, 60, 20), "��Ⱦ���");
        cCameraGameObject = (GameObject)EditorGUI.ObjectField(new Rect(60, 0, 75, 20), cCameraGameObject, typeof(GameObject), true);
        GUI.Label(new Rect(0, 30, 60, 20), "Ŀ�����");
        targetGameObject = (GameObject)EditorGUI.ObjectField(new Rect(60, 30, 75, 20), targetGameObject, typeof(GameObject), true);
        GUI.Label(new Rect(140, 0, 60, 20), "���Ŀ¼");
        txtInputOutputAddress = GUI.TextField(new Rect(200, 0, 80, 20), txtInputOutputAddress);
        GUI.Label(new Rect(140, 30, 60, 20), "��(s)");
        startTime = EditorGUI.FloatField(new Rect(175, 30, 30, 20), "", startTime);
        GUI.Label(new Rect(215, 30, 60, 20), "β(s)");
        endTime = EditorGUI.FloatField(new Rect(250, 30, 30, 20), "", endTime);
        GUI.Label(new Rect(5, 60, 60, 20), "��");
        renderWidth = EditorGUI.IntField(new Rect(25, 60, 35, 20), "", renderWidth);
        GUI.Label(new Rect(80, 60, 60, 20), "��");
        renderHeight = EditorGUI.IntField(new Rect(100, 60, 35, 20), "", renderHeight);
        GUI.TextField(new Rect(5, 90, 130, 20), m_scriptMessage);
        if (GUI.Button(new Rect(145, 60, 60, 30), "��ʼ��Ⱦ"))
        {
            if (DoubleClickChecker("��ʼ��Ⱦ"))
            {
                if (CheckRenderLegal(1) && CheckRenderLegal(2))
                {
                    MyRenderAll();
                    m_scriptMessage = "ͼƬ��Ⱦ��ɣ�(MyRenderOnePic)";
                    MyReleaseMemory();
                }
            }
        }
        if (GUI.Button(new Rect(220, 60, 60, 30), "��ͼ����"))
        {
            if (DoubleClickChecker("��ͼ����"))
            {
                if (CheckRenderLegal(1))
                {
                    MyRenderOnePicCover();
                    m_scriptMessage = "ͼƬ��Ⱦ��ɣ�(MyRenderOnePic)";
                    MyReleaseMemory();
                }
            }
        }
        GUILayout.EndArea();
    }

    // Update is called once per frame
    void Update()
    {
        if (myUpdate != null)
        {
            myUpdate();
        }
        DoubleClickTimerTicker();
    }

    /// <summary>
    /// �ű���ʼ��
    /// </summary>
    private static void ScriptInit()
    {
        if (thisWindow != null)
        {
            thisWindow.position = windowRect;
        }
        if (!File.Exists(historyPath))
        {
            File.WriteAllText(historyPath, "#��ʷ��¼#\n" +
                "<�����ַ>\n\n\n" +
                "<��Ⱦ���>\n\n\n" +
                "<Ŀ�����>\n\n\n" +
                "<��Ⱦ����>\n\n\n" +
                "<��Ⱦ����>\n"
                );
        }
        ReadHistory();
    }
    #endregion

    #region �ű����ܷ���
    /// <summary>
    /// ��ȡ��ʷ
    /// </summary>
    private static void ReadHistory()
    {
        try
        {
            txtInputOutputAddress = MyReadTxtUTF8(historyPath, "�����ַ", 1)[1];
        }
        catch { }
        try
        {
            cCameraGameObject = GameObject.Find(MyReadTxtUTF8(historyPath, "��Ⱦ���", 1)[1]);
        }
        catch { }
        try
        {
            targetGameObject = GameObject.Find(MyReadTxtUTF8(historyPath, "Ŀ�����", 1)[1]);
        }
        catch { }
        try
        {
            renderWidth = int.Parse(MyReadTxtUTF8(historyPath, "��Ⱦ����", 1)[1]);
        }
        catch { }
        try
        {
            renderHeight = int.Parse(MyReadTxtUTF8(historyPath, "��Ⱦ����", 1)[1]);
        }
        catch { }
    }

    /// <summary>
    /// д����ʷ
    /// </summary>
    private static void WriteHistory()
    {
        string strContent = "#��ʷ��¼#\n" +
                "<�����ַ>\n" + txtInputOutputAddress + "\n\n"+
                "<��Ⱦ����>\n" + renderWidth + "\n\n"+
                "<��Ⱦ����>\n" + renderHeight + "\n\n"
                ;
        if (cCameraGameObject != null)
        {
            strContent += "<��Ⱦ���>\n" + cCameraGameObject.name + "\n\n";
        }
        if (targetGameObject != null)
        {
            strContent += "<Ŀ�����>\n" + targetGameObject.name + "\n\n";
        }
        File.WriteAllText(historyPath, strContent, System.Text.Encoding.GetEncoding("utf-8"));
    }

    /// <summary>
    /// ͳһ������Ⱦ
    /// </summary>
    private static void MyRenderAll()
    {
        WriteHistory();//��¼���ν�����Ⱦ������
        Debug.LogWarning("# ��ʼ��֡��Ⱦ��");

        //�������������֡���
        sysTimeStep = Time.maximumDeltaTime;
        Time.maximumDeltaTime = maxTimeStep;

        //������ʼ��
        cameraTex2D.Clear();
        texWorkIsDone = false;
        updateCount = 0;

        //Ŀ����Ⱦ����������Timeline
        targetGameObject.GetComponent<PlayableDirector>().time = startTime;
        targetGameObject.GetComponent<PlayableDirector>().Play();

        //����Ⱦ����ע�ᵽ��֡������
        myUpdate += MyUpdateFunction;
        //��ͼƬ���������йܵ�Э����
        Observable.FromCoroutine(MyCoroutineFunction).Subscribe(_ => { Time.maximumDeltaTime = sysTimeStep; });
    }

    /// <summary>
    /// ��֡��ȾTex2D�ķ���
    /// </summary>
    private static void MyUpdateFunction()
    {
        if (targetGameObject.GetComponent<PlayableDirector>().time <= endTime && targetGameObject.GetComponent<PlayableDirector>().state == PlayState.Playing)
        {
            //UnityCameraRender unityCameraRender = GetUnityCameraRender(CameraRenderChoice.default_2560x1920);
            UnityCameraRender unityCameraRender = GetUnityCameraRender(renderWidth, renderHeight);
            Camera thisCamera = cCameraGameObject.GetComponent<Camera>();
            Texture2D tex = UnityEngine.Object.Instantiate(unityCameraRender.GetViewData(thisCamera));
            cameraTex2D.Add(tex);
            updateCount++;
        }
        else
        {
            texWorkIsDone = true;
            targetGameObject.GetComponent<PlayableDirector>().Stop();
            Debug.LogWarning("# Tex2D��ȡ���� ������" + updateCount);
        }
    }

    /// <summary>
    /// ͼƬ�����ķ���
    /// </summary>
    /// <returns></returns>
    private static IEnumerator MyCoroutineFunction()
    {
        Debug.LogWarning("# ��ʼ�ȴ�Tex2D��ȡ");
        yield return new WaitUntil(() => { return texWorkIsDone; });
        Debug.LogWarning("# ��ʼͼƬ���� ��ַ��" + txtInputOutputAddress);
        DoClearFunction(ref myUpdate);
        for (int i = 0; i < cameraTex2D.Count; i++)
        {
            string pngName = BuildPNGName(i);
            WritePNG(OutputPathBuilder(txtInputOutputAddress), pngName, cameraTex2D[i]);//д��PNGͼƬ
        }
        cameraTex2D.Clear();
        Debug.LogWarning("# ͼƬ������ϣ�");
        yield break;
    }

    /// <summary>
    /// ֻ��Ⱦһ��ͼ
    /// </summary>
    private static void MyRenderOnePicCover()
    {
        WriteHistory();//��¼���ν�����Ⱦ������

        //UnityCameraRender unityCameraRender = GetUnityCameraRender(CameraRenderChoice.default_2560x1920);
        UnityCameraRender unityCameraRender = GetUnityCameraRender(renderWidth,renderHeight);
        Camera thisCamera = cCameraGameObject.GetComponent<Camera>();
        if (thisCamera.targetDisplay == 0)
        {
            Texture2D tex = unityCameraRender.GetViewData(thisCamera);
            Debug.Log(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory));
            WritePNG(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\\", DateTime.Now.ToString("M") + ".png", tex);//д��PNGͼƬ
        }
    }

    private static Dictionary<CameraRenderChoice, UnityCameraRender> m_unityCameraRenderDictionary;
    /// <summary>
    /// ���÷�װ������ȡ�����Ⱦ���󣬷�ֹƵ��new����ڴ����
    /// </summary>
    /// <param name="cameraRenderChoice"></param>
    /// <returns></returns>
    private static UnityCameraRender GetUnityCameraRender(CameraRenderChoice cameraRenderChoice)
    {
        if (m_unityCameraRenderDictionary == null)
        {
            m_unityCameraRenderDictionary = new Dictionary<CameraRenderChoice, UnityCameraRender>();
        }
        UnityCameraRender unityCameraRender;
        if (m_unityCameraRenderDictionary.TryGetValue(cameraRenderChoice, out unityCameraRender))
        {
            return unityCameraRender;
        }
        else
        {
            unityCameraRender = new UnityCameraRender(cameraRenderChoice);
            m_unityCameraRenderDictionary.Add(cameraRenderChoice, unityCameraRender);
            return unityCameraRender;
        }
    }
    private static Dictionary<string, UnityCameraRender> m_customCameraRenderDictionary;
    /// <summary>
    /// 
    /// </summary>
    /// <param name="cameraRenderChoice"></param>
    /// <returns></returns>
    private static UnityCameraRender GetUnityCameraRender(int renderwidth,int renderheight)
    {
        string mark = renderwidth.ToString() + " " + renderheight.ToString();
        if (m_customCameraRenderDictionary == null)
        {
            m_customCameraRenderDictionary = new Dictionary<string, UnityCameraRender>();
        }
        UnityCameraRender unityCameraRender;
        if (m_customCameraRenderDictionary.TryGetValue(mark, out unityCameraRender))
        {
            return unityCameraRender;
        }
        else
        {
            unityCameraRender = new UnityCameraRender(renderwidth,renderheight);
            m_customCameraRenderDictionary.Add(mark, unityCameraRender);
            return unityCameraRender;
        }
    }

    /// <summary>
    /// �����Ⱦ�Ƿ�Ϸ�
    /// </summary>
    /// <returns></returns>
    private static bool CheckRenderLegal(int condition)
    {
        m_scriptMessage = "";

        switch (condition)
        {
            case 1:
                {
                    if (cCameraGameObject == null || cCameraGameObject.GetComponent<Camera>() == null)
                    {
                        m_scriptMessage = "�������ȷ";
                        return false;
                    }
                    break;
                }
            case 2:
                {
                    if (targetGameObject == null || targetGameObject.GetComponent<PlayableDirector>() == null)
                    {
                        m_scriptMessage = "��������ȷ";
                        return false;
                    }
                    break;
                }
            default:return false;
        }
        return true;
    }

    /// <summary>
    /// д��PNGͼƬ
    /// </summary>
    /// <param name="pngName"></param>
    /// <param name="pngTex"></param>
    private static void WritePNG(string pathName, string pngName, Texture2D pngTex)
    {
        byte[] bytes = pngTex.EncodeToPNG();//���������ݣ�ת����һ��pngͼƬ
        File.WriteAllBytes(pathName + pngName, bytes);//д������
    }
    #endregion

    #region Util���߸�������
    /// <summary>
    /// ��ȡ����Ϣ��Ŀ���ļ�Ϊutf8����
    /// ���ʺͶ�������
    /// </summary>
    /// <param name="filePath"></param>
    /// <param name="keyStr"></param>
    /// <param name="lines"></param>
    /// <returns></returns>
    private static string[] MyReadTxtUTF8(string filePath, string keyStr = "", int lines = -1)
    {
        try
        {
            string[] fileContent = File.ReadAllLines(filePath);
            if (lines == -1)
            {
                return fileContent;
            }
            for (int i = 0; i < fileContent.Length; i++)
            {
                if (fileContent[i].Contains(keyStr))
                {
                    string[] strLine = new string[lines + 1];
                    strLine[0] = fileContent[i];
                    for (int j = 0; j < lines; j++)
                    {
                        strLine[j + 1] = fileContent[i + j + 1];
                    }
                    return strLine;
                }
            }
            return null;
        }
        catch (Exception e)
        {
            m_scriptMessage = "�ļ���ȡ�쳣[UTF8]";
            Debug.LogError(e);
            return null;
        }
    }

    /// <summary>
    /// ����png���ƣ�����Ϊ1����3λΪ֡��ţ���11֡Ϊ1011��100֡Ϊ1100
    /// </summary>
    /// <param name="frameNo"></param>
    /// <returns></returns>
    private static string BuildPNGName(int frameNo)
    {
        string result = "1";
        if (frameNo >= 100 && frameNo <= 999)
        {
            return result + frameNo + ".png";
        }
        else if (frameNo >= 10 && frameNo <= 99)
        {
            return result + "0" + frameNo + ".png";
        }
        else if (frameNo >= 0 && frameNo <= 9)
        {
            return result + "00" + frameNo + ".png";
        }
        else
        {
            m_scriptMessage = "ͼƬ�������󣡽ű�������\"0000.png\"";
            Debug.LogError("ͼƬ��������! " + frameNo + " (BuildPNGName)");
            return "0000.png";
        }
    }

    /// <summary>
    /// ��ϻ�ȡĿ���ļ���·��
    /// </summary>
    /// <param name="rootPath"></param>
    /// <param name="direction"></param>
    /// <param name="action"></param>
    /// <returns></returns>
    private static string OutputPathBuilder(string rootPath)
    {
        string fixPath = rootPath.EndsWith("\\") ? rootPath : rootPath + "\\";
        return fixPath;
    }

    /// <summary>
    /// ����һ��ί��
    /// </summary>
    /// <param name="myAction"></param>
    private static void DoClearFunction(ref Action myAction)
    {
        while (myAction != null)
        {
            myAction -= myAction;
        }
    }

    /// <summary>
    /// ��������
    /// </summary>
    private static void MyReleaseMemory()
    {
        //��ȷ���Ƿ��������
        Resources.UnloadUnusedAssets();
        System.GC.Collect();
    }

    private struct DoubleClickFlag
    {
        public string key;
        public int value;
        public int timer;
    }
    private static DoubleClickFlag m_DoubleClickFlag;
    private static bool DoubleClickChecker(string actionName)
    {
        if (m_DoubleClickFlag.key != actionName)
        {
            m_DoubleClickFlag.key = actionName;
            m_DoubleClickFlag.value = 0;
            m_DoubleClickFlag.timer = 0;
            //Debug.LogWarning("˫����ʱ���䶯��"+actionName);
        }
        else if (m_DoubleClickFlag.key != "")
        {
            m_DoubleClickFlag.value++;
            m_DoubleClickFlag.timer = 0;
            //Debug.LogWarning("˫����ʱ���ڶ��ε����" + actionName);
        }
        if (m_DoubleClickFlag.value == 1)
        {
            m_DoubleClickFlag.key = "";
            m_DoubleClickFlag.value = 0;
            m_DoubleClickFlag.timer = 0;
            //Debug.LogWarning("˫����ʱ���ڶ��ε����λ");
            return true;
        }
        else
        {
            return false;
        }
    }
    private static void DoubleClickTimerTicker()
    {
        if (m_DoubleClickFlag.key != "")
        {
            m_DoubleClickFlag.timer++;
            if (m_DoubleClickFlag.timer >= 60)
            {
                m_DoubleClickFlag.key = "";
                m_DoubleClickFlag.value = 0;
                m_DoubleClickFlag.timer = 0;
                //Debug.LogWarning("˫����ʱ����ʱ��λ");
            }
        }
    }
    #endregion
}
