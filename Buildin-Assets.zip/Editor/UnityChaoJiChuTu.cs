﻿using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using System;
//using UniRx;//如果需要异步操作，这个包还是需要使用的
//using System.Threading;//unity下的部分功能不能放在子线程中使用，因此多线程的包不一定会被需要
using UnityEngine.Playables;
using UnityEngine.Timeline;
using UnityEngine.Rendering;

/// <summary>
/// Version:0.4
/// Author:CaoQian
/// Date:2022/01/17
/// Description:Unity出图的编辑器扩展
/// </summary>
public class UnityChaoJiChuTu : EditorWindow
{
    #region params
    private static UnityChaoJiChuTu thisWindow;
    private static Rect windowRect = new Rect(10, 50, 600, 625);//窗口大小，暂时不作只读

    //在这里修改文件路径
    private static readonly string filePath = "C:\\Users\\Public\\Documents\\maxChaoJiChuTuTxt.txt";//这份文件存储出图的抽帧序列和出图地址
    private static readonly string matPath = "C:\\Users\\Public\\Documents\\maxChaoJiChuTuMat.txt";//这份文件存储材质更换的序列
    private static readonly string historyPath = "C:\\Users\\Public\\Documents\\maxChaoJiChuTuHistory.txt";//这份文件存储上一次进行渲染的配置

    //动作
    private static readonly string[] selStrings = { "待机", "攻击", "防御", "疾跑", "受伤", "死亡", "攻_击1", "攻_击2", "特效" };
    private static int actionSelection = -1;

    //方向过滤按钮
    private static bool LU_CheckButton = true;
    private static bool U_CheckButton = true;
    private static bool RU_CheckButton = true;
    private static bool L_CheckButton = true;
    private static bool R_CheckButton = true;
    private static bool LD_CheckButton = true;
    private static bool D_CheckButton = true;
    private static bool RD_CheckButton = true;
    private static bool All_CheckButton = true;

    //相机
    private static Dictionary<string, Camera> cCameras;
    private static Dictionary<string, string> cDirection;
    private static Camera c01;
    private static Camera c02;
    private static Camera c03;
    private static Camera c04;
    private static Camera c05;
    private static Camera c06;
    private static Camera c07;
    private static Camera c08;

    //脚本信息
    //private static float m_workingProgress = 1f;
    //private static string m_workingMessage = "工作信息";
    private static string m_scriptMessage = "只读脚本消息";

    //输入框
    private static string txtInputMaterialNo = "";
    private static string txtInputOutputAddress = "";
    private static string txtInputFrameSolution = "";
    private static string txtInputAnimationFrame = "";
    private static string txtInputTxtAddress = "";
    private static string txtInputMatAddress = "";

    //协程与紧急停止//由于unity主线程有些东西没法进行操作，这部分功能暂不作实现，代码暂不进行删除
    //private static IDisposable renderHandler;
    //private static bool stopSingnal = false;

    //对象配置 包括相机组、灯光组，主渲染对象和材质
    private static GameObject cCameraGameObject;
    private static GameObject lightGameObject;
    private static GameObject targetGameObject;
    private static int materialsQuantity = 0;
    private static List<Material> targetMaterials;

    private static Action frameFn = null;

    //相机调整的部分参数
    //使用正交相机时（请不要使用正交相机，否则得不到正确的特效）
    //相机的orthographic size=1.852，得到与3dmax中35mm镜头焦距等价的效果，对应photoshop16切
    //相机的orthographic size=2.315，得到与3dmax中28mm镜头焦距等价的效果，对应Photoshop20切
    //使用透视相机时
    //相机的filed of view=2，得到与3dmax中35mm镜头焦距等价的效果，对应photoshop16切
    //相机的filed of view=2.5，得到与3dmax中28mm镜头焦距等价的效果，对应Photoshop20切
    //视图使用2560*1920，得到的就是等价于相机渲染的视图
    private static readonly float[] cCameraSize = { 2, 2.5f };//{ 1.852f, 2.315f };
    private static readonly float[,,] cCameraPos =
    {
        {
            { 0,44.88f,96.36f },
            { 68.148f,44.88f,68.148f},
            { 96.36f,44.88f,0},
            { 68.148f,44.88f,-68.148f},
            { 0,44.88f,-96.36f},
            { -68.148f,44.88f,-68.148f},
            { -96.36f,44.88f,0},
            { -68.148f,44.88f,68.148f},
        }
        //如果需要添加新的相机配置，在这后面加
    };

    //地面阴影调整的部分参数
    //由于后处理的外轮廓方法，导致描边颜色的混合方法发生变化，导致阴影颜色与原颜色不同，且深浅变化呈非线性变化
    //private static readonly float[] spot001ShadowStrength = { 0, 0.457f, 0.644f };//原参数
    private static readonly float[] spot001ShadowStrength = { 0, 0.68f, 0.8f, 0.457f, 0.644f };//新参数

    //unity TimeLine下动画相对3dmax动画/抽帧方案产生的固定偏移，这个数字随动作类型加载和改变
    private static int currentAnimationTimelineOffset = 0;

    #endregion

    #region 脚本UI与初始化
    [MenuItem("Tools/unityChaoJiChuTu #r")]
    static void unityChaoJiChuTu_Start()
    {
        ScriptInit();
        thisWindow = (UnityChaoJiChuTu)GetWindowWithRect(typeof(UnityChaoJiChuTu), windowRect, true, "UnityChaoJiChuTu");//new Rect(10, 10, 600, 425)
        thisWindow.Show();
    }

    private void OnGUI()
    {
        //==============================================//模块0：非GUI按键监测

        //==============================================//模块1：相机
        GUILayout.BeginArea(new Rect(5, 5, 180, 140));
        GUI.Label(new Rect(0, 0, 60, 20), "选择相机");

        if (GUI.Button(new Rect(0, 20, 50, 30), "左上"))
        {
            c06 = GetCameraByName("c06");
            cCameras["c06"] = c06;
            ExcludeOtherCameraAndSetTargetDisplay(c06);
            SetLightRotation("左上");
        }
        if (GUI.Button(new Rect(60, 20, 50, 30), "上"))
        {
            c05 = GetCameraByName("c05");
            cCameras["c05"] = c05;
            ExcludeOtherCameraAndSetTargetDisplay(c05);
            SetLightRotation("上");
        }
        if (GUI.Button(new Rect(120, 20, 50, 30), "右上"))
        {
            c04 = GetCameraByName("c04");
            cCameras["c04"] = c04;
            ExcludeOtherCameraAndSetTargetDisplay(c04);
            SetLightRotation("右上");
        }

        if (GUI.Button(new Rect(0, 60, 50, 30), "左"))
        {
            c07 = GetCameraByName("c07");
            cCameras["c07"] = c07;
            ExcludeOtherCameraAndSetTargetDisplay(c07);
            SetLightRotation("左");
        }

        if (GUI.Button(new Rect(120, 60, 50, 30), "右"))
        {
            c03 = GetCameraByName("c03");
            cCameras["c03"] = c03;
            ExcludeOtherCameraAndSetTargetDisplay(c03);
            SetLightRotation("右");
        }

        if (GUI.Button(new Rect(0, 100, 50, 30), "左下"))
        {
            c08 = GetCameraByName("c08");
            cCameras["c08"] = c08;
            ExcludeOtherCameraAndSetTargetDisplay(c08);
            SetLightRotation("左下");
        }
        if (GUI.Button(new Rect(60, 100, 50, 30), "下"))
        {
            c01 = GetCameraByName("c01");
            cCameras["c01"] = c01;
            ExcludeOtherCameraAndSetTargetDisplay(c01);
            SetLightRotation("下");
        }
        if (GUI.Button(new Rect(120, 100, 50, 30), "右下"))
        {
            c02 = GetCameraByName("c02");
            cCameras["c02"] = c02;
            ExcludeOtherCameraAndSetTargetDisplay(c02);
            SetLightRotation("右下");
        }
        GUILayout.EndArea();

        //==============================================//模块2：动作种类
        GUILayout.BeginArea(new Rect(5, 150, 180, 140));
        GUI.Label(new Rect(0, 0, 60, 20), "动作种类");
        int actionOldSelection = actionSelection;
        actionSelection = GUI.SelectionGrid(new Rect(0, 20, 170, 100), actionSelection, selStrings, 3);
        if (actionSelection != actionOldSelection)
        {
            if (targetGameObject != null)
            {
                ActiveTimeLineTrack(GetActionStr());
            }
            ReadFileAction();
        }
        GUILayout.EndArea();

        //==============================================//模块3：渲染方向
        GUILayout.BeginArea(new Rect(5, 285, 180, 140));
        GUI.Label(new Rect(0, 0, 60, 20), "渲染方向");
        LU_CheckButton = GUI.Toggle(new Rect(0, 20, 50, 20), LU_CheckButton, "左上");
        U_CheckButton = GUI.Toggle(new Rect(60, 20, 50, 20), U_CheckButton, "上");
        RU_CheckButton = GUI.Toggle(new Rect(120, 20, 50, 20), RU_CheckButton, "右上");

        L_CheckButton = GUI.Toggle(new Rect(0, 40, 50, 20), L_CheckButton, "左");
        R_CheckButton = GUI.Toggle(new Rect(120, 40, 50, 20), R_CheckButton, "右");

        LD_CheckButton = GUI.Toggle(new Rect(0, 60, 60, 20), LD_CheckButton, "左下");
        D_CheckButton = GUI.Toggle(new Rect(60, 60, 60, 20), D_CheckButton, "下");
        RD_CheckButton = GUI.Toggle(new Rect(120, 60, 60, 20), RD_CheckButton, "右下");

        bool temp_All_CheckButton = All_CheckButton;
        All_CheckButton = GUI.Toggle(new Rect(120, 0, 60, 20), All_CheckButton, "全部");
        if (All_CheckButton != temp_All_CheckButton)
        {
            LU_CheckButton = All_CheckButton;
            U_CheckButton = All_CheckButton;
            RU_CheckButton = All_CheckButton;
            L_CheckButton = All_CheckButton;
            R_CheckButton = All_CheckButton;
            LD_CheckButton = All_CheckButton;
            D_CheckButton = All_CheckButton;
            RD_CheckButton = All_CheckButton;
        }
        GUILayout.EndArea();

        //==============================================//模块4：标准化
        GUILayout.BeginArea(new Rect(200, 285, 250, 200));
        GUI.Label(new Rect(0, 0, 100, 20), "相机/阴影标准化");
        if (GUI.Button(new Rect(0, 20, 60, 30), "35mm"))
        {
            NormalizeCamera();
        }
        if (GUI.Button(new Rect(63, 20, 60, 30), "28mm"))
        {
            NormalizeCamera(1);
        }
        if (GUI.Button(new Rect(126, 20, 60, 30), "相机归位"))
        {
            SetCameraPosition(0);
        }
        if (GUI.Button(new Rect(189, 20, 60, 30), "无阴影"))
        {
            SetSpot001ShadowStrength(0);
        }
        if (GUI.Button(new Rect(0, 53, 60, 30), "浅阴影1"))
        {
            SetSpot001ShadowStrength(1);
        }
        if (GUI.Button(new Rect(63, 53, 60, 30), "深阴影1"))
        {
            SetSpot001ShadowStrength(2);
        }
        if (GUI.Button(new Rect(126, 53, 60, 30), "浅阴影2"))
        {
            SetSpot001ShadowStrength(3);
        }
        if (GUI.Button(new Rect(189, 53, 60, 30), "深阴影2"))
        {
            SetSpot001ShadowStrength(4);
        }
        GUILayout.EndArea();

        //==============================================//模块5：用户输入区域
        GUILayout.BeginArea(new Rect(200, 5, 250, 300));
        GUI.Label(new Rect(0, 0, 60, 20), "材质序列");
        txtInputMaterialNo = GUI.TextField(new Rect(0, 20, 250, 20), txtInputMaterialNo);

        GUI.Label(new Rect(0, 45, 60, 20), "输出地址");
        txtInputOutputAddress = GUI.TextField(new Rect(0, 65, 250, 20), txtInputOutputAddress);

        GUI.Label(new Rect(0, 90, 60, 20), "抽帧方案");
        txtInputFrameSolution = GUI.TextField(new Rect(0, 110, 250, 20), txtInputFrameSolution);

        GUI.Label(new Rect(0, 135, 60, 20), "动画序列");
        txtInputAnimationFrame = GUI.TextField(new Rect(0, 155, 250, 20), txtInputAnimationFrame);

        GUI.Label(new Rect(0, 180, 80, 20), "txt文件地址");
        txtInputTxtAddress = GUI.TextField(new Rect(0, 200, 250, 20), txtInputTxtAddress);

        GUI.Label(new Rect(0, 225, 80, 20), "mat文件地址");
        txtInputMatAddress = GUI.TextField(new Rect(0, 245, 250, 20), txtInputMatAddress);
        GUILayout.EndArea();

        //==============================================//模块6：主操作按钮
        GUILayout.BeginArea(new Rect(200, 380, 250, 200));
        GUI.Label(new Rect(0, 0, 60, 20), "操作按钮");
        if (GUI.Button(new Rect(0, 20, 60, 30), "写入历史"))
        {
            //ReadHistory();
            WriteHistory();
        }
        if (GUI.Button(new Rect(63, 20, 60, 30), "修改序列"))
        {
            ModifyFrameTxt();
        }
        if (GUI.Button(new Rect(126, 20, 60, 30), "材质测试"))
        {
            if (targetGameObject != null)
            {
                SwitchMaterialAndAccessoriesAndDo(() => { });//配件开关和材质替换测试，仅显示替换到的最后一个材质
            }
            else
            {
                m_scriptMessage = "主渲染对象不能为空！";
            }
        }
        if (GUI.Button(new Rect(189, 20, 60, 30), "动画测试"))
        {
            if (targetGameObject != null)
            {
                PlayFrameAnimation();//播放动画测试
            }
            else
            {
                m_scriptMessage = "主渲染对象不能为空！";
            }
        }

        if (GUI.Button(new Rect(0, 53, 60, 30), "全套渲染"))
        {
            if (DoubleClickChecker("全套渲染"))
            {
                if (targetGameObject != null)
                {
                    RenewCamera();
                    //RenewMesh();//这个方法的调用放在循环内切换配件后执行
                    MyRenderAll();
                    m_scriptMessage = "图片渲染完成！(MyRenderAll)";
                    MyReleaseMemory();
                }
                else
                {
                    m_scriptMessage = "主渲染对象不能为空！";
                }
            }
        }
        if (GUI.Button(new Rect(63, 53, 60, 30), "全色渲染"))
        {
            if (DoubleClickChecker("全色渲染"))
            {
                if (targetGameObject != null)
                {
                    RenewCamera();
                    //RenewMesh();//这个方法的调用放在循环内切换配件后执行
                    SwitchMaterialAndAccessoriesAndDo(MyRender);
                    m_scriptMessage = "图片渲染完成！(SwitchMaterialAndAccessoriesAndDo)";
                    MyReleaseMemory();
                }
                else
                {
                    m_scriptMessage = "主渲染对象不能为空！";
                }
            }
        }
        if (GUI.Button(new Rect(126, 53, 60, 30), "单套渲染"))
        {
            if (DoubleClickChecker("单套渲染"))
            {
                if (targetGameObject != null)
                {
                    RenewCamera();
                    RenewMesh();
                    MyRenderOneSuit();
                    m_scriptMessage = "图片渲染完成！";
                    MyReleaseMemory();
                }
                else
                {
                    m_scriptMessage = "主渲染对象不能为空！(MyRenderOneSuit)";
                }
            }
        }
        if (GUI.Button(new Rect(189, 53, 60, 30), "渲染当前"))
        {
            if (DoubleClickChecker("渲染当前"))
            {
                if (targetGameObject != null)
                {
                    RenewCamera();
                    RenewMesh();
                    MyRender();
                    m_scriptMessage = "图片渲染完成！";
                    MyReleaseMemory();
                }
                else
                {
                    m_scriptMessage = "主渲染对象不能为空！(MyRender)";
                }
            }
        }
        if (GUI.Button(new Rect(0, 86, 60, 30), "单图渲染"))
        {
            if (DoubleClickChecker("单图渲染"))
            {
                RenewCamera();
                RenewMesh();
                MyRenderOnePic();
                m_scriptMessage = "图片渲染完成！(MyRenderOnePic)";
                MyReleaseMemory();
            }
        }
        if (GUI.Button(new Rect(63, 86, 60, 30), "单图覆盖"))
        {
            if (DoubleClickChecker("单图覆盖"))
            {
                RenewCamera();
                RenewMesh();
                MyRenderOnePicCover();
                m_scriptMessage = "图片渲染完成！(MyRenderOnePic)";
                MyReleaseMemory();
            }
        }

        GUI.Label(new Rect(0, 120, 60, 20), "脚本消息");
        GUI.TextField(new Rect(0, 140, 250, 20), m_scriptMessage);
        GUILayout.EndArea();

        //==============================================//模块7：配置对象
        GUILayout.BeginArea(new Rect(5, 380, 250, 200));
        GUI.Label(new Rect(0, 0, 60, 20), "配置对象");
        GUI.Label(new Rect(5, 25, 80, 20), "相机组");
        cCameraGameObject = (GameObject)EditorGUI.ObjectField(new Rect(60, 25, 100, 20), cCameraGameObject, typeof(GameObject), true);
        GUI.Label(new Rect(5, 50, 80, 20), "灯光组");
        lightGameObject = (GameObject)EditorGUI.ObjectField(new Rect(60, 50, 100, 20), lightGameObject, typeof(GameObject), true);
        GUI.Label(new Rect(5, 75, 80, 20), "主对象");
        targetGameObject = (GameObject)EditorGUI.ObjectField(new Rect(60, 75, 100, 20), targetGameObject, typeof(GameObject), true);
        GUILayout.EndArea();

        //==============================================//模块8：配置材质
        GUILayout.BeginArea(new Rect(475, 5, 120, 625));
        GUI.Label(new Rect(0, 0, 60, 20), "材质数量");
        int materialObjectFieldQuantity = materialsQuantity = EditorGUI.IntField(new Rect(60, 0, 50, 20), "", materialsQuantity);
        if (materialsQuantity >= 21)
        {
            materialObjectFieldQuantity = 20;
            m_scriptMessage = "手动配置的材质数量过多！！(超过20上限，至少目前是20个)";
        }
        if (materialsQuantity < 0)
        {
            materialObjectFieldQuantity = 0;
            m_scriptMessage = "手动配置的材质数量过少！！(数量不能为负)";
        }
        for (int i = 1; i <= materialObjectFieldQuantity; i++)
        {
            if (targetMaterials.Count < i)
            {
                Material newMat = (Material)EditorGUI.ObjectField(new Rect(0, 25 * i, 100, 20), null, typeof(Material), true);
                targetMaterials.Add(newMat);
            }
            else
            {
                targetMaterials[i - 1] = (Material)EditorGUI.ObjectField(new Rect(0, 25 * i, 100, 20), targetMaterials[i - 1], typeof(Material), true);
            }
        }
        GUILayout.EndArea();


        //==============================================//模块9：进度显示与其他（如果不解决多线程问题这部分是无效的）
        //如果有比较方便的实现思路，可以补进度条、紧急停止按钮的功能
        /*
        GUILayout.BeginArea(new Rect(5, 375, 180, 40));
        GUI.Label(new Rect(0, 0, 60, 20), "执行进度");
        GUI.DrawTexture(new Rect(0, 20, 75, 20), Texture2D.grayTexture);//进度条灰色底纹
        GUI.DrawTexture(new Rect(2, 22, 71 * m_workingProgress, 16), Texture2D.whiteTexture, ScaleMode.StretchToFill, true, 0, Color.red, 0, 0);//红色进度条，用白色材质+红色染色
        GUI.Label(new Rect(0, 20, 80, 20), m_workingMessage);
        GUI.Label(new Rect(80, 0, 60, 20), "开发按钮");
        if (GUI.Button(new Rect(80, 20, 40, 20), "停止"))
        {
            m_scriptMessage = "停止按钮按下！";
        }
        if (GUI.Button(new Rect(125, 20, 40, 20), "其他"))
        {
            m_scriptMessage = "其他按钮按下！";
        }
        GUILayout.EndArea();
        */
        //==============================================//
    }

    private void Update()
    {
        if (frameFn == null)
        {
            frameFn = () => { };
        }
        else
        {
            frameFn();
        }
        DoubleClickTimerTicker();
    }

    /// <summary>
    /// 脚本初始化
    /// </summary>
    private static void ScriptInit()
    {
        if (thisWindow != null)
        {
            thisWindow.position = windowRect;
        }
        if (!File.Exists(filePath))
        {
            txtInputTxtAddress = filePath;
            File.WriteAllText(filePath, "请输入图片导出地址\n\n" +
                "待机\n\n\n" + "攻击\n\n\n" + "防御\n\n\n" +
                "疾跑\n\n\n" + "受伤\n\n\n" + "死亡\n\n\n" +
                "攻_击1\n\n\n" + "攻_击2\n\n\n" + "特效\n\n\n");
        }
        if (!File.Exists(matPath))
        {
            txtInputMatAddress = matPath;
            /*
            File.WriteAllText(matPath, "通用\n" +//这个是旧的默认材质文件
                "0\n\n" + "正常(待机、防御、疾跑)\n" + "0\n\n" +
                "晕眩(死亡、受击)\n" + "0\n\n" +
                "攻击\n" + "0\n");
            */
            File.WriteAllText(matPath, "通用\n" + "0\n\n" +
                "待机\n" + "0\n\n" +
                "攻击\n" + "0\n\n" +
                "防御\n" + "0\n\n" +
                "疾跑\n" + "0\n\n" +
                "受伤\n" + "0\n\n" +
                "死亡\n" + "0\n\n");
        }
        if (!File.Exists(historyPath))
        {
            File.WriteAllText(historyPath, "#历史记录#\n" +
                "<材质序列>\n\n\n" +
                "<输出地址>\n\n\n" +
                "<抽帧方案>\n\n\n" +
                "<动画序列>\n\n\n" +
                "<txt文件地址>\n\n\n" +
                "<mat文件地址>\n\n\n" +
                "<相机角度>\n");
        }
        ReadHistory();

        c01 = GetCameraByName("c01");
        c02 = GetCameraByName("c02");
        c03 = GetCameraByName("c03");
        c04 = GetCameraByName("c04");
        c05 = GetCameraByName("c05");
        c06 = GetCameraByName("c06");
        c07 = GetCameraByName("c07");
        c08 = GetCameraByName("c08");

        cCameras = new Dictionary<string, Camera>();
        cCameras.Add("c01", c01);
        cCameras.Add("c02", c02);
        cCameras.Add("c03", c03);
        cCameras.Add("c04", c04);
        cCameras.Add("c05", c05);
        cCameras.Add("c06", c06);
        cCameras.Add("c07", c07);
        cCameras.Add("c08", c08);


        cDirection = new Dictionary<string, string>();
        cDirection.Add("c01", "下");
        cDirection.Add("c02", "右下");
        cDirection.Add("c03", "右");
        cDirection.Add("c04", "右上");
        cDirection.Add("c05", "上");
        cDirection.Add("c06", "左上");
        cDirection.Add("c07", "左");
        cDirection.Add("c08", "左下");

        GetLight();

        targetMaterials = new List<Material>();

        frameFn = () => { };//尝试去初始化一个空方法
    }
    #endregion

    #region 脚本功能方法
    /// <summary>
    /// 获取场景中的摄像机对象
    /// </summary>
    /// <param name="name"></param>
    /// <returns></returns>
    private static Camera GetCameraByName(string name)
    {
        if (cCameraGameObject != null)
        {
            foreach (Transform theTransform in cCameraGameObject.GetComponentsInChildren<Transform>())
            {
                if (theTransform.GetComponent<Camera>() != null && theTransform.name.Equals(name))
                {
                    return theTransform.GetComponent<Camera>();
                }
            }
        }
        else
        {
            cCameraGameObject = GameObject.Find("RenderBox");
            if (cCameraGameObject != null)
            {
                return GetCameraByName(name);
            }
        }
        foreach (Camera theCamera in Camera.allCameras)
        {
            if (theCamera.name.Equals(name))
            {
                return theCamera;
            }
        }
        m_scriptMessage = "场景中的相机阵列不符合渲染要求！！";
        return null;
    }

    /// <summary>
    /// 排除其他视图干扰，在Display1下仅显示当前目标摄像机效果
    /// </summary>
    /// <param name="cCamera"></param>
    private static void ExcludeOtherCameraAndSetTargetDisplay(Camera cCamera)
    {
        foreach (Camera theCamera in Camera.allCameras)
        {
            if (theCamera.Equals(cCamera))
            {
                theCamera.targetDisplay = 0;//在Display1视图输出渲染效果
            }
            else
            {
                theCamera.targetDisplay = -1;//待研究-1的合理性
            }
        }
    }

    /// <summary>
    /// 获取场景中的灯光对象
    /// </summary>
    private static void GetLight()
    {
        if (lightGameObject != null)
        {
            return;
        }
        lightGameObject = GameObject.Find("LightBox");
        if (lightGameObject != null)
        {
            return;
        }
        m_scriptMessage = "场景中的灯光阵列不符合渲染要求";
    }

    /// <summary>
    /// 设置场景中灯光的角度
    /// </summary>
    private static void SetLightRotation(string cCameraNameOrDirection)
    {
        float offset = 0;
        switch (cCameraNameOrDirection)
        {
            case "c01": offset = 0; break;
            case "c02": offset = 1; break;
            case "c03": offset = 2; break;
            case "c04": offset = 3; break;
            case "c05": offset = 4; break;
            case "c06": offset = 5; break;
            case "c07": offset = 6; break;
            case "c08": offset = 7; break;
            case "下": offset = 0; break;
            case "右下": offset = 1; break;
            case "右": offset = 2; break;
            case "右上": offset = 3; break;
            case "上": offset = 4; break;
            case "左上": offset = 5; break;
            case "左": offset = 6; break;
            case "左下": offset = 7; break;
            default: offset = 0; break;
        }
        if (lightGameObject != null)
        {
            lightGameObject.transform.localEulerAngles = new Vector3(0, 45 * offset, 0);
        }
    }

    /// <summary>
    /// 读取历史
    /// </summary>
    private static void ReadHistory()
    {
        try
        {
            txtInputMaterialNo = MyReadTxtGB2312(historyPath, "材质序列", 1)[1];
            txtInputOutputAddress = MyReadTxtGB2312(historyPath, "输出地址", 1)[1];
            txtInputFrameSolution = MyReadTxtGB2312(historyPath, "抽帧方案", 1)[1];
            txtInputAnimationFrame = MyReadTxtGB2312(historyPath, "动画序列", 1)[1];
            txtInputTxtAddress = MyReadTxtGB2312(historyPath, "txt文件地址", 1)[1];
            txtInputMatAddress = MyReadTxtGB2312(historyPath, "mat文件地址", 1)[1];
        }
        catch { }

        try
        {
            actionSelection = ReadIntFromString(MyReadTxtGB2312(historyPath, "动作类型", 1)[1])[0];
        }
        catch { }
        try
        {
            cCameraGameObject = GameObject.Find(MyReadTxtGB2312(historyPath, "相机组", 1)[1]);
        }
        catch { }
        try
        {
            lightGameObject = GameObject.Find(MyReadTxtGB2312(historyPath, "灯光组", 1)[1]);
        }
        catch { }
        try
        {
            targetGameObject = GameObject.Find(MyReadTxtGB2312(historyPath, "主渲染对象", 1)[1]);
        }
        catch { }

        m_scriptMessage = "读取历史完成！";
    }

    /// <summary>
    /// 写入历史
    /// </summary>
    private static void WriteHistory()
    {
        string strContent = "#历史记录#\n" +
                "<材质序列>\n" + txtInputMaterialNo + "\n\n" +
                "<输出地址>\n" + txtInputOutputAddress + "\n\n" +
                "<抽帧方案>\n" + txtInputFrameSolution + "\n\n" +
                "<动画序列>\n" + txtInputAnimationFrame + "\n\n" +
                "<txt文件地址>\n" + txtInputTxtAddress + "\n\n" +
                "<mat文件地址>\n" + txtInputMatAddress + "\n\n" +
                "<动作类型>\n" + actionSelection + "\n\n"
                ;
        if (cCameraGameObject != null)
        {
            strContent += "<相机组>\n" + cCameraGameObject.name + "\n\n";
        }
        if (lightGameObject != null)
        {
            strContent += "<灯光组>\n" + lightGameObject.name + "\n\n";
        }
        if (targetGameObject != null)
        {
            strContent += "<主渲染对象>\n" + targetGameObject.name + "\n\n";
        }
        File.WriteAllText(historyPath, strContent, System.Text.Encoding.GetEncoding("gb2312"));
    }

    /// <summary>
    /// 更新写入frame.txt
    /// </summary>
    /// <param name="dirPath"></param>
    private static void WriteFrameTxt(string dirPath, string strContent)
    {
        File.WriteAllText(dirPath + "frame.txt", strContent);
    }

    /// <summary>
    /// 写入PNG图片
    /// </summary>
    /// <param name="pngName"></param>
    /// <param name="pngTex"></param>
    private static void WritePNG(string pathName, string pngName, Texture2D pngTex)
    {
        byte[] bytes = pngTex.EncodeToPNG();//将纹理数据，转换成一个png图片
        File.WriteAllBytes(pathName + pngName, bytes);//写入数据
    }

    /// <summary>
    /// 渲染当前
    /// </summary>
    private static void MyRender()
    {
        WriteHistory();//记录本次进行渲染的配置

        //UnityCameraRender unityCameraRender = new UnityCameraRender(CameraRenderChoice.default_2560x1920);//CameraRenderChoice.default_2560x1920
        UnityCameraRender unityCameraRender = GetUnityCameraRender(CameraRenderChoice.default_2560x1920);
        int[] frameArray = ReadIntFromString(txtInputFrameSolution);
        foreach (KeyValuePair<string, Camera> thisCamera in cCameras)
        {
            if (ShouldCameraRender(thisCamera.Value.name))
            {
                //设置灯光方向
                SetLightRotation(thisCamera.Value.name);
                //拼接基础地址+方向+动作
                string outputPath = OutputPathBuilder(txtInputOutputAddress, cDirection[thisCamera.Key], GetActionStr());//构造输出路径
                foreach (int frame in frameArray)
                {
                    if (targetGameObject != null && targetGameObject.GetComponent<PlayableDirector>() != null)
                    {
                        JumpToFrame(targetGameObject.GetComponent<PlayableDirector>(), frame);//使用timeline进行帧跳转功能的实现(特效)
                    }
                    Texture2D tex = unityCameraRender.GetViewData(thisCamera.Value);
                    WritePNG(outputPath, BuildPNGName(frame), tex);//写入PNG图片
                }
                WriteFrameTxt(outputPath, txtInputAnimationFrame);//写入frame.txt

                JumpToFrame(targetGameObject.GetComponent<PlayableDirector>(), 0);//在一个帧序列渲染完毕后跳转回第0帧
            }
        }
    }

    /// <summary>
    /// 渲染一套
    /// </summary>
    private static void MyRenderOneSuit()
    {
        for (int i = 0; i < selStrings.Length; i++)
        {
            if (selStrings[i].Equals("攻_击1") || selStrings[i].Equals("攻_击2") || selStrings[i].Equals("特效"))
            {
                continue;//不将攻_击1/攻_击2/特效动作纳入全动作渲染中
            }
            actionSelection = i;
            ActiveTimeLineTrack(GetActionStr());//更新时间轴状态
            ReadFileAction();//更新抽帧方案和动画序列
            MyRender();
        }
    }

    /// <summary>
    /// 全套渲染
    /// </summary>
    private static void MyRenderAll()
    {
        for (int i = 0; i < selStrings.Length; i++)
        {
            if (selStrings[i].Equals("攻_击1") || selStrings[i].Equals("攻_击2") || selStrings[i].Equals("特效"))
            {
                continue;//不将攻_击1/攻_击2/特效动作纳入全动作渲染中
            }
            actionSelection = i;
            ActiveTimeLineTrack(GetActionStr());//更新时间轴状态
            ReadFileAction();//更新抽帧方案和动画序列
            SwitchMaterialAndAccessoriesAndDo(MyRender);
        }
    }

    private static void MyRenderOnePic()
    {
        WriteHistory();//记录本次进行渲染的配置

        //UnityCameraRender unityCameraRender = new UnityCameraRender(CameraRenderChoice.default_2560x1920);//CameraRenderChoice.default_2560x1920
        UnityCameraRender unityCameraRender = GetUnityCameraRender(CameraRenderChoice.default_2560x1920);
        foreach (KeyValuePair<string, Camera> thisCamera in cCameras)
        {
            if (thisCamera.Value.targetDisplay == 0)
            {
                Texture2D tex = unityCameraRender.GetViewData(thisCamera.Value);
                Debug.Log(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory));
                WritePNG(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\\", DateTime.Now.ToString("HHmmssffff") + ".png", tex);//写入PNG图片
            }
        }
    }

    private static void MyRenderOnePicCover()
    {
        WriteHistory();//记录本次进行渲染的配置

        //UnityCameraRender unityCameraRender = new UnityCameraRender(CameraRenderChoice.default_2560x1920);//CameraRenderChoice.default_2560x1920
        UnityCameraRender unityCameraRender = GetUnityCameraRender(CameraRenderChoice.default_2560x1920);
        foreach (KeyValuePair<string, Camera> thisCamera in cCameras)
        {
            if (thisCamera.Value.targetDisplay == 0)
            {
                Texture2D tex = unityCameraRender.GetViewData(thisCamera.Value);
                Debug.Log(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory));
                WritePNG(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\\", DateTime.Now.ToString("M") + ".png", tex);//写入PNG图片
            }
        }
    }

    /// <summary>
    /// 修改frame.txt文件
    /// </summary>
    private static void ModifyFrameTxt()
    {
        foreach (KeyValuePair<string, Camera> thisCamera in cCameras)
        {
            if (ShouldCameraRender(thisCamera.Value.name))
            {
                string outPutPath = txtInputOutputAddress + cDirection[thisCamera.Key] + "\\" + GetActionStr() + "\\";//构造输出路径
                WriteFrameTxt(outPutPath, txtInputAnimationFrame);//写入frame.txt
            }
        }
        m_scriptMessage = "修改序列完成！";
    }



    /// <summary>
    /// 更换材质，需要提供材质名称
    /// 优先使用右侧材质区的材质，如果没有则去资源区寻找
    /// </summary>
    private static void SwitchMaterial(string nodeName, string materialName)
    {
        //先找材质
        Material theMaterial = null;
        for (int i = 0; i < targetMaterials.Count; i++)//右侧材质区优先
        {
            if (targetMaterials[i] != null && targetMaterials[i].name.Equals(materialName))
            {
                theMaterial = targetMaterials[i];
                break;
            }
        }
        if (theMaterial == null)//材质区没有的时候尝试从资源区获取
        {
            Dictionary<string, Material> theMats = GetMaterialFromPetFolder(targetGameObject);
            //theMaterial = theMats[materialName+".mat"];//存在字典下标不存在情况
            theMats.TryGetValue(materialName + ".mat", out theMaterial);//如果找不到则材质还是null
        }
        if (theMaterial == null)//正常获取材质的方法无法获取的时候，去取用我的预留错误材质
        {
            UnityEditor.VersionControl.Asset errMat = new UnityEditor.VersionControl.Asset("Assets/DependenceBox/MyError.mat");//从资源区加载材质
            theMaterial = new Material((Material)errMat.Load());
            m_scriptMessage = "发生了找不到材质资源的问题！详情见控制台";
            Debug.LogError("找不到材质 " + materialName + ".mat (SwitchMaterial)");
        }
        if (theMaterial == null)//如果连我的默认材质都没有了，那我真没办法了，返回吧
        {
            m_scriptMessage = "怎么回事？连错误材质资源都找不到！";
            return;
        }

        //再找节点
        foreach (Transform oneParentNode in targetGameObject.transform.GetComponentsInChildren<Transform>())
        {
            if (oneParentNode.name.Equals(nodeName))
            {
                SkinnedMeshRenderer theSMR = oneParentNode.GetComponent<SkinnedMeshRenderer>();
                if (theSMR != null)
                {
                    theSMR.sharedMaterial = theMaterial;
                }
                foreach (Transform oneNode in oneParentNode.GetComponentsInChildren<Transform>())
                {
                    theSMR = oneNode.GetComponent<SkinnedMeshRenderer>();
                    if (theSMR != null)
                    {
                        theSMR.sharedMaterial = theMaterial;
                    }
                }
                break;
            }
        }
    }

    /// <summary>
    /// 开关配件和材质然后执行指定方法（新）
    /// </summary>
    private static void SwitchMaterialAndAccessoriesAndDo(Action inLoopFunction)
    {
        string[] matInfo = MyReadTxtUTF8(txtInputMatAddress);
        try
        {
            string[] StandardArr = null;//标准通用材质
            string[] StandbyArr = null;//待机材质
            string[] AttackArr = null;//攻击材质
            string[] DefendArr = null;//防御材质
            string[] RunArr = null;//疾跑材质
            string[] GetHitArr = null;//受伤材质
            string[] DeadArr = null;//死亡材质
            #region 解析材质文件
            for (int i = 0; i < matInfo.Length; i++)
            {

                if (matInfo[i].Contains("通用"))
                {
                    int count = ReadIntFromString(matInfo[i + 1])[0];
                    StandardArr = new string[2 * count];
                    for (int j = 0; j < count; j++)
                    {
                        StandardArr[j * 2] = matInfo[i + 2 + j * 2];
                        StandardArr[j * 2 + 1] = matInfo[i + 3 + j * 2];
                    }
                    break;
                }
            }

            for (int i = 0; i < matInfo.Length; i++)
            {
                if (matInfo[i].Contains("待机"))
                {
                    int count = ReadIntFromString(matInfo[i + 1])[0];
                    StandbyArr = new string[2 * count];
                    for (int j = 0; j < count; j++)
                    {
                        StandbyArr[j * 2] = matInfo[i + 2 + j * 2];
                        StandbyArr[j * 2 + 1] = matInfo[i + 3 + j * 2];
                    }
                    break;
                }
            }
            for (int i = 0; i < matInfo.Length; i++)
            {
                if (matInfo[i].Contains("攻击"))
                {
                    int count = ReadIntFromString(matInfo[i + 1])[0];
                    AttackArr = new string[2 * count];
                    for (int j = 0; j < count; j++)
                    {
                        AttackArr[j * 2] = matInfo[i + 2 + j * 2];
                        AttackArr[j * 2 + 1] = matInfo[i + 3 + j * 2];
                    }
                    break;
                }
            }
            for (int i = 0; i < matInfo.Length; i++)
            {
                if (matInfo[i].Contains("防御"))
                {
                    int count = ReadIntFromString(matInfo[i + 1])[0];
                    DefendArr = new string[2 * count];
                    for (int j = 0; j < count; j++)
                    {
                        DefendArr[j * 2] = matInfo[i + 2 + j * 2];
                        DefendArr[j * 2 + 1] = matInfo[i + 3 + j * 2];
                    }
                    break;
                }
            }
            for (int i = 0; i < matInfo.Length; i++)
            {
                if (matInfo[i].Contains("疾跑"))
                {
                    int count = ReadIntFromString(matInfo[i + 1])[0];
                    RunArr = new string[2 * count];
                    for (int j = 0; j < count; j++)
                    {
                        RunArr[j * 2] = matInfo[i + 2 + j * 2];
                        RunArr[j * 2 + 1] = matInfo[i + 3 + j * 2];
                    }
                    break;
                }
            }
            for (int i = 0; i < matInfo.Length; i++)
            {
                if (matInfo[i].Contains("受伤"))
                {
                    int count = ReadIntFromString(matInfo[i + 1])[0];
                    GetHitArr = new string[2 * count];
                    for (int j = 0; j < count; j++)
                    {
                        GetHitArr[j * 2] = matInfo[i + 2 + j * 2];
                        GetHitArr[j * 2 + 1] = matInfo[i + 3 + j * 2];
                    }
                    break;
                }
            }
            for (int i = 0; i < matInfo.Length; i++)
            {
                if (matInfo[i].Contains("死亡"))
                {
                    int count = ReadIntFromString(matInfo[i + 1])[0];
                    DeadArr = new string[2 * count];
                    for (int j = 0; j < count; j++)
                    {
                        DeadArr[j * 2] = matInfo[i + 2 + j * 2];
                        DeadArr[j * 2 + 1] = matInfo[i + 3 + j * 2];
                    }
                    break;
                }
            }
            #endregion
            int[] materialNo = ReadIntFromString(txtInputMaterialNo);
            #region 构建名称组
            string[] defaultName = BuildGroupName();
            List<string[]> nameGroup = new List<string[]>();
            for (int i = 0; i < materialNo.Length; i++)
            {
                nameGroup.Add(BuildGroupName(materialNo[i]));//构建名称组
            }
            #endregion
            for (int i = 0; i < materialNo.Length; i++)
            {
                #region 开关配件
                JumpToFrame(targetGameObject.GetComponent<PlayableDirector>(), 0);//在开关配件之前先返回到初始状态（时间轴第0帧）
                //0//材质序号
                //1//配件时间轴名称
                //2//特效时间轴名称
                //string nameNo = nameGroup[i][0];//名称组第一位固定是材质序号
                //开关配件//名称组第二位是配件时间轴名称//相应的要求timeline中将需要开关的特效/配件做成组，组命名为T_PJ，后缀使用编号
                ActiveAccessoriesTrack("配件", nameGroup[i][1], defaultName[1]);
                //开关特效//名称组第三位是特效时间轴名称//相应的要求timeline中将需要开关的特效/配件做成组，组命名为T_TX，后缀使用编号
                ActiveAccessoriesTrack("待机", nameGroup[i][2], defaultName[2]);
                ActiveAccessoriesTrack("攻击", nameGroup[i][2], defaultName[2]);
                ActiveAccessoriesTrack("防御", nameGroup[i][2], defaultName[2]);
                ActiveAccessoriesTrack("疾跑", nameGroup[i][2], defaultName[2]);
                ActiveAccessoriesTrack("受伤", nameGroup[i][2], defaultName[2]);
                ActiveAccessoriesTrack("死亡", nameGroup[i][2], defaultName[2]);
                ActiveAccessoriesTrack("攻_击1", nameGroup[i][2], defaultName[2]);
                ActiveAccessoriesTrack("攻_击2", nameGroup[i][2], defaultName[2]);
                ActiveAccessoriesTrack("常驻", nameGroup[i][2], defaultName[2]);
                //目前一共11个时间轴轨道
                //待机    //攻击    //防御    //疾跑    //受伤    //死亡    //攻_击1  //攻_击2  //常驻    //特效    //配件
                //处理    //处理    //处理    //处理    //处理    //处理    //处理    //处理    //处理    //单出    //处理
                #endregion
                #region 更换材质
                for (int j = 0; j < StandardArr.Length / 2; j++)//通用材质是全换
                {
                    SwitchMaterial(StandardArr[j * 2], StandardArr[j * 2 + 1] + materialNo[i]);
                }
                switch (actionSelection)
                {
                    case 0://待机
                        {
                            for (int j = 0; j < StandbyArr.Length / 2; j++)
                            {
                                SwitchMaterial(StandbyArr[j * 2], StandbyArr[j * 2 + 1] + materialNo[i]);
                            }
                        }
                        break;
                    case 1://攻击
                        {
                            for (int j = 0; j < AttackArr.Length / 2; j++)
                            {
                                SwitchMaterial(AttackArr[j * 2], AttackArr[j * 2 + 1] + materialNo[i]);
                            }
                        }
                        break;
                    case 2://防御
                        {
                            for (int j = 0; j < DefendArr.Length / 2; j++)
                            {
                                SwitchMaterial(DefendArr[j * 2], DefendArr[j * 2 + 1] + materialNo[i]);
                            }
                        }
                        break;
                    case 3://疾跑
                        {
                            for (int j = 0; j < RunArr.Length / 2; j++)
                            {
                                SwitchMaterial(RunArr[j * 2], RunArr[j * 2 + 1] + materialNo[i]);
                            }
                        }
                        break;
                    case 4://受伤
                        {
                            for (int j = 0; j < GetHitArr.Length / 2; j++)
                            {
                                SwitchMaterial(GetHitArr[j * 2], GetHitArr[j * 2 + 1] + materialNo[i]);
                            }
                        }
                        break;
                    case 5://死亡
                        {
                            for (int j = 0; j < DeadArr.Length / 2; j++)
                            {
                                SwitchMaterial(DeadArr[j * 2], DeadArr[j * 2 + 1] + materialNo[i]);
                            }
                        }
                        break;
                    default: break;
                }
                #endregion
                //在开关配件操作完毕后，更新网格
                RenewMesh();
                //修改地址
                txtInputOutputAddress = ModifyOutputPath(txtInputOutputAddress, materialNo[i]);
                inLoopFunction();
            }
        }
        catch (Exception e)
        {
            m_scriptMessage = "开关配件/更换材质中发生异常(SwitchMaterialAndAccessoriesAndDoNew)";
            Debug.LogError(e);
        }
    }

    /// <summary>
    /// 设置目标节点与其子节点是否可见
    /// </summary>
    /// <param name="nodeName"></param>
    /// <param name="isVisible"></param>
    [Obsolete("SetMeshNodesVisible已经不被使用了. 利用时间轴并使用ActiveAccessoriesTrack来进行配件特效开关的管理", false)]
    private static void SetMeshNodesVisible(string nodeName, bool isVisible)
    {
        foreach (Transform oneParentNode in targetGameObject.transform.GetComponentsInChildren<Transform>())
        {
            if (oneParentNode.name.Equals(nodeName))
            {
                try
                {
                    oneParentNode.gameObject.GetComponent<SkinnedMeshRenderer>().enabled = isVisible;
                    foreach (Transform oneNode in oneParentNode.GetComponentsInChildren<Transform>())
                    {
                        oneNode.gameObject.GetComponent<SkinnedMeshRenderer>().enabled = isVisible;
                    }
                }
                catch { }
                break;
            }
        }
    }

    //这两个独立的参数仅用于实现以下执行动画播放的方法
    private static int currentAnimationPosition = 0;
    private static Dictionary<int, int> frameToAnimationPosition;
    /// <summary>
    /// 按照抽帧方案去播放动画效果
    /// </summary>
    private static void PlayFrameAnimation()
    {
        if (frameToAnimationPosition == null)
        {
            frameToAnimationPosition = new Dictionary<int, int>();
        }
        else
        {
            frameToAnimationPosition.Clear();
        }
        frameFn -= FnFrameAnimation;
        currentAnimationPosition = 0;
        string animationStr = txtInputAnimationFrame;
        int[] frameNo = ReadIntFromString(animationStr);
        if (frameNo.Length < 2)
        {
            m_scriptMessage = "动画序列格式有误！";
            return;
        }
        float realTime = (float)frameNo[0] / 2000;//这个抽帧时间/2000为大致游戏内动画的播放总时长
        float frameTime = realTime / (frameNo.Length - 1);//这个获取的是动画播放的每帧时间
        for (int i = 1; i < frameNo.Length; i++)
        {
            int framePos = (int)(frameTime * i * 60);//frameNo[i]
            while (frameToAnimationPosition.ContainsKey(framePos))
            {
                framePos++;
            }
            frameToAnimationPosition.Add(framePos, frameNo[i]);
        }
        frameFn += FnFrameAnimation;//将动画跳转注册到委托中
    }

    /// <summary>
    /// 执行播放动画的方法，需要注册到frameFn中使用
    /// </summary>
    private static void FnFrameAnimation()
    {
        if (frameToAnimationPosition.TryGetValue(currentAnimationPosition, out int nowJumpTo))
        {
            //JumpToFrame(targetGameObject.GetComponent<Animator>(), nowJumpTo);//不再直接使用animator去操控动画序列
            JumpToFrame(targetGameObject.GetComponent<PlayableDirector>(), nowJumpTo);//使用Timeline管理动画
            frameToAnimationPosition.Remove(currentAnimationPosition);
            if (frameToAnimationPosition.Count <= 0)//如果全部动画都执行完毕
            {
                frameFn -= FnFrameAnimation;
                currentAnimationPosition = 0;
            }
        }
        currentAnimationPosition++;
    }

    /// <summary>
    /// 根据当前动作选项切换序列
    /// </summary>
    private static void ReadFileAction()
    {
        string actionStr = GetActionStr();
        string fileOutputAddress = MyReadTxtUTF8(txtInputTxtAddress)[0];
        txtInputOutputAddress = fileOutputAddress;
        string[] fileActionStrs = MyReadTxtUTF8(txtInputTxtAddress, actionStr, 2);
        if (fileActionStrs != null)
        {
            txtInputFrameSolution = fileActionStrs[1];
            txtInputAnimationFrame = fileActionStrs[2];
            try
            {//目前先这样，关键字后面如果接了数字那就是偏移，没接就是无偏移，如果这里要改成具有拓展能力的再重新设计逻辑
                currentAnimationTimelineOffset = ReadIntFromString(fileActionStrs[0])[1];//读取到的第一组数字为unity内时间轴固定偏移
            }
            catch (IndexOutOfRangeException)
            {
                currentAnimationTimelineOffset = 0;
            }
        }
        else
        {
            txtInputFrameSolution = "";
            txtInputAnimationFrame = "";
        }

        string[] fileMatAddress = MyReadTxtUTF8(txtInputTxtAddress, txtInputTxtAddress, 1);
        if (fileMatAddress != null)
        {
            if (File.Exists(fileMatAddress[1]) && fileMatAddress[1] != "")
            {
                txtInputMatAddress = fileMatAddress[1];
                m_scriptMessage = "mat文件地址已更新!";
            }
            else
            {
                m_scriptMessage = "从txt读取的mat路径可能存在问题，mat文件地址不会被覆盖!";
            }
        }
        else
        {
            txtInputMatAddress = "";
        }
    }

    /// <summary>
    /// 刷新相机
    /// </summary>
    private static void RenewCamera()
    {
        c01 = GetCameraByName("c01");
        cCameras["c01"] = c01;
        c02 = GetCameraByName("c02");
        cCameras["c02"] = c02;
        c03 = GetCameraByName("c03");
        cCameras["c03"] = c03;
        c04 = GetCameraByName("c04");
        cCameras["c04"] = c04;
        c05 = GetCameraByName("c05");
        cCameras["c05"] = c05;
        c06 = GetCameraByName("c06");
        cCameras["c06"] = c06;
        c07 = GetCameraByName("c07");
        cCameras["c07"] = c07;
        c08 = GetCameraByName("c08");
        cCameras["c08"] = c08;
    }

    /// <summary>
    /// 修正相机
    /// </summary>
    /// <param name="choice"></param>
    private static void NormalizeCamera(int choice = 0)
    {
        foreach (KeyValuePair<string, Camera> thisCamera in cCameras)
        {
            //thisCamera.Value.orthographicSize = cCameraSize[choice];//正交
            thisCamera.Value.fieldOfView = cCameraSize[choice];//透视
            thisCamera.Value.depthTextureMode = DepthTextureMode.DepthNormals;//使得相机去生成自己的深度图（好像不开启也有用）
            //And More...
        }
    }

    /// <summary>
    /// 设置相机位置
    /// </summary>
    /// <param name="i">相机配置编号，在参数列表进行添加或修改</param>
    private static void SetCameraPosition(int i)
    {
        try
        {
            cCameras["c01"].transform.localPosition = new Vector3(cCameraPos[i, 0, 0], cCameraPos[i, 0, 1], cCameraPos[i, 0, 2]);
            cCameras["c02"].transform.localPosition = new Vector3(cCameraPos[i, 1, 0], cCameraPos[i, 1, 1], cCameraPos[i, 1, 2]);
            cCameras["c03"].transform.localPosition = new Vector3(cCameraPos[i, 2, 0], cCameraPos[i, 2, 1], cCameraPos[i, 2, 2]);
            cCameras["c04"].transform.localPosition = new Vector3(cCameraPos[i, 3, 0], cCameraPos[i, 3, 1], cCameraPos[i, 3, 2]);
            cCameras["c05"].transform.localPosition = new Vector3(cCameraPos[i, 4, 0], cCameraPos[i, 4, 1], cCameraPos[i, 4, 2]);
            cCameras["c06"].transform.localPosition = new Vector3(cCameraPos[i, 5, 0], cCameraPos[i, 5, 1], cCameraPos[i, 5, 2]);
            cCameras["c07"].transform.localPosition = new Vector3(cCameraPos[i, 6, 0], cCameraPos[i, 6, 1], cCameraPos[i, 6, 2]);
            cCameras["c08"].transform.localPosition = new Vector3(cCameraPos[i, 7, 0], cCameraPos[i, 7, 1], cCameraPos[i, 7, 2]);
        }
        catch (ArgumentOutOfRangeException e)
        {
            m_scriptMessage = "不存在指定相机配置";
            Debug.LogError(e);
        }
    }

    /// <summary>
    /// 设置阴影强度，这里给的三套预制的强度参数
    /// </summary>
    private static void SetSpot001ShadowStrength(int i)
    {
        foreach (Transform lights in lightGameObject.GetComponentsInChildren<Transform>())//直接遍历的方法似乎不太优雅
        {
            if (lights.name.Equals("Spot001(0.65)"))//寻找上方主灯光（也是投影灯）
            {
                lights.GetComponent<Light>().shadowStrength = spot001ShadowStrength[i];
                return;
            }
        }
    }

    /// <summary>
    /// Unity下的SkinMeshRender不会自己主动刷新（尤其是在一帧内的状态是不会主动刷新的）
    /// 但我们需要在一帧内完成渲染，所以设置主动刷新是必要的
    /// </summary>
    private static void RenewMesh()
    {
        try
        {
            foreach (Transform item in targetGameObject.GetComponentsInChildren<Transform>())
            {
                if (item.GetComponent<SkinnedMeshRenderer>() != null)
                {
                    item.GetComponent<SkinnedMeshRenderer>().forceMatrixRecalculationPerRender = true;
                }
            }
        }
        catch (Exception e) { Debug.Log(e); }
    }

    /// <summary>
    /// 启用当前动作的时间轴，禁用其他时间轴
    /// timelineName为时间轴一级目录
    /// </summary>
    private static void ActiveTimeLineTrack(string timeLineName)
    {
        TimelineAsset timelineAsset = (TimelineAsset)targetGameObject.GetComponent<PlayableDirector>().playableAsset;
        foreach (TrackAsset trackAsset in timelineAsset.GetRootTracks())
        {
            if (trackAsset.locked || trackAsset.name.Equals("配件") || trackAsset.name.Equals("常驻"))
            {
                continue;
            }
            if (trackAsset.name.Equals(timeLineName))
            {
                trackAsset.muted = false;
            }
            else
            {
                trackAsset.muted = true;
            }
        }
        targetGameObject.GetComponent<PlayableDirector>().RebuildGraph();
        //当playableAsset/playableDirector发生了变化，要用这个方法重新获得一个资源实例才能实际改变效果
        targetGameObject.GetComponent<PlayableDirector>().Evaluate();
        //修改之后scene视图不一定会重新刷新它的显示，用这个方法可以在屏幕上直接看到效果
        //合起来使用的效果等同于直接在unity Editor下进行修改
    }

    /// <summary>
    /// 启用配件轴，需要搭配材质序列一起使用
    /// timeLine1Name为一级目录
    /// timeLine2Name为二级目录
    /// filter为二级目录过滤项，提供过滤项时，包含filter的时间轴将会被禁用，但timeLine2Name始终会被启用
    /// </summary>
    private static void ActiveAccessoriesTrack(string timeLine1Name, string timeLine2Name, string filter = "")
    {
        TimelineAsset timelineAsset = (TimelineAsset)targetGameObject.GetComponent<PlayableDirector>().playableAsset;
        foreach (TrackAsset trackAsset in timelineAsset.GetRootTracks())
        {
            if (trackAsset.locked || !trackAsset.name.Equals(timeLine1Name))
            {
                continue;
            }
            foreach (TrackAsset item in trackAsset.GetChildTracks())
            {
                if (item.name.Contains(filter))//对包含filter的时间轴进行禁用
                {
                    item.muted = true;
                }
                if (item.name.Equals(timeLine2Name))//指定轴开启
                {
                    item.muted = false;
                }
            }
        }
        targetGameObject.GetComponent<PlayableDirector>().RebuildGraph();
        targetGameObject.GetComponent<PlayableDirector>().Evaluate();
    }

    #endregion

    #region Util工具辅助方法
    /// <summary>
    /// 读取行信息，目标文件为gb2312编码
    /// </summary>
    /// <param name="filePath"></param>
    /// <param name="keyStr"></param>
    /// <param name="lines"></param>
    private static string[] MyReadTxtGB2312(string filePath, string keyStr = "", int lines = -1)
    {
        try
        {
            string[] fileContent = File.ReadAllLines(filePath, System.Text.Encoding.GetEncoding("gb2312"));
            for (int i = 0; i < fileContent.Length; i++)
            {
                byte[] temp = System.Text.Encoding.GetEncoding("gb2312").GetBytes(fileContent[i]);
                temp = System.Text.Encoding.Convert(System.Text.Encoding.GetEncoding("gb2312"), System.Text.Encoding.GetEncoding("utf-8"), temp);
                fileContent[i] = System.Text.Encoding.GetEncoding("utf-8").GetString(temp);
            }
            if (lines == -1)//预留，-1为读取全部
            {
                return fileContent;
            }
            for (int i = 0; i < fileContent.Length; i++)
            {
                if (fileContent[i].Contains(keyStr))
                {
                    string[] strLine = new string[lines + 1];
                    strLine[0] = fileContent[i];
                    for (int j = 0; j < lines; j++)
                    {
                        strLine[j + 1] = fileContent[i + j + 1];
                    }
                    return strLine;
                }
            }
            return null;
        }
        catch (Exception e)
        {
            m_scriptMessage = "文件读取异常[GB2312]";
            Debug.LogError(e);
            return null;
        }
    }

    /// <summary>
    /// 读取行信息，目标文件为utf8编码
    /// 材质和动画序列
    /// </summary>
    /// <param name="filePath"></param>
    /// <param name="keyStr"></param>
    /// <param name="lines"></param>
    /// <returns></returns>
    private static string[] MyReadTxtUTF8(string filePath, string keyStr = "", int lines = -1)
    {
        try
        {
            string[] fileContent = File.ReadAllLines(filePath);
            if (lines == -1)
            {
                return fileContent;
            }
            for (int i = 0; i < fileContent.Length; i++)
            {
                if (fileContent[i].Contains(keyStr))
                {
                    string[] strLine = new string[lines + 1];
                    strLine[0] = fileContent[i];
                    for (int j = 0; j < lines; j++)
                    {
                        strLine[j + 1] = fileContent[i + j + 1];
                    }
                    return strLine;
                }
            }
            return null;
        }
        catch (Exception e)
        {
            m_scriptMessage = "文件读取异常[UTF8]";
            Debug.LogError(e);
            return null;
        }
    }

    /// <summary>
    /// 写入行信息，目标文件为gb2312编码
    /// 历史记录
    /// </summary>
    /// <param name="filePath"></param>
    /// <param name="strContent"></param>
    private static void MyWriteTextGB2312(string filePath, string[] strContent)
    {
        try
        {
            File.WriteAllLines(filePath, strContent, System.Text.Encoding.GetEncoding("gb2312"));
        }
        catch (Exception e)
        {
            m_scriptMessage = "文件写入异常[GB2312]";
            Debug.LogError(e);
        }
    }

    /// <summary>
    /// 写入行信息，目标文件为utf8编码
    /// </summary>
    /// <param name="filePath"></param>
    /// <param name="strContent"></param>
    private static void MyWriteTextUTF8(string filePath, string[] strContent)
    {
        try
        {
            File.WriteAllLines(filePath, strContent);
        }
        catch (Exception e)
        {
            m_scriptMessage = "文件写入异常[UTF8]";
            Debug.LogError(e);
        }
    }

    /// <summary>
    /// 组合获取目标文件夹路径
    /// </summary>
    /// <param name="rootPath"></param>
    /// <param name="direction"></param>
    /// <param name="action"></param>
    /// <returns></returns>
    private static string OutputPathBuilder(string rootPath, string direction, string action)
    {
        string fixPath = rootPath.EndsWith("\\") ? rootPath : rootPath + "\\";
        return fixPath + direction + "\\" + action + "\\";
    }

    /// <summary>
    /// 解析字符串，获取字符串中的Int，返回数组
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    private static int[] ReadIntFromString(string str)
    {
        int temp = 0;
        bool continuouslyNotNum = false;//连续非数字标识符
        char[] ch = str.ToCharArray();
        List<int> result = new List<int>();
        for (int i = 0; i < ch.Length; i++)
        {
            if (ch[i] >= '0' && ch[i] <= '9')
            {
                int num = ch[i] - 48;//ascii:char to int
                temp = temp * 10 + num;
                continuouslyNotNum = false;
            }
            else if (!continuouslyNotNum)
            {
                result.Add(temp);
                temp = 0;
                continuouslyNotNum = true;
            }
            else
            {
                continue;
            }
        }
        if (!continuouslyNotNum)
        {
            result.Add(temp);
        }
        return result.ToArray();
    }

    /// <summary>
    /// 从宠物文件中获取材质
    /// 使用材质名称取用
    /// </summary>
    /// <returns></returns>
    private static Dictionary<string, Material> GetMaterialFromPetFolder(GameObject targetGameObject)
    {
        string prefabPath = PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(targetGameObject);//预制体根目录
        string folderPath = prefabPath.Substring(0, prefabPath.LastIndexOf(targetGameObject.name));//项目根目录文件夹
        string matPath = folderPath + "CaiZhi/";//存放材质的文件夹
        Dictionary<string, Material> theMats = new Dictionary<string, Material>();
        DirectoryInfo dInfo = new DirectoryInfo(matPath);
        FileInfo[] fInfo = dInfo.GetFiles("*.mat");//获取所有mat文件
        foreach (FileInfo files in fInfo)
        {
            if (files.Name.EndsWith(".meta"))//排除所有meta文件
            {
                continue;
            }
            else
            {
                string matName = files.Name;//获取材质的名称
                UnityEditor.VersionControl.Asset thisMat = new UnityEditor.VersionControl.Asset(files.FullName);//从资源区加载材质
                //theMats.Add(matName, new Material((Material)thisMat.Load()));//使用资源文件的拷贝
                theMats.Add(matName, (Material)thisMat.Load());//使用源文件
            }
        }
        return theMats;
    }

    /// <summary>
    /// 修改输出地址
    /// </summary>
    /// <returns></returns>
    private static string ModifyOutputPath(string originPath, int num)
    {
        char[] trimChar = { '/', '\\' };//切除尾随的斜杠
        originPath = originPath.TrimEnd(trimChar);
        if (num < 10)
        {
            originPath = originPath.Remove(originPath.Length - 2) + "0" + num + "/";
        }
        else
        {
            originPath = originPath.Remove(originPath.Length - 2) + num + "/";
        }
        return originPath;
    }

    /// <summary>
    /// 跳转到指定动画的指定帧数
    /// unity动画状态机的缓入缓出会影响动画(如果该动画不是独立执行的话)
    /// </summary>
    /// <param name="theAnimator"></param>
    /// <param name="frameNo"></param>
    /// <param name="stateName"></param>
    [Obsolete("基于动画机的动画调整已经不被使用了. 请利用时间轴来进行动画跳转", false)]
    private static void JumpToFrame(Animator theAnimator, int frameNo, string stateName = "")
    {
        float timeBySecond = (float)frameNo / 30;//将关键帧序号转换为时间轴上的时间 animator这边使用的是每秒30帧
        if (stateName.Length > 0)
        {
            try
            {
                theAnimator.PlayInFixedTime(stateName, 0, timeBySecond);//播放指定的动画，在baselayer(0)层，播放偏移为指定时间(浮点，按秒计算)
            }
            catch (Exception e)
            {
                m_scriptMessage = "动画帧跳转发生异常：" + stateName;
                Debug.LogError(e);
            }
        }
        else
        {
            theAnimator.PlayInFixedTime(0, 0, timeBySecond);//播放当前动画
        }
        theAnimator.Update(0);//更新动画状态，不更新看不到动作
        m_scriptMessage = "动画帧跳转到 " + frameNo + " 帧(" + timeBySecond + ")";
    }

    /// <summary>
    /// 跳转到指定时间轴的指定帧数
    /// </summary>
    /// <param name="thePlayableDirector"></param>
    /// <param name="frameNo"></param>
    private static void JumpToFrame(PlayableDirector thePlayableDirector, int frameNo)
    {
        float timeBySecond = (float)(frameNo + currentAnimationTimelineOffset) / 30;//将关键帧序号转换为时间轴上的时间 timeline这边使用的是每秒30帧
        thePlayableDirector.time = timeBySecond;
        thePlayableDirector.Evaluate();
        m_scriptMessage = "动画帧跳转到 " + frameNo + " 帧(" + timeBySecond + ")";
    }

    /// <summary>
    /// 将单选按钮的选择转换成字符串
    /// </summary>
    /// <returns></returns>
    private static string GetActionStr()
    {
        switch (actionSelection)
        {
            case 0:
                return "待机";
            case 1:
                return "攻击";
            case 2:
                return "防御";
            case 3:
                return "疾跑";
            case 4:
                return "受伤";
            case 5:
                return "死亡";
            case 6:
                return "攻_击1";
            case 7:
                return "攻_击2";
            case 8:
                return "特效";
            default:
                return "未知";
        }
    }

    /// <summary>
    /// 检测当前相机是否应当执行渲染
    /// </summary>
    /// <param name="cameraName"></param>
    /// <returns></returns>
    private static bool ShouldCameraRender(string cameraName)
    {
        switch (cameraName)
        {
            case "c01": return D_CheckButton;
            case "c02": return RD_CheckButton;
            case "c03": return R_CheckButton;
            case "c04": return RU_CheckButton;
            case "c05": return U_CheckButton;
            case "c06": return LU_CheckButton;
            case "c07": return L_CheckButton;
            case "c08": return LD_CheckButton;
            default: return false;
        }
    }

    /// <summary>
    /// 构造png名称，首字为1，后3位为帧序号，如11帧为1011，100帧为1100
    /// </summary>
    /// <param name="frameNo"></param>
    /// <returns></returns>
    private static string BuildPNGName(int frameNo)
    {
        string result = "1";
        if (frameNo >= 100 && frameNo <= 999)
        {
            return result + frameNo + ".png";
        }
        else if (frameNo >= 10 && frameNo <= 99)
        {
            return result + "0" + frameNo + ".png";
        }
        else if (frameNo >= 0 && frameNo <= 9)
        {
            return result + "00" + frameNo + ".png";
        }
        else
        {
            m_scriptMessage = "图片名称有误！脚本将返回\"0000.png\"";
            Debug.LogError("图片名称有误! " + frameNo + " (BuildPNGName)");
            return "0000.png";
        }
    }

    /// <summary>
    /// 根据当前的材质编号换算配件时间轴、特效时间轴、材质的名称
    /// 省略参数将得到不带后缀参数的名称
    /// 可能需要根据需求扩展该方法
    /// </summary>
    /// <returns></returns>
    private static string[] BuildGroupName(int inputMaterialNo = -1)
    {
        string[] theNameGroup = new string[3];
        theNameGroup[0] = "";//材质序号
        theNameGroup[1] = "T_PJ";//配件时间轴名称
        theNameGroup[2] = "T_TX";//特效时间轴名称
        /*
        theNameGroup[3] = "N";//标准材质
        theNameGroup[4] = "PJ";//配件材质
        theNameGroup[5] = "Hair";//头发材质
        theNameGroup[6] = "Standby";//待机材质
        theNameGroup[7] = "Attack";//攻击材质
        theNameGroup[8] = "Defend";//防御材质
        theNameGroup[9] = "Run";//疾跑材质
        theNameGroup[10] = "GetHit";//受伤材质
        theNameGroup[11] = "Dead";//死亡材质
        */
        //0//材质序号
        //1//配件时间轴名称
        //2//特效时间轴名称
        //3//标准材质
        //4//配件材质
        //5//头发材质
        //6//待机材质
        //7//攻击材质
        //8//防御材质
        //9//疾跑材质
        //10//受伤材质
        //11//死亡材质
        //复制用//目前使用到的名称就这些，后续可以根据需求添加
        if (inputMaterialNo >= 0)
        {
            for (int i = 0; i < theNameGroup.Length; i++)
            {
                theNameGroup[i] += inputMaterialNo;
            }
        }
        return theNameGroup;
    }

    /// <summary>
    /// 垃圾回收
    /// </summary>
    private static void MyReleaseMemory()
    {
        //不确定是否真的有用
        Resources.UnloadUnusedAssets();
        System.GC.Collect();
    }

    private static Dictionary<CameraRenderChoice, UnityCameraRender> m_unityCameraRenderDictionary;
    /// <summary>
    /// 改用封装方法获取相机渲染对象，防止频繁new造成内存溢出
    /// </summary>
    /// <param name="cameraRenderChoice"></param>
    /// <returns></returns>
    private static UnityCameraRender GetUnityCameraRender(CameraRenderChoice cameraRenderChoice)
    {
        if (m_unityCameraRenderDictionary == null)
        {
            m_unityCameraRenderDictionary = new Dictionary<CameraRenderChoice, UnityCameraRender>();
        }
        UnityCameraRender unityCameraRender;
        if (m_unityCameraRenderDictionary.TryGetValue(cameraRenderChoice, out unityCameraRender))
        {
            return unityCameraRender;
        }
        else
        {
            unityCameraRender = new UnityCameraRender(cameraRenderChoice);
            m_unityCameraRenderDictionary.Add(cameraRenderChoice, unityCameraRender);
            return unityCameraRender;
        }
    }

    private struct DoubleClickFlag
    {
        public string key;
        public int value;
        public int timer;
    }
    private static DoubleClickFlag m_DoubleClickFlag;
    private static bool DoubleClickChecker(string actionName)
    {
        if (m_DoubleClickFlag.key != actionName)
        {
            m_DoubleClickFlag.key = actionName;
            m_DoubleClickFlag.value = 0;
            m_DoubleClickFlag.timer = 0;
            //Debug.LogWarning("双击计时器变动："+actionName);
        }
        else if (m_DoubleClickFlag.key != "")
        {
            m_DoubleClickFlag.value++;
            m_DoubleClickFlag.timer = 0;
            //Debug.LogWarning("双击计时器第二次点击：" + actionName);
        }
        if (m_DoubleClickFlag.value == 1)
        {
            m_DoubleClickFlag.key = "";
            m_DoubleClickFlag.value = 0;
            m_DoubleClickFlag.timer = 0;
            //Debug.LogWarning("双击计时器第二次点击归位");
            return true;
        }
        else
        {
            return false;
        }
    }
    private static void DoubleClickTimerTicker()
    {
        if (m_DoubleClickFlag.key != "")
        {
            m_DoubleClickFlag.timer++;
            if (m_DoubleClickFlag.timer >= 60)
            {
                m_DoubleClickFlag.key = "";
                m_DoubleClickFlag.value = 0;
                m_DoubleClickFlag.timer = 0;
                //Debug.LogWarning("双击计时器超时归位");
            }
        }
    }
    #endregion
}