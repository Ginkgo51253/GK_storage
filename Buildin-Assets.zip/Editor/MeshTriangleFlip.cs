﻿using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.VersionControl;
using UnityEngine;

/// <summary>
/// 翻转三角形处理脚本
/// 将mesh拖入脚本对象或者将包含mesh的文件夹拖入地址框，执行结束后会翻转mesh的三角形
/// </summary>
public class MeshTrangleFlip : EditorWindow
{
    private static List<Mesh> theMesh;
    private static int meshQuantity = 10;
    private static bool ChangedTint = false;
    private static string workingPath = "";

    [MenuItem("Tools/MeshTrangleFlip")]
    static void unityChaoJiChuTu_Start()
    {
        ScriptInit();
        MeshTrangleFlip window = (MeshTrangleFlip)GetWindowWithRect(typeof(MeshTrangleFlip), new Rect(10, 10, 160, 320), true, "MeshTrangleFlip");
        window.Show();
    }

    private void OnGUI()
    {
        if (!ChangedTint)//快捷刷新脚本窗口组件的方法，不然每次修改后都得重新打开窗口来加载静态对象
        {
            ScriptInit();
        }
        GUILayout.BeginArea(new Rect(5, 5, 150, 350));
        GUI.Label(new Rect(0, 0, 120, 20), "翻转三角面");
        for (int i = 1; i <= meshQuantity; i++)
        {
            if (theMesh.Count < i)
            {
                GUI.Label(new Rect(5, 25 * i, 20, 20), i.ToString());
                Mesh newMesh = (Mesh)EditorGUI.ObjectField(new Rect(25, 25 * i, 110, 20), null, typeof(Mesh), true);
                theMesh.Add(newMesh);
            }
            else
            {
                GUI.Label(new Rect(5, 25 * i, 20, 20), i.ToString());
                theMesh[i - 1] = (Mesh)EditorGUI.ObjectField(new Rect(25, 25 * i, 110, 20), theMesh[i - 1], typeof(Mesh), true);
            }
        }

        Rect workingPathArea = new Rect(5, 280, 80, 20);
        workingPath = GUI.TextField(workingPathArea, workingPath);
        if (workingPathArea.Contains(Event.current.mousePosition))
        {//可以使用鼠标位置判断进入指定区域
            DragAndDrop.visualMode = DragAndDropVisualMode.Generic;//改变鼠标外观
            if (Event.current.type == EventType.DragExited)
            {
                if (DragAndDrop.paths != null)
                {
                    int len = DragAndDrop.paths.Length;
                    string str = "";
                    for (int i = 0; i < len; i++)
                    {
                        str += DragAndDrop.paths[i];//输出拖入的文件或文件夹路径
                    }
                    workingPath = str;
                }
            }
        }
        if (GUI.Button(new Rect(90, 280, 50, 20), "批处理"))
        {
            ExecuteCalculation(theMesh);
            ExecuteCalculation(GetAllMeshInWorkingPath());
            Debug.LogWarning("MeshTrangleFlip:执行完成");
        }
        GUILayout.EndArea();
    }

    private static void ScriptInit()
    {
        theMesh = new List<Mesh>();
        meshQuantity = 10;
        ChangedTint = true;
        workingPath = "";
    }

    /// <summary>
    /// 执行入口
    /// </summary>
    /// <param name="meshs"></param>
    private static void ExecuteCalculation(IEnumerable<Mesh> meshs)
    {
        int count = 0;
        foreach (Mesh mesh in meshs)
        {
            if (mesh != null)
            {
                WriteTriangle(mesh);
                count++;
            }
        }
        //Debug.LogWarning("MeshSmoothNormals:执行了 " + count + " 个对象");
    }

    /// <summary>
    /// 从指定路径获取所有目标资源（仅一级目录）
    /// Asset方法只能在Editor下使用
    /// </summary>
    /// <returns></returns>
    private static List<Mesh> GetAllMeshInWorkingPath()
    {
        List<Mesh> theseMeshes = new List<Mesh>();
        if (Directory.Exists(workingPath))
        {
            DirectoryInfo dInfo = new DirectoryInfo(workingPath);
            FileInfo[] fInfo = dInfo.GetFiles("*.mesh");
            foreach (FileInfo files in fInfo)
            {
                if (files.Name.EndsWith(".meta"))
                {
                    continue;
                }
                else
                {
                    Asset thisMesh = new Asset(files.FullName);
                    theseMeshes.Add((Mesh)thisMesh.Load());
                }
            }
        }
        else
        {
            //Debug.LogWarning("MeshSmoothNormals:指定工作路径不存在");
        }
        return theseMeshes;
    }

    /// <summary>
    /// 翻转三角形
    /// </summary>
    private static void WriteTriangle(Mesh theMesh)
    {
        int[] theTriangles = theMesh.triangles;
        for (int i = 0; i < theTriangles.Length; i+=3)
        {
            int t = theTriangles[i];
            theTriangles[i] = theTriangles[i + 2];
            theTriangles[i + 2] = t;
        }
        theMesh.triangles = theTriangles;
    }
}
