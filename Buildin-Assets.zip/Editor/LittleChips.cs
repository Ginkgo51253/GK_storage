﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using System.Drawing;
using static UnityEngine.ParticleSystem;
using System.IO;

public class LittleChips : EditorWindow
{
    private static LittleChips thisWindow;
    private static Rect windowRect = new Rect(10, 50, 620, 510);//窗口大小，暂时不作只读

    #region 基础参数区域
    private static Action frameFn = null;//用于存放每帧调用的方法
    #endregion

    #region 具体参数区域
    //模块1参数
    private static GameObject psRootGameObject = null;
    private static bool is3DStartSize = false;
    private static bool isRatedOrSet = false;
    private static Vector3 psStartSize3D = Vector3.one;
    private static float psStartSize = 1;

    //模块2参数
    private static GameObject degradedTriangleRootGameObject = null;

    //模块3参数
    private static string targetPicPath = "";

    //模块4参数
    private static string rPicPath = "";
    private static string gPicPath = "";
    private static string bPicPath = "";
    private static string aPicPath = "";
    private static Vector2Int rgbaPicWidthAndHeight = new Vector2Int(64, 64);

    //模块5参数
    private static string rgbaPicPath = "";
    private static Vector2Int rgbaOutputPicWidthAndHeight = new Vector2Int(64, 64);

    //模块6参数
    private static string generateUniqueMessage = "";

    //模块7参数
    private static string expand1PixelFloderPath = "";

    //模块8参数
    private static GameObject objA = null;
    private static GameObject objB = null;


    #endregion

    #region 脚本UI与初始化
    [MenuItem("Tools/LittleChips")]
    static void LittleChips_Start()
    {
        ScriptInit();
        thisWindow = (LittleChips)GetWindowWithRect(typeof(LittleChips), windowRect, true, "LittleChips");
        thisWindow.Show();
    }

    private void OnGUI()
    {
        //==============================================//模块1：粒子缩放功能
        GUILayout.BeginArea(new Rect(5, 5, 600, 60));
        GUI.Label(new Rect(0, 0, 80, 20), "#1 粒子缩放");
        GUI.Label(new Rect(0, 30, 60, 20), "根节点");
        psRootGameObject = (GameObject)EditorGUI.ObjectField(new Rect(50, 30, 80, 20), psRootGameObject, typeof(GameObject), true);
        is3DStartSize = GUI.Toggle(new Rect(150, 30, 100, 20), is3DStartSize, "2D[o]/3D[v]");
        isRatedOrSet = GUI.Toggle(new Rect(250, 30, 100, 20), isRatedOrSet, "set[o]/mul[v]");

        if (is3DStartSize)
        {
            psStartSize3D = EditorGUI.Vector3Field(new Rect(350, 30, 180, 20), "", psStartSize3D);
        }
        else
        {
            GUI.Label(new Rect(350, 28, 20, 20), "R");
            psStartSize = EditorGUI.FloatField(new Rect(365, 30, 48, 18), "", psStartSize);
        }


        if (GUI.Button(new Rect(550, 28, 50, 25), "执行"))
        {
            if (psRootGameObject != null)
            {
                if (is3DStartSize)
                {
                    DoScaleParticleSystemStartSize(psStartSize3D, isRatedOrSet);
                }
                else
                {
                    DoScaleParticleSystemStartSize(psStartSize, isRatedOrSet);
                }
            }
            else
            {
                Debug.LogWarning("#1 根节点不能为空");
            }
        }
        GUILayout.EndArea();
        //==============================================//模块3：待定功能
        GUILayout.BeginArea(new Rect(5, 65, 600, 60));
        GUI.Label(new Rect(0, 0, 200, 20), "#2 SkinMesh节点与根节点归一化");
        GUI.Label(new Rect(0, 30, 60, 20), "根节点");
        degradedTriangleRootGameObject = (GameObject)EditorGUI.ObjectField(new Rect(50, 30, 80, 20), degradedTriangleRootGameObject, typeof(GameObject), true);
        if (GUI.Button(new Rect(550, 28, 50, 25), "执行"))
        {
            if (degradedTriangleRootGameObject != null)
            {
                DoNormalizeSkinMeshRenderGameObjectTransformScale(degradedTriangleRootGameObject);
            }
            else
            {
                Debug.LogWarning("#2 根节点不能为空");
            }
        }
        GUILayout.EndArea();
        //==============================================//模块3：待定功能
        GUILayout.BeginArea(new Rect(5, 125, 600, 60));
        GUI.Label(new Rect(0, 0, 200, 20), "#3 PNG灰度图与透明图互转");
        GUI.Label(new Rect(0, 30, 60, 20), "图片路径");
        Rect workingPathArea = new Rect(60, 30, 160, 20);
        targetPicPath = GUI.TextField(workingPathArea, targetPicPath);
        targetPicPath = DoGetFilePathUsingDragAndDrop(workingPathArea, targetPicPath);
        if (GUI.Button(new Rect(355, 28, 75, 25), "黑白转白透"))
        {
            DoSwitchGeryPicToWhiteTransparentPic(targetPicPath);
        }
        if (GUI.Button(new Rect(440, 28, 75, 25), "黑白转灰透"))
        {
            DoSwitchGeryPicToGeryTransparentPic(targetPicPath);
        }
        if (GUI.Button(new Rect(525, 28, 75, 25), "透明转黑白"))
        {
            DoSwitchTransparentPicToGeryPic(targetPicPath);
        }
        GUILayout.EndArea();
        //==============================================//模块4：合并黑白图
        GUILayout.BeginArea(new Rect(5, 185, 600, 60));
        GUI.Label(new Rect(0, 0, 100, 20), "#4 合并黑白图");
        GUI.Label(new Rect(0, 30, 60, 20), "图片路径");
        GUI.Label(new Rect(70, 30, 20, 20), "R:");
        Rect rPathArea = new Rect(90, 30, 40, 20);
        rPicPath = GUI.TextField(rPathArea, rPicPath);
        rPicPath = DoGetFilePathUsingDragAndDrop(rPathArea, rPicPath);
        GUI.Label(new Rect(140, 30, 20, 20), "G:");
        Rect gPathArea = new Rect(160, 30, 40, 20);
        gPicPath = GUI.TextField(gPathArea, gPicPath);
        gPicPath = DoGetFilePathUsingDragAndDrop(gPathArea, gPicPath);
        GUI.Label(new Rect(210, 30, 20, 20), "B:");
        Rect bPathArea = new Rect(230, 30, 40, 20);
        bPicPath = GUI.TextField(bPathArea, bPicPath);
        bPicPath = DoGetFilePathUsingDragAndDrop(bPathArea, bPicPath);
        GUI.Label(new Rect(280, 30, 20, 20), "A:");
        Rect aPathArea = new Rect(300, 30, 40, 20);
        aPicPath = GUI.TextField(aPathArea, aPicPath);
        aPicPath = DoGetFilePathUsingDragAndDrop(aPathArea, aPicPath);
        GUI.Label(new Rect(360, 30, 60, 20), "图片长宽");
        rgbaPicWidthAndHeight = EditorGUI.Vector2IntField(new Rect(430, 30, 100, 20), "", rgbaPicWidthAndHeight);
        if (GUI.Button(new Rect(550, 28, 50, 25), "执行"))
        {
            DoMergeMultiGeryPic(rPicPath, gPicPath, bPicPath, aPicPath, rgbaPicWidthAndHeight);
        }
        GUILayout.EndArea();
        //==============================================//模块5：拆分黑白图
        GUILayout.BeginArea(new Rect(5, 245, 600, 60));
        GUI.Label(new Rect(0, 0, 100, 20), "#5 拆分黑白图");
        GUI.Label(new Rect(0, 30, 60, 20), "图片路径");
        GUI.Label(new Rect(360, 30, 60, 20), "图片长宽");
        GUI.Label(new Rect(70, 30, 40, 20), "RGBA:");
        Rect rgbaPathArea = new Rect(110, 30, 40, 20);
        rgbaPicPath = GUI.TextField(rgbaPathArea, rgbaPicPath);
        rgbaPicPath = DoGetFilePathUsingDragAndDrop(rgbaPathArea, rgbaPicPath);
        rgbaOutputPicWidthAndHeight = EditorGUI.Vector2IntField(new Rect(430, 30, 100, 20), "", rgbaOutputPicWidthAndHeight);
        if (GUI.Button(new Rect(550, 28, 50, 25), "执行"))
        {
            DoSplitRGBAPic(rgbaPicPath, rgbaOutputPicWidthAndHeight);
        }
        GUILayout.EndArea();
        //==============================================//模块6：生成独特信息
        GUILayout.BeginArea(new Rect(5, 305, 600, 60));
        GUI.Label(new Rect(0, 0, 120, 20), "#6 生成独特信息");
        GUI.TextField(new Rect(0, 30, 250, 20), generateUniqueMessage);
        if (GUI.Button(new Rect(550, 28, 50, 25), "生成"))
        {
            generateUniqueMessage = GenerateUniqueMessage();
        }
        GUILayout.EndArea();
        //==============================================//模块7：待定功能
        GUILayout.BeginArea(new Rect(5, 365, 600, 60));
        GUI.Label(new Rect(0, 0, 100, 20), "#7 图片扩展1像素");
        GUI.Label(new Rect(0, 30, 80, 20), "文件夹路径");
        expand1PixelFloderPath = GUI.TextField(new Rect(70, 30, 160, 20), expand1PixelFloderPath);
        expand1PixelFloderPath = DoGetFilePathUsingDragAndDrop(new Rect(70, 30, 160, 20), expand1PixelFloderPath);
        if (GUI.Button(new Rect(550, 28, 50, 25), "执行"))
        {
            OnExpand1PixelBtnClicked(expand1PixelFloderPath);
        }
        GUILayout.EndArea();
        //==============================================//模块8：对齐
        GUILayout.BeginArea(new Rect(5, 425, 600, 60));
        GUI.Label(new Rect(0, 0, 160, 20), "#8 对象B对齐对象A");
        GUI.Label(new Rect(0, 30, 60, 20), "A节点");
        objA = (GameObject)EditorGUI.ObjectField(new Rect(50, 30, 80, 20), objA, typeof(GameObject), true);
        GUI.Label(new Rect(150, 30, 60, 20), "B节点");
        objB = (GameObject)EditorGUI.ObjectField(new Rect(200, 30, 80, 20), objB, typeof(GameObject), true);
        if (GUI.Button(new Rect(440, 28, 75, 25), "局部对齐"))
        {
            if(objA != null && objB != null)
            {
                objB.transform.localPosition = objA.transform.localPosition;
                objB.transform.localRotation = objA.transform.localRotation;
            }
        }
        if (GUI.Button(new Rect(525, 28, 75, 25), "世界对齐"))
        {
            if (objA != null && objB != null)
            {
                objB.transform.position = objA.transform.position;
                objB.transform.rotation = objA.transform.rotation;
            }
        }
        GUILayout.EndArea();
        //==============================================//模块9：待定功能
        GUILayout.BeginArea(new Rect(5, 485, 600, 60));
        GUI.Label(new Rect(0, 0, 80, 20), "#9 待定功能");
        GUI.Label(new Rect(0, 30, 60, 20), "……");
        GUILayout.EndArea();
        //==============================================//模块？？？：待定功能
    }


    private static void ScriptInit()
    {
        psRootGameObject = null;
        is3DStartSize = false;
        isRatedOrSet = false;
        psStartSize3D = Vector3.one;
        psStartSize = 1;
    }

    private void Update()
    {
        if (frameFn == null)
        {
            frameFn = () => { };
        }
        else
        {
            frameFn();
        }
    }

    #endregion

    #region 脚本扩展功能
    /// <summary>
    /// 操作非3DStartSize
    /// </summary>
    /// <param name="scale"></param>
    /// <param name="isSetOrRated"></param>
    private static void DoScaleParticleSystemStartSize(float scale, bool isSetOrRated)
    {
        MainModule currentMainModule;
        if (isSetOrRated)
        {
            foreach (ParticleSystem thePS in psRootGameObject.GetComponentsInChildren<ParticleSystem>())
            {
                currentMainModule = thePS.main;
                if (!currentMainModule.startSize3D)
                {
                    currentMainModule.startSizeMultiplier *= scale;
                }
            }
        }
        else
        {
            foreach (ParticleSystem thePS in psRootGameObject.GetComponentsInChildren<ParticleSystem>())
            {
                currentMainModule = thePS.main;
                if (!currentMainModule.startSize3D)
                {
                    currentMainModule.startSizeMultiplier = scale;
                }
            }
        }
    }

    /// <summary>
    /// 操作3DStartSize
    /// </summary>
    /// <param name="scale"></param>
    /// <param name="isSetOrRated"></param>
    private static void DoScaleParticleSystemStartSize(Vector3 scale, bool isSetOrRated)
    {
        MainModule currentMainModule;
        if (isSetOrRated)
        {
            foreach (ParticleSystem thePS in psRootGameObject.GetComponentsInChildren<ParticleSystem>())
            {
                currentMainModule = thePS.main;
                if (currentMainModule.startSize3D)
                {
                    currentMainModule.startSizeXMultiplier *= scale.x;
                    currentMainModule.startSizeYMultiplier *= scale.y;
                    currentMainModule.startSizeZMultiplier *= scale.z;
                }
            }
        }
        else
        {
            foreach (ParticleSystem thePS in psRootGameObject.GetComponentsInChildren<ParticleSystem>())
            {
                currentMainModule = thePS.main;
                if (currentMainModule.startSize3D)
                {
                    currentMainModule.startSizeXMultiplier *= scale.x;
                    currentMainModule.startSizeYMultiplier *= scale.y;
                    currentMainModule.startSizeZMultiplier *= scale.z;
                }
            }
        }
    }

    private static void DoNormalizeSkinMeshRenderGameObjectTransformScale(GameObject rootGameObject)
    {
        foreach (SkinnedMeshRenderer cell in rootGameObject.GetComponentsInChildren<SkinnedMeshRenderer>())
        {
            Vector3 v3Scale = Vector3.one;
            Transform currentNode = cell.transform.parent;
            while (!currentNode.Equals(rootGameObject.transform))
            {
                v3Scale.Scale(currentNode.transform.localScale);
                currentNode = currentNode.parent;
            }
            v3Scale.Scale(rootGameObject.transform.localScale);
            v3Scale.x = 1 / v3Scale.x;
            v3Scale.y = 1 / v3Scale.y;
            v3Scale.z = 1 / v3Scale.z;
            cell.transform.localScale = v3Scale;
        }
    }


    /// <summary>
    /// 灰度图转白色透明图
    /// </summary>
    /// <param name="path"></param>
    private static void DoSwitchGeryPicToWhiteTransparentPic(string path)
    {
        Bitmap oriBitmap = null;
        oriBitmap = GetBitmapFromFile(path);
        if (oriBitmap == null)
        {
            return;
        }

        Bitmap bitmap = new Bitmap(oriBitmap.Width, oriBitmap.Height);
        try
        {
            for (int i = 0; i < oriBitmap.Width; i++)
            {
                for (int j = 0; j < oriBitmap.Height; j++)
                {
                    System.Drawing.Color oriColor = oriBitmap.GetPixel(i, j);
                    System.Drawing.Color newColor;
                    int newAlpha = (oriColor.R + oriColor.G + oriColor.B) / 3;
                    newColor = System.Drawing.Color.FromArgb(newAlpha, 255, 255, 255);
                    bitmap.SetPixel(i, j, newColor);
                }
            }
            string[] str = DoGetPathAndFilename(path);
            bitmap.Save(str[0] + "[wTran]" + str[1]);
#if UNITY_EDITOR
            UnityEditor.AssetDatabase.Refresh();
#endif
        }
        catch (Exception e)
        {
            Debug.LogError(e);
        }
        oriBitmap.Dispose();
    }

    /// <summary>
    /// 灰度图转黑白透明图
    /// </summary>
    /// <param name="path"></param>
    private static void DoSwitchGeryPicToGeryTransparentPic(string path)
    {
        Bitmap oriBitmap = null;
        oriBitmap = GetBitmapFromFile(path);
        if (oriBitmap == null)
        {
            return;
        }

        Bitmap bitmap = new Bitmap(oriBitmap.Width, oriBitmap.Height);
        try
        {
            for (int i = 0; i < oriBitmap.Width; i++)
            {
                for (int j = 0; j < oriBitmap.Height; j++)
                {
                    System.Drawing.Color oriColor = oriBitmap.GetPixel(i, j);
                    System.Drawing.Color newColor;
                    int newAlpha = (oriColor.R + oriColor.G + oriColor.B) / 3;
                    newColor = System.Drawing.Color.FromArgb(newAlpha, newAlpha, newAlpha, newAlpha);
                    bitmap.SetPixel(i, j, newColor);
                }
            }
            string[] str = DoGetPathAndFilename(path);
            bitmap.Save(str[0] + "[gTran]" + str[1]);
            UnityEditor.AssetDatabase.Refresh();
        }
        catch (Exception e)
        {
            Debug.LogError(e);
        }
        oriBitmap.Dispose();
    }

    /// <summary>
    /// 透明图转灰度图
    /// </summary>
    /// <param name="path"></param>
    private static void DoSwitchTransparentPicToGeryPic(string path)
    {
        Bitmap oriBitmap = null;
        oriBitmap = GetBitmapFromFile(path);
        if (oriBitmap == null)
        {
            return;
        }

        Bitmap bitmap = new Bitmap(oriBitmap.Width, oriBitmap.Height);
        try
        {
            for (int i = 0; i < oriBitmap.Width; i++)
            {
                for (int j = 0; j < oriBitmap.Height; j++)
                {
                    System.Drawing.Color oriColor = oriBitmap.GetPixel(i, j);
                    System.Drawing.Color newColor;
                    int newRGB = oriColor.A;
                    newColor = System.Drawing.Color.FromArgb(255, newRGB, newRGB, newRGB);
                    bitmap.SetPixel(i, j, newColor);
                }
            }
            string[] str = DoGetPathAndFilename(path);
            bitmap.Save(str[0] + "[Gery]" + str[1]);
            UnityEditor.AssetDatabase.Refresh();
        }
        catch (Exception e)
        {
            Debug.LogError(e);
        }
        oriBitmap.Dispose();
    }


    private static string[] DoGetPathAndFilename(string path)
    {
        string[] str = { "", "" };
        int separateLocation = path.LastIndexOf("/");
        str[0] = path.Substring(0, separateLocation + 1);
        str[1] = path.Substring(separateLocation + 1, path.Length - separateLocation - 1);
        return str;
    }

    private static void DoMergeMultiGeryPic(string rPicName, string gPicName, string bPicName, string aPicName, Vector2Int widthAndHeight)
    {
        Bitmap rBitMap = GetBitmapFromFile(rPicName);
        Bitmap gBitMap = GetBitmapFromFile(gPicName);
        Bitmap bBitMap = GetBitmapFromFile(bPicName);
        Bitmap aBitMap = GetBitmapFromFile(aPicName);
        if (rBitMap != null || gBitMap != null || bBitMap != null || aBitMap != null)
        {
            Bitmap bitmap = new Bitmap(widthAndHeight.x, widthAndHeight.y);
            int loopI, loopJ;
            System.Drawing.Color rColor, gColor, bColor, aColor;
            for (loopI = 0; loopI < bitmap.Width; loopI++)
            {
                for (loopJ = 0; loopJ < bitmap.Height; loopJ++)
                {
                    if (rBitMap != null)
                    {
                        rColor = rBitMap.GetPixel(rBitMap.Width * loopI / bitmap.Width, rBitMap.Height * loopJ / bitmap.Height);
                    }
                    else
                    {
                        rColor = System.Drawing.Color.Black;
                    }
                    if (gBitMap != null)
                    {
                        gColor = gBitMap.GetPixel(gBitMap.Width * loopI / bitmap.Width, gBitMap.Height * loopJ / bitmap.Height);
                    }
                    else
                    {
                        gColor = System.Drawing.Color.Black;
                    }
                    if (bBitMap != null)
                    {
                        bColor = bBitMap.GetPixel(bBitMap.Width * loopI / bitmap.Width, bBitMap.Height * loopJ / bitmap.Height);
                    }
                    else
                    {
                        bColor = System.Drawing.Color.Black;
                    }
                    if (aBitMap != null)
                    {
                        aColor = aBitMap.GetPixel(aBitMap.Width * loopI / bitmap.Width, aBitMap.Height * loopJ / bitmap.Height);
                    }
                    else
                    {
                        aColor = System.Drawing.Color.White;
                    }
                    System.Drawing.Color newColor;
                    int theA = (aColor.R + aColor.G + aColor.B) / 3;
                    int theR = (rColor.R + rColor.G + rColor.B) / 3;
                    int theG = (gColor.R + gColor.G + gColor.B) / 3;
                    int theB = (bColor.R + bColor.G + bColor.B) / 3;
                    newColor = System.Drawing.Color.FromArgb(theA, theR, theG, theB);//argb
                    bitmap.SetPixel(loopI, loopJ, newColor);
                }
            }
            string outputPath =
            Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) +
            "\\" +
            DateTime.Now.ToString("HHmmss") +
            " Merged.png"
            ;
            bitmap.Save(outputPath);
        }
    }

    private void DoSplitRGBAPic(string rgbaPicPath, Vector2Int widthAndHeight)
    {
        Bitmap rgbaBitMap = GetBitmapFromFile(rgbaPicPath);
        if (rgbaBitMap != null)
        {
            Bitmap bitmapR = new Bitmap(widthAndHeight.x, widthAndHeight.y);
            Bitmap bitmapG = new Bitmap(widthAndHeight.x, widthAndHeight.y);
            Bitmap bitmapB = new Bitmap(widthAndHeight.x, widthAndHeight.y);
            Bitmap bitmapA = new Bitmap(widthAndHeight.x, widthAndHeight.y);
            int loopI, loopJ;
            System.Drawing.Color rgbaColor;
            for (loopI = 0; loopI < widthAndHeight.x; loopI++)
            {
                for (loopJ = 0; loopJ < widthAndHeight.y; loopJ++)
                {
                    rgbaColor = rgbaBitMap.GetPixel(rgbaBitMap.Width * loopI / widthAndHeight.x, rgbaBitMap.Height * loopJ / widthAndHeight.y);
                    System.Drawing.Color newColor1, newColor2, newColor3, newColor4;
                    newColor1 = System.Drawing.Color.FromArgb(255, rgbaColor.A, rgbaColor.A, rgbaColor.A);
                    newColor2 = System.Drawing.Color.FromArgb(255, rgbaColor.R, rgbaColor.R, rgbaColor.R);
                    newColor3 = System.Drawing.Color.FromArgb(255, rgbaColor.G, rgbaColor.G, rgbaColor.G);
                    newColor4 = System.Drawing.Color.FromArgb(255, rgbaColor.B, rgbaColor.B, rgbaColor.B);
                    bitmapA.SetPixel(loopI, loopJ, newColor1);
                    bitmapR.SetPixel(loopI, loopJ, newColor2);
                    bitmapG.SetPixel(loopI, loopJ, newColor3);
                    bitmapB.SetPixel(loopI, loopJ, newColor4);
                }
            }
            string outputPath =
            Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) +
            "\\" +
            DateTime.Now.ToString("HHmmss") +
            " ";
            bitmapA.Save(outputPath + " A.png");
            bitmapR.Save(outputPath + " R.png");
            bitmapG.Save(outputPath + " G.png");
            bitmapB.Save(outputPath + " B.png");
        }
    }

    /// <summary>
    /// 总指定文件读取bitmap
    /// </summary>
    /// <param name="filename"></param>
    /// <returns></returns>
    private static Bitmap GetBitmapFromFile(string filename)
    {
        Bitmap oriBitmap = null;
        try
        {
            oriBitmap = (Bitmap)System.Drawing.Image.FromFile(filename);
        }
        catch
        {
            if (oriBitmap == null)
            {
                Debug.LogWarning("文件地址不正确！");
            }
            else
            {
                oriBitmap.Dispose();
                Debug.LogWarning("文件格式不正确！(BMP/GIF/JPEG/PNG/TIFF)");
            }
            return null;
        }
        return oriBitmap;
    }

    private static string GenerateUniqueMessage()
    {
        string msg = "测试信息(" + Environment.UserName + "): " + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
        return msg;
    }


    private static void OnExpand1PixelBtnClicked(string path)
    {
        string floderPath = path;//txtInputMergeFolder;
        DirectoryInfo directoryInfo;
        try
        {
            directoryInfo = new DirectoryInfo(floderPath);
            if (directoryInfo == null)
            {
                Debug.LogError("找不到指定目录！ Path = " + floderPath);
                return;
            }
        }
        catch (Exception e)
        {
            Debug.LogError("合并目录不能为空！ " + e);
            return;
        }

        try
        {
            string resultPath = Path.Combine(floderPath, "处理后");
            if (!Directory.Exists(resultPath))
                Directory.CreateDirectory(resultPath);//在当前目录下创建一个名称为“处理后”的文件夹
            FileInfo[] images = directoryInfo.GetFiles("*.png");
            for (int l = 0; l < images.Length; l++)
            {
                Bitmap result = MyExpand1PixelFn2(images[l].FullName);
                result.Save(Path.Combine(resultPath, images[l].Name));
            }
            Debug.LogWarning("完成图片扩展！");
        }
        catch (Exception e)
        {
            Debug.LogWarning("图片扩展存在问题！ " + e);
        }
    }

    /// <summary>
    /// 标准混合函数
    /// 颜色和透明度使用传统混合
    /// </summary>
    /// <param name="back"></param>
    /// <param name="front"></param>
    /// <returns></returns>
    private static Bitmap MyExpand1PixelFn1(string ImgPath)
    {
        Bitmap frontBitmap = (Bitmap)System.Drawing.Image.FromFile(ImgPath);
        Bitmap bitmap = new Bitmap(frontBitmap.Width, frontBitmap.Height);
        try
        {
            for (int i = 0; i < frontBitmap.Width; i++)
            {
                for (int j = 0; j < frontBitmap.Height; j++)
                {
                    System.Drawing.Color color0 = frontBitmap.GetPixel(i, j);
                    if (color0.A > 0)
                    {
                        bitmap.SetPixel(i, j, color0);
                        continue;
                    }
                    int colorA = color0.A;
                    int colorR = color0.R;
                    int colorG = color0.G;
                    int colorB = color0.B;
                    int count = 0;
                    if (i > 0)
                    {
                        var temp = frontBitmap.GetPixel(i - 1, j);
                        if (temp.A > 0)
                        {
                            colorA += temp.A;
                            colorR += temp.R;
                            colorG += temp.G;
                            colorB += temp.B;
                            count++;
                        }
                    }
                    if (i < frontBitmap.Width - 1)
                    {
                        var temp = frontBitmap.GetPixel(i + 1, j);
                        if (temp.A > 0)
                        {
                            colorA += temp.A;
                            colorR += temp.R;
                            colorG += temp.G;
                            colorB += temp.B;
                            count++;
                        }
                    }
                    if (j > 0)
                    {
                        var temp = frontBitmap.GetPixel(i, j - 1);
                        if (temp.A > 0)
                        {
                            colorA += temp.A;
                            colorR += temp.R;
                            colorG += temp.G;
                            colorB += temp.B;
                            count++;
                        }
                    }
                    if (j < frontBitmap.Height - 1)
                    {
                        var temp = frontBitmap.GetPixel(i, j + 1);
                        if (temp.A > 0)
                        {
                            colorA += temp.A;
                            colorR += temp.R;
                            colorG += temp.G;
                            colorB += temp.B;
                            count++;
                        }
                    }
                    if(count == 0)
                    {
                        bitmap.SetPixel(i, j, System.Drawing.Color.FromArgb(0,0,0,0));
                        continue;
                    }
                    colorA /= count;
                    colorR /= count;
                    colorG /= count;
                    colorB /= count;
                    bitmap.SetPixel(i, j, System.Drawing.Color.FromArgb(colorA, colorR, colorG, colorB));
                }
            }
        }
        catch (Exception e)
        {
            Debug.LogError(e);
        }
        return bitmap;
    }

    /// <summary>
    /// 标准混合函数
    /// 颜色和透明度使用传统混合
    /// </summary>
    /// <param name="back"></param>
    /// <param name="front"></param>
    /// <returns></returns>
    private static Bitmap MyExpand1PixelFn2(string ImgPath)
    {
        Bitmap rawBitMap = (Bitmap)System.Drawing.Image.FromFile(ImgPath);
        Bitmap bitmap = new Bitmap(rawBitMap.Width, rawBitMap.Height);
        try
        {
            for (int i = 0; i < rawBitMap.Width; i++)
            {
                for (int j = 0; j < rawBitMap.Height; j++)
                {
                    System.Drawing.Color color0 = rawBitMap.GetPixel(i, j);
                    if (color0.A > 0)
                    {
                        bitmap.SetPixel(i, j, color0);
                        continue;
                    }
                    if (i == 0 || i == rawBitMap.Width - 1 || j == 0 || j == rawBitMap.Height - 1)
                    {
                        bitmap.SetPixel(i, j, color0);
                        continue;
                    }
                    int colorA = color0.A;
                    int colorR = color0.R;
                    int colorG = color0.G;
                    int colorB = color0.B;
                    int count = 0;

                    var temp = rawBitMap.GetPixel(i - 1, j);
                    if (temp.A > 0)
                    {
                        colorA += temp.A;
                        colorR += temp.R;
                        colorG += temp.G;
                        colorB += temp.B;
                        count++;
                    }
                    temp = rawBitMap.GetPixel(i + 1, j);
                    if (temp.A > 0)
                    {
                        colorA += temp.A;
                        colorR += temp.R;
                        colorG += temp.G;
                        colorB += temp.B;
                        count++;
                    }
                    temp = rawBitMap.GetPixel(i, j - 1);
                    if (temp.A > 0)
                    {
                        colorA += temp.A;
                        colorR += temp.R;
                        colorG += temp.G;
                        colorB += temp.B;
                        count++;
                    }
                    temp = rawBitMap.GetPixel(i, j + 1);
                    if (temp.A > 0)
                    {
                        colorA += temp.A;
                        colorR += temp.R;
                        colorG += temp.G;
                        colorB += temp.B;
                        count++;
                    }
                    if (count == 0)
                    {
                        bitmap.SetPixel(i, j, System.Drawing.Color.FromArgb(0, 0, 0, 0));
                        continue;
                    }
                    colorA /= count;
                    colorR /= count;
                    colorG /= count;
                    colorB /= count;
                    bitmap.SetPixel(i, j, System.Drawing.Color.FromArgb(colorA, colorR, colorG, colorB));
                }
            }
        }
        catch (Exception e)
        {
            Debug.LogError(e);
        }
        return bitmap;
    }

    #endregion

    #region Util工具辅助方法
    /// <summary>
    /// 通过鼠标托转文件到指定矩形框的方式获取文件地址
    /// 如果未拖入则不改变字符串原样输出
    /// </summary>
    /// <returns></returns>
    private static string DoGetFilePathUsingDragAndDrop(Rect rect, string oriStr)
    {
        if (rect.Contains(Event.current.mousePosition))
        {//可以使用鼠标位置判断进入指定区域
            DragAndDrop.visualMode = DragAndDropVisualMode.Generic;//改变鼠标外观
            if (Event.current.type == EventType.DragExited)
            {
                if (DragAndDrop.paths != null)
                {
                    int len = DragAndDrop.paths.Length;
                    string str = "";
                    for (int i = 0; i < len; i++)
                    {
                        str += DragAndDrop.paths[i];//输出拖入的文件或文件夹路径
                    }
                    return str;
                }
            }
        }
        return oriStr;
    }

    #endregion
}
