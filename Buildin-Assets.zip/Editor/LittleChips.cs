﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using System.Drawing;
using static UnityEngine.ParticleSystem;

public class LittleChips : EditorWindow
{
    private static LittleChips thisWindow;
    private static Rect windowRect = new Rect(10, 50, 620, 210);//窗口大小，暂时不作只读

    #region 基础参数区域
    private static Action frameFn = null;//用于存放每帧调用的方法
    #endregion

    #region 具体参数区域
    //模块1参数
    private static GameObject psRootGameObject = null;
    private static bool is3DStartSize = false;
    private static bool isRatedOrSet = false;
    private static Vector3 psStartSize3D = Vector3.one;
    private static float psStartSize = 1;

    //模块2参数
    private static GameObject degradedTriangleRootGameObject = null;

    //模块3参数
    private static string targetPicPath = "";
    #endregion

    #region 脚本UI与初始化
    [MenuItem("Tools/LittleChips")]
    static void LittleChips_Start()
    {
        ScriptInit();
        thisWindow = (LittleChips)GetWindowWithRect(typeof(LittleChips), windowRect, true, "LittleChips");//new Rect(10, 10, 600, 425)
        thisWindow.Show();
    }

    private void OnGUI()
    {
        //==============================================//模块1：粒子缩放功能
        GUILayout.BeginArea(new Rect(5, 5, 600, 60));
        GUI.Label(new Rect(0, 0, 80, 20), "#1 粒子缩放");
        GUI.Label(new Rect(0, 30, 60, 20), "根节点");
        psRootGameObject = (GameObject)EditorGUI.ObjectField(new Rect(50, 30, 80, 20), psRootGameObject, typeof(GameObject), true);
        is3DStartSize = GUI.Toggle(new Rect(150, 30, 100, 20), is3DStartSize, "2D[o]/3D[v]");
        isRatedOrSet = GUI.Toggle(new Rect(250, 30, 100, 20), isRatedOrSet, "set[o]/mul[v]");

        if (is3DStartSize)
        {
            psStartSize3D = EditorGUI.Vector3Field(new Rect(350, 30, 180, 20), "", psStartSize3D);
        }
        else
        {
            GUI.Label(new Rect(350, 28, 20, 20), "R");
            psStartSize = EditorGUI.FloatField(new Rect(365, 30, 48, 18), "", psStartSize);
        }


        if (GUI.Button(new Rect(550, 28, 50, 25), "执行"))
        {
            if (psRootGameObject != null)
            {
                if (is3DStartSize)
                {
                    DoScaleParticleSystemStartSize(psStartSize3D, isRatedOrSet);
                }
                else
                {
                    DoScaleParticleSystemStartSize(psStartSize, isRatedOrSet);
                }
            }
            else
            {
                Debug.LogWarning("#1 根节点不能为空");
            }
        }
        GUILayout.EndArea();
        //==============================================//模块3：待定功能
        GUILayout.BeginArea(new Rect(5, 65, 600, 60));
        GUI.Label(new Rect(0, 0, 200, 20), "#2 SkinMesh节点与根节点归一化");
        GUI.Label(new Rect(0, 30, 60, 20), "根节点");
        degradedTriangleRootGameObject = (GameObject)EditorGUI.ObjectField(new Rect(50, 30, 80, 20), degradedTriangleRootGameObject, typeof(GameObject), true);
        if (GUI.Button(new Rect(550, 28, 50, 25), "执行"))
        {
            if (degradedTriangleRootGameObject != null)
            {
                DoNormalizeSkinMeshRenderGameObjectTransformScale(degradedTriangleRootGameObject);
            }
            else
            {
                Debug.LogWarning("#2 根节点不能为空");
            }
        }
        GUILayout.EndArea();
        //==============================================//模块3：待定功能
        GUILayout.BeginArea(new Rect(5, 125, 600, 60));
        GUI.Label(new Rect(0, 0, 200, 20), "#3 PNG灰度图与透明图互转");
        GUI.Label(new Rect(0, 30, 60, 20), "图片路径");
        Rect workingPathArea = new Rect(60, 30, 160, 20);
        targetPicPath = GUI.TextField(workingPathArea, targetPicPath);
        if (workingPathArea.Contains(Event.current.mousePosition))
        {//可以使用鼠标位置判断进入指定区域
            DragAndDrop.visualMode = DragAndDropVisualMode.Generic;//改变鼠标外观
            if (Event.current.type == EventType.DragExited)
            {
                if (DragAndDrop.paths != null)
                {
                    int len = DragAndDrop.paths.Length;
                    string str = "";
                    for (int i = 0; i < len; i++)
                    {
                        str += DragAndDrop.paths[i];//输出拖入的文件或文件夹路径
                    }
                    targetPicPath = str;
                }
            }
        }
        if (GUI.Button(new Rect(440, 28, 75, 25), "黑白转透明"))
        {
            Debug.LogWarning(targetPicPath);
            DoSwitchGeryPicToTransparentPic(targetPicPath);
        }
        if (GUI.Button(new Rect(525, 28, 75, 25), "透明转黑白"))
        {
            DoSwitchTransparentPicToGeryPic(targetPicPath);
        }
        GUILayout.EndArea();
        //==============================================//模块4：待定功能
        GUILayout.BeginArea(new Rect(5, 185, 600, 60));
        GUI.Label(new Rect(0, 0, 80, 20), "#4 待定功能");
        GUI.Label(new Rect(0, 30, 60, 20), "……");
        GUILayout.EndArea();
        //==============================================//模块？？？：待定功能
    }


    private static void ScriptInit()
    {
        psRootGameObject = null;
        is3DStartSize = false;
        isRatedOrSet = false;
        psStartSize3D = Vector3.one;
        psStartSize = 1;
    }

    private void Update()
    {
        if (frameFn == null)
        {
            frameFn = () => { };
        }
        else
        {
            frameFn();
        }
    }

    #endregion

    #region 脚本扩展功能
    /// <summary>
    /// 操作非3DStartSize
    /// </summary>
    /// <param name="scale"></param>
    /// <param name="isSetOrRated"></param>
    private static void DoScaleParticleSystemStartSize(float scale, bool isSetOrRated)
    {
        MainModule currentMainModule;
        if (isSetOrRated)
        {
            foreach (ParticleSystem thePS in psRootGameObject.GetComponentsInChildren<ParticleSystem>())
            {
                currentMainModule = thePS.main;
                if (!currentMainModule.startSize3D)
                {
                    currentMainModule.startSizeMultiplier *= scale;
                }
            }
        }
        else
        {
            foreach (ParticleSystem thePS in psRootGameObject.GetComponentsInChildren<ParticleSystem>())
            {
                currentMainModule = thePS.main;
                if (!currentMainModule.startSize3D)
                {
                    currentMainModule.startSizeMultiplier = scale;
                }
            }
        }
    }

    /// <summary>
    /// 操作3DStartSize
    /// </summary>
    /// <param name="scale"></param>
    /// <param name="isSetOrRated"></param>
    private static void DoScaleParticleSystemStartSize(Vector3 scale, bool isSetOrRated)
    {
        MainModule currentMainModule;
        if (isSetOrRated)
        {
            foreach (ParticleSystem thePS in psRootGameObject.GetComponentsInChildren<ParticleSystem>())
            {
                currentMainModule = thePS.main;
                if (currentMainModule.startSize3D)
                {
                    currentMainModule.startSizeXMultiplier *= scale.x;
                    currentMainModule.startSizeYMultiplier *= scale.y;
                    currentMainModule.startSizeZMultiplier *= scale.z;
                }
            }
        }
        else
        {
            foreach (ParticleSystem thePS in psRootGameObject.GetComponentsInChildren<ParticleSystem>())
            {
                currentMainModule = thePS.main;
                if (currentMainModule.startSize3D)
                {
                    currentMainModule.startSizeXMultiplier *= scale.x;
                    currentMainModule.startSizeYMultiplier *= scale.y;
                    currentMainModule.startSizeZMultiplier *= scale.z;
                }
            }
        }
    }

    private static void DoNormalizeSkinMeshRenderGameObjectTransformScale(GameObject rootGameObject)
    {
        foreach(SkinnedMeshRenderer cell in rootGameObject.GetComponentsInChildren<SkinnedMeshRenderer>())
        {
            Vector3 v3Scale = Vector3.one;
            Transform currentNode = cell.transform.parent;
            while (!currentNode.Equals(rootGameObject.transform))
            {
                v3Scale.Scale(currentNode.transform.localScale);
                currentNode = currentNode.parent;
            }
            v3Scale.Scale(rootGameObject.transform.localScale);
            v3Scale.x = 1 / v3Scale.x;
            v3Scale.y = 1 / v3Scale.y;
            v3Scale.z = 1 / v3Scale.z;
            cell.transform.localScale = v3Scale;
        }
    }

    
    /// <summary>
    /// 灰度图转透明图
    /// </summary>
    /// <param name="path"></param>
    private static void DoSwitchGeryPicToTransparentPic(string path)
    {
        Bitmap oriBitmap = (Bitmap)System.Drawing.Image.FromFile(path);
        Bitmap bitmap = new Bitmap(oriBitmap.Width, oriBitmap.Height);
        try
        {
            for (int i = 0; i < oriBitmap.Width; i++)
            {
                for (int j = 0; j < oriBitmap.Height; j++)
                {
                    System.Drawing.Color oriColor = oriBitmap.GetPixel(i, j);
                    System.Drawing.Color newColor;
                    int newAlpha = (oriColor.R + oriColor.G + oriColor.B) / 3; 
                    newColor = System.Drawing.Color.FromArgb(newAlpha,255,255,255);
                    bitmap.SetPixel(i, j, newColor);
                }
            }
            string[] str = DoGetPathAndFilename(path);
            bitmap.Save(str[0] + "[Tran]" + str[1]);
        }
        catch (Exception e)
        {
            Debug.LogError(e);
        }
        oriBitmap.Dispose();
    }

    /// <summary>
    /// 透明图转灰度图
    /// </summary>
    /// <param name="path"></param>
    private static void DoSwitchTransparentPicToGeryPic(string path)
    {
        Bitmap oriBitmap = (Bitmap)System.Drawing.Image.FromFile(path);
        Bitmap bitmap = new Bitmap(oriBitmap.Width, oriBitmap.Height);
        try
        {
            for (int i = 0; i < oriBitmap.Width; i++)
            {
                for (int j = 0; j < oriBitmap.Height; j++)
                {
                    System.Drawing.Color oriColor = oriBitmap.GetPixel(i, j);
                    System.Drawing.Color newColor;
                    int newRGB = oriColor.A;
                    newColor = System.Drawing.Color.FromArgb(255, newRGB, newRGB, newRGB);
                    bitmap.SetPixel(i, j, newColor);
                }
            }
            string[] str = DoGetPathAndFilename(path);
            bitmap.Save(str[0]+"[Gery]"+str[1]);
        }
        catch (Exception e)
        {
            Debug.LogError(e);
        }
        oriBitmap.Dispose();
    }
    

    private static string[] DoGetPathAndFilename(string path)
    {
        string[] str = { "","" };
        int separateLocation = path.LastIndexOf("/");
        str[0] = path.Substring(0, separateLocation+1);
        str[1] = path.Substring(separateLocation + 1, path.Length - separateLocation -1);
        return str;
    }
    
    #endregion
}
