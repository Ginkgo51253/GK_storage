﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
public class CameraTest : MonoBehaviour
{
    [ContextMenu("CameraDepth")]
    private void Func1()
    {
        gameObject.GetComponent<Camera>().depthTextureMode = DepthTextureMode.Depth;
    }
    [ContextMenu("CameraDepthNormals")]
    private void Func2()
    {
        gameObject.GetComponent<Camera>().depthTextureMode = DepthTextureMode.DepthNormals;
    }
}
