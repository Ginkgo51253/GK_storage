﻿using UnityEngine;
using System.Collections;
using UnityEngine.Networking;
using UnityEngine.UI;

public class UnityWebTest : MonoBehaviour
{
    public Button btn1;
    public InputField InputField0;
    //public Text text1;
    public InputField InputField1;
    //public Text text2;
    public InputField InputField2;
    private Coroutine coroutine;
    
    void Start()
    {
        btn1.onClick.AddListener(() =>
        {
            if (coroutine != null)
            {
                StopCoroutine(coroutine);
            }
            coroutine = StartCoroutine(SendGetText());
        });
    }

    IEnumerator SendGetText()
    {
#if UNITY_EDITOR
        Debug.Log("协程开始");
#endif
        WWWForm form = new WWWForm();//post内容
        //form.headers["Content-Type"]= "application/x-www-form-urlencoded;charset=UTF-8";
        //form.AddField("", "");
        UnityWebRequest www;
        InputField1.text = "";
        InputField2.text = "";
        try
        {
            www = UnityWebRequest.Post(InputField0.text, form);
        }
        catch { yield break; }
        yield return www.SendWebRequest();
        if (www.isNetworkError || www.isHttpError)
        {
            InputField2.text += www.error;
        }
        else
        {
#if UNITY_EDITOR
            Debug.LogWarning("数据上传完毕");
#endif
        }


        try
        {
            www = UnityWebRequest.Get(InputField0.text);
        }
        catch { yield break; }
        if (www != null)
        {
            yield return www.SendWebRequest();
            if (www.isNetworkError || www.isHttpError)
            {
                InputField2.text += www.error;
            }
            else
            {
                // 接收文本数据，并打印到日志中
                InputField1.text += www.downloadHandler.text;

                // 接收二进制数据
                //byte[] results = www.downloadHandler.data;
            }
#if UNITY_EDITOR
            Debug.LogWarning("数据接收完毕");
#endif
        }
    }
}