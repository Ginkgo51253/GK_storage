﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

[ExecuteInEditMode]
public class MyCurveToTex : MonoBehaviour
{
    [Range(16, 256)]
    public int textureSize = 64;
    public List<ParticleSystem.MinMaxCurve> myCurves;
    public bool linkActive = false;
    public List<LinkMaterial> linkMaterials;

    private List<Texture2D> tempTex2D;
    private List<Texture2D> linkMaterialsTempTex2D;
    private void OnEnable()
    {
        if (myCurves == null)
        {
            myCurves = new List<ParticleSystem.MinMaxCurve>();
        }
        if (tempTex2D == null)
        {
            tempTex2D = new List<Texture2D>();
        }
        if (linkMaterials == null)
        {
            linkMaterials = new List<LinkMaterial>();
        }
        if (linkMaterialsTempTex2D == null)
        {
            linkMaterialsTempTex2D = new List<Texture2D>();
        }
    }

    /// <summary>
    /// 清理列表
    /// </summary>
    [ContextMenu("ClearMyGradients")]
    private void ClearMyGradients()
    {
        myCurves.Clear();
        tempTex2D.Clear();
        linkMaterials.Clear();
        linkMaterialsTempTex2D.Clear();
    }

    /// <summary>
    /// 在桌面生成渐变图PNG
    /// </summary>
    [ContextMenu("CreateGradientsPNG")]
    private void CreateGradientsPNG()
    {
        for (int i = 0; i < myCurves.Count; i++)
        {
            Texture2D theTex = CreateTex2DFromGradient(myCurves[i]);
            WritePNGFromTex2D(theTex, i.ToString());
            tempTex2D.Add(theTex);
        }
    }

    /// <summary>
    /// 生成渐变图的2d材质
    /// </summary>
    /// <returns></returns>
    private Texture2D CreateTex2DFromGradient(ParticleSystem.MinMaxCurve gradient)
    {
        Texture2D texture2D = GetTempTex2D(textureSize);
        for (int i = 0; i < texture2D.width; i++)
        {
            for (int j = 0; j < texture2D.height; j++)
            {
                float evaluateTime = (float)1 / textureSize;
                float geryScale = gradient.Evaluate(evaluateTime * i);
                Color theColor = new Color(geryScale, geryScale, geryScale,1);
                texture2D.SetPixel(i, j, theColor);
            }
        }
        texture2D.Apply();
        return texture2D;
    }

    /// <summary>
    /// 使用现成的tex2D创建贴图
    /// </summary>
    /// <param name="gradient"></param>
    /// <param name="texture2D"></param>
    private void CreateTex2DFromGradient(ParticleSystem.MinMaxCurve gradient, Texture2D texture2D)
    {
        for (int i = 0; i < texture2D.width; i++)
        {
            for (int j = 0; j < texture2D.height; j++)
            {
                float evaluateTime = (float)1 / textureSize;
                float geryScale = gradient.Evaluate(evaluateTime * i);
                Color theColor = new Color(geryScale, geryScale, geryScale, 1);
                texture2D.SetPixel(i, j, theColor);
            }
        }
        texture2D.Apply();
    }

    /// <summary>
    /// 构造PNG并导出在桌面
    /// </summary>
    /// <param name="texture2D"></param>
    /// <param name="id"></param>
    private void WritePNGFromTex2D(Texture2D texture2D, string id)
    {
        byte[] bytes = texture2D.EncodeToPNG();//将纹理数据，转换成一个png图片
        string outputPath =
            Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) +
            "\\" +
            DateTime.Now.ToString("HHmmss") +
            " Gradient" +
            id +
            ".png"
            ;
        File.WriteAllBytes(outputPath, bytes);//写入数据
    }

    /// <summary>
    /// 获取临时的贴图对象
    /// </summary>
    /// <param name="theTextureSize"></param>
    /// <returns></returns>
    private Texture2D GetTempTex2D(int theTextureSize)
    {
        foreach (Texture2D targetTex2D in tempTex2D)
        {
            if (targetTex2D.width == theTextureSize)
            {
                tempTex2D.Remove(targetTex2D);
                return targetTex2D;
            }
        }
        Texture2D newTempTex2D = new Texture2D(theTextureSize, theTextureSize);
        return newTempTex2D;
    }

    private void Update()
    {
        if (linkActive)
        {
            if (linkMaterialsTempTex2D.Count > 0)
            {
                if (linkMaterialsTempTex2D[0].width != textureSize)
                {
                    while (linkMaterialsTempTex2D.Count > 0)
                    {
                        tempTex2D.Add(linkMaterialsTempTex2D[0]);
                        linkMaterialsTempTex2D.Remove(linkMaterialsTempTex2D[0]);
                    }
                }
            }

            for (int i = 0; i < linkMaterials.Count; i++)
            {
                if (linkMaterialsTempTex2D.Count < i + 1)
                {
                    linkMaterialsTempTex2D.Add(GetTempTex2D(textureSize));
                }
                try
                {
                    CreateTex2DFromGradient(myCurves[linkMaterials[i].gradientID], linkMaterialsTempTex2D[i]);
                }
                catch (ArgumentOutOfRangeException)
                {
                    Debug.LogError("渐变索引超出其数量！最大为 " + (myCurves.Count - 1));
                }
                if (linkMaterials[i].material != null)
                {
                    linkMaterials[i].material.SetTexture("_" + linkMaterials[i].textureName, linkMaterialsTempTex2D[i]);
                }
            }
        }
        else
        {
            while (linkMaterialsTempTex2D.Count > 0)
            {
                tempTex2D.Add(linkMaterialsTempTex2D[0]);
                linkMaterialsTempTex2D.Remove(linkMaterialsTempTex2D[0]);
            }
        }
    }

    [Serializable]
    public struct LinkMaterial
    {
        public Material material;
        public string textureName;
        public int gradientID;
    }
}
