﻿using System.Diagnostics;
using UnityEngine;
using UnityEngine.UI;

public class ControlMode : MonoBehaviour
{
    private static ControlMode s_Intance;

    public Button preloadButton;

    public Text logText;

    private Stopwatch m_StopWatch = new Stopwatch();

    public Button loadOneBtn, loadAnimBtn;

    public InputField animIDInput;

    public SpriteRenderer sr;

    public Image im;

    public Button switchBtn, hotBtn, exitBtn;

    private bool doOnce = false;

    // Start is called before the first frame update
    private void Start()
    {
        s_Intance = this;
        switchBtn.GetComponentInChildren<Text>().text = GlobalDefine.newMethod ? "新" : "老";
        preloadButton.onClick.AddListener(() =>
        {
            GraphicsManager.StartPreLoad(m_StopWatch);
        });
        loadOneBtn.onClick.AddListener(() =>
        {
            m_StopWatch.Restart();
            im.sprite = GraphicsManager.LoadAnimFirstSprite(uint.Parse(animIDInput.text));
            m_StopWatch.Stop();
            Log($"加载单图{animIDInput.text}耗时：" + m_StopWatch.ElapsedTicks + "Ticks");
        });
        loadAnimBtn.onClick.AddListener(() =>
        {
            m_StopWatch.Restart();
            GraphicsManager.LoadAnimAllSprite(uint.Parse(animIDInput.text));
            m_StopWatch.Stop();
            Log("加载全图耗时：" + m_StopWatch.ElapsedTicks + "Ticks");
        });
        switchBtn.onClick.AddListener(() =>
        {
            GlobalDefine.newMethod = !GlobalDefine.newMethod;
            switchBtn.GetComponentInChildren<Text>().text = GlobalDefine.newMethod ? "新" : "老";
        });
        hotBtn.onClick.AddListener(() =>
        {
            if (!doOnce)
            {
                doOnce = true;
                Log("开始预热");
                m_StopWatch.Restart();
                GraphicsManager.Preload();
                m_StopWatch.Stop();
                Log($"预热结束 耗时：" + m_StopWatch.ElapsedTicks + "Ticks");
            }
        });
        exitBtn.onClick.AddListener(() =>
        {
            Application.Quit();
        });
    }

    private void OnDestroy()
    {
        s_Intance = null;
    }

    public static void Log(string info)
    {
        if (GlobalDefine.newMethod)
        {
            info = $"<color=black>{info}</color>";
        }
        else
        {
            info = $"<color=blue>{info}</color>";
        }
        if (s_Intance != null)
        {
            s_Intance.logText.text += '\n';
            s_Intance.logText.text += info;
        }
        UnityEngine.Debug.Log(info);
    }
}