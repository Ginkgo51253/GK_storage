using System.IO;
using System.Text;
using UnityEngine;

public static class GlobalDefine
{
    public static readonly string PERSISTENT_PATH = Application.persistentDataPath;

#if UNITY_STANDALONE_WIN && !UNITY_EDITOR
    public static readonly string ROOT_PATH = Application.dataPath;
#else
    public static readonly string ROOT_PATH = PERSISTENT_PATH;
#endif

#if UNITY_EDITOR
    public static readonly string BUILD_ASSET_PATH = Path.Combine(Application.dataPath, "_GameAssets/BuildAssets/data");
#endif

    public static readonly string DATA_PATH = Path.Combine(ROOT_PATH, "data");

    public static readonly string BIN_PATH = Path.Combine(DATA_PATH, "advanced");
    public static readonly string BIN_PATH_OLD = Path.Combine(DATA_PATH, "bin");

    public static readonly string PAL_PATH = Path.Combine(DATA_PATH, "pal");

    public const string BIN_FILE_EXT = ".bin";

    public static bool newMethod = false;
}