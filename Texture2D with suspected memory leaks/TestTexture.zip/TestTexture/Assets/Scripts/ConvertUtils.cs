﻿using System;
using System.Runtime.InteropServices;

/// <summary>
/// 转换工具类，包含了一些常用的数据转换方法
/// </summary>
public static class ConvertUtils
{
    public static T BytesToObject<T>(IntPtr buffer, byte[] bytes, int objectSize)
    {
        Marshal.Copy(bytes, 0, buffer, objectSize);
        return Marshal.PtrToStructure<T>(buffer);
    }

    public static int SizeOf<T>()
    {
        return Marshal.SizeOf<T>();
    }
}