﻿public struct AnimationData
{
    public static AnimationData invalid { get; } = new AnimationData();

    public int fileIndex;

    public ushort animationCount;

    public AnimationInfo[] animationList;

    public bool IsValid()
    {
        return animationList != null && animationList.Length > 0;
    }
}