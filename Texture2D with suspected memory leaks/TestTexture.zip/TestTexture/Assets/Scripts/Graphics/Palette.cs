﻿using System.IO;
using UnityEngine;

public class Palette
{
    private static Palette m_Normal;

    public static Palette normal
    {
        get
        {
            if (m_Normal == null)
            {
                m_Normal = new Palette(1);
            }
            return m_Normal;
        }
    }

    private const string FILE_NAME_FORMAT = "Palet_{0}.sap";

    private Color32[] m_Colors;

    public Color32[] colors
    {
        get
        {
            return m_Colors;
        }
    }

    private string m_FilePath;

    public string filePath
    {
        get
        {
            return m_FilePath;
        }
        set
        {
            m_FilePath = value;
            InitWithFile();
        }
    }

    private const int MAX_COLORS = 256;

    public Palette(Color32[] colors)
    {
        m_Colors = colors;
    }

    public Palette(int fileIndex)
    {
        m_Colors = new Color32[MAX_COLORS];
        filePath = Path.Combine(GlobalDefine.PAL_PATH, string.Format(FILE_NAME_FORMAT, fileIndex));
    }

    private void InitWithFile()
    {
        AddExtraColors();
        if (!File.Exists(m_FilePath))
        {
            return;
        }
        var fs = File.OpenRead(m_FilePath);
        for (int i = 16; i < 240; i++)
        {
            m_Colors[i].a = 0xff;
            m_Colors[i].b = (byte)fs.ReadByte();
            m_Colors[i].g = (byte)fs.ReadByte();
            m_Colors[i].r = (byte)fs.ReadByte();
        }
        fs.Dispose();
        m_Colors[168].a = 0xff;
        m_Colors[168].r = 0x00;
        m_Colors[168].g = 0x00;
        m_Colors[168].b = 0x00;
    }

    private void AddExtraColors()
    {
        m_Colors[0].a = 0x00;
        m_Colors[0].r = 0x00;
        m_Colors[0].g = 0x00;
        m_Colors[0].b = 0x00;

        m_Colors[1].a = 0xff;
        m_Colors[1].r = 0x80;
        m_Colors[1].g = 0x00;
        m_Colors[1].b = 0x00;

        m_Colors[2].a = 0xff;
        m_Colors[2].r = 0x00;
        m_Colors[2].g = 0x80;
        m_Colors[2].b = 0x00;

        m_Colors[3].a = 0xff;
        m_Colors[3].r = 0x80;
        m_Colors[3].g = 0x80;
        m_Colors[3].b = 0x00;

        m_Colors[4].a = 0xff;
        m_Colors[4].r = 0x00;
        m_Colors[4].g = 0x00;
        m_Colors[4].b = 0x80;

        m_Colors[5].a = 0xff;
        m_Colors[5].r = 0x80;
        m_Colors[5].g = 0x00;
        m_Colors[5].b = 0x80;

        m_Colors[6].a = 0xff;
        m_Colors[6].r = 0x00;
        m_Colors[6].g = 0x80;
        m_Colors[6].b = 0x80;

        m_Colors[7].a = 0xff;
        m_Colors[7].r = 0xc0;
        m_Colors[7].g = 0xc0;
        m_Colors[7].b = 0xc0;

        m_Colors[8].a = 0xff;
        m_Colors[8].r = 0xc0;
        m_Colors[8].g = 0xdc;
        m_Colors[8].b = 0xc0;

        m_Colors[9].a = 0xff;
        m_Colors[9].r = 0xa6;
        m_Colors[9].g = 0xca;
        m_Colors[9].b = 0xf0;

        m_Colors[10].a = 0xff;
        m_Colors[10].r = 0xde;
        m_Colors[10].g = 0x00;
        m_Colors[10].b = 0x00;

        m_Colors[11].a = 0xff;
        m_Colors[11].r = 0xff;
        m_Colors[11].g = 0x5f;
        m_Colors[11].b = 0x00;

        m_Colors[12].a = 0xff;
        m_Colors[12].r = 0xff;
        m_Colors[12].g = 0xff;
        m_Colors[12].b = 0xa0;

        m_Colors[13].a = 0xff;
        m_Colors[13].r = 0x00;
        m_Colors[13].g = 0x5f;
        m_Colors[13].b = 0xd2;

        m_Colors[14].a = 0xff;
        m_Colors[14].r = 0x50;
        m_Colors[14].g = 0xd2;
        m_Colors[14].b = 0xff;

        m_Colors[15].a = 0xff;
        m_Colors[15].r = 0x28;
        m_Colors[15].g = 0xe1;
        m_Colors[15].b = 0x28;

        m_Colors[240].a = 0xff;
        m_Colors[240].r = 0xf5;
        m_Colors[240].g = 0xc3;
        m_Colors[240].b = 0x96;

        m_Colors[241].a = 0xff;
        m_Colors[241].r = 0xe1;
        m_Colors[241].g = 0xa0;
        m_Colors[241].b = 0x5f;

        m_Colors[242].a = 0xff;
        m_Colors[242].r = 0xc3;
        m_Colors[242].g = 0x7d;
        m_Colors[242].b = 0x46;

        m_Colors[243].a = 0xff;
        m_Colors[243].r = 0x9b;
        m_Colors[243].g = 0x55;
        m_Colors[243].b = 0x1e;

        m_Colors[244].a = 0xff;
        m_Colors[244].r = 0x46;
        m_Colors[244].g = 0x41;
        m_Colors[244].b = 0x37;

        m_Colors[245].a = 0xff;
        m_Colors[245].r = 0x28;
        m_Colors[245].g = 0x23;
        m_Colors[245].b = 0x1e;

        m_Colors[246].a = 0xff;
        m_Colors[246].r = 0xff;
        m_Colors[246].g = 0xfb;
        m_Colors[246].b = 0xf0;

        m_Colors[247].a = 0xff;
        m_Colors[247].r = 0xa0;
        m_Colors[247].g = 0xa0;
        m_Colors[247].b = 0xa4;

        m_Colors[248].a = 0xff;
        m_Colors[248].r = 0x80;
        m_Colors[248].g = 0x80;
        m_Colors[248].b = 0x80;

        m_Colors[249].a = 0xff;
        m_Colors[249].r = 0xff;
        m_Colors[249].g = 0x00;
        m_Colors[249].b = 0x00;

        m_Colors[250].a = 0xff;
        m_Colors[250].r = 0x00;
        m_Colors[250].g = 0xff;
        m_Colors[250].b = 0x00;

        m_Colors[251].a = 0xff;
        m_Colors[251].r = 0xff;
        m_Colors[251].g = 0xff;
        m_Colors[251].b = 0x00;

        m_Colors[252].a = 0xff;
        m_Colors[252].r = 0x00;
        m_Colors[252].g = 0x00;
        m_Colors[252].b = 0xff;

        m_Colors[253].a = 0xff;
        m_Colors[253].r = 0xff;
        m_Colors[253].g = 0x00;
        m_Colors[253].b = 0xff;

        m_Colors[254].a = 0xff;
        m_Colors[254].r = 0x00;
        m_Colors[254].g = 0xff;
        m_Colors[254].b = 0xff;

        m_Colors[255].a = 0xff;
        m_Colors[255].r = 0xff;
        m_Colors[255].g = 0xff;
        m_Colors[255].b = 0xff;
    }
}