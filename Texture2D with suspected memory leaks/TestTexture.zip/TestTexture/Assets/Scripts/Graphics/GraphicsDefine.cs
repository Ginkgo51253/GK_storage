﻿using UnityEngine;

public static class GraphicsDefine
{
    public const float DEFAULT_ANIMATION_SPEED = 2f;

    /// <summary>
    /// 像素转距离系数(Sprite默认为100pixels per unit)
    /// </summary>
    public const float PIXEL_DISTANCE_RATIO = 1f / DISTANCE_PIXEL_RATIO;

    /// <summary>
    /// 距离转像素系数
    /// </summary>
    public const int DISTANCE_PIXEL_RATIO = 100;

    public const int INVISIBLE_MAP_SPRITE_ID = 99;

    public const int FRAME_PER_SECOND = 30;

    /// <summary>
    /// 最大动画数量
    /// </summary>
    public const uint MAX_ANI_COUNT = 40000;

    /// <summary>
    /// 动画的起始ID
    /// </summary>
    public const uint ANI_ID_START = 100000;

    /// <summary>
    /// 最大静态图片数量
    /// </summary>
    public const uint MAX_MAPPED_SPRITE_COUNT = 100000;

    /// <summary>
    /// 地块图片结束ID
    /// </summary>
    public const uint TILE_SPRITE_END_INDEX = 9999;

    /// <summary>
    /// 地图用图片结束ID
    /// </summary>
    public const uint MAP_SPRITE_END_INDEX = 15999;

    public const float PLAYER_RENDER_OFFSET = -0.00099f;

    public static int maxSpriteCacheCount { get; /*private*/ set; } = 10000;
}