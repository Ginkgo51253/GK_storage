﻿using System.Runtime.InteropServices;
using UnityEngine;

/// <summary>
/// Sprite的寻址信息
/// </summary>
[StructLayout(LayoutKind.Sequential)]
public struct SpriteAddrInfo {

    public uint bitmapID;

    public uint address;

    public int size;

    public int offsetX;

    public int offsetY;

    public int width;

    public int height;

    public MapSpriteInfo mapSpriteInfo;

    public byte textureFormat;

    public bool IsValid() {
        return bitmapID != 0 && width > 0 && height > 0;
    }

    public Vector2 GetPivot() {
        Vector2 pivot = Vector2.zero;
        pivot.x = -offsetX / (float)width;
        pivot.y = (height + offsetY) / (float)height;
        return pivot;
    }

}
