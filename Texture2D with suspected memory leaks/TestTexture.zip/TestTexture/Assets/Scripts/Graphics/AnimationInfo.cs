﻿using System;
using System.Runtime.InteropServices;

public struct AnimationInfo : IEquatable<AnimationInfo> {

    public static AnimationInfo invalid { get; } = new AnimationInfo();

    /// <summary>
    /// 基础的信息
    /// </summary>
    public AnimationHeader header;

    /// <summary>
    /// 实际的帧数据
    /// </summary>
    public FrameInfo[] frameList;

    public bool IsValid() {
        return header.frameCount != 0;
    }

    public bool Equals(AnimationInfo other) {
        return header.direction == other.header.direction &&
               header.type == other.header.type &&
               header.duration == other.header.duration &&
               header.frameCount == other.header.frameCount;
    }
}

[StructLayout(LayoutKind.Sequential)]
public struct AnimationHeader {

    /// <summary>
    /// 动作方向（8向）
    /// </summary>
    public ushort direction;

    /// <summary>
    /// 动作类型
    /// </summary>
    public ushort type;

    /// <summary>
    /// 动画持续时间
    /// </summary>
    public uint duration;

    /// <summary>
    /// 帧数
    /// </summary>
    public uint frameCount;

}
