﻿using System.Runtime.InteropServices;

/// <summary>
/// Sprite包含的地图绘制信息
/// </summary>
[StructLayout(LayoutKind.Sequential)]
public struct MapSpriteInfo {

    /// <summary>
    /// X方向占地
    /// </summary>
    public char atari_x;

    /// <summary>
    /// Y方向占地
    /// </summary>
    public char atari_y;

    /// <summary>
    /// 碰撞信息
    /// <para>最低位代表是否可行走0：不可行走，1：可行走</para>
    /// <para>第三位代表优先级，目前推测是决定绘制顺序的值</para>
    /// </summary>
    public ushort hit;

    public short height;//该字段目前未使用，保留是为了结构体数据对齐以获取正确的bmpID字段

    //public short broken;

    //public short inDamage;

    //public short outDamage;

    ///// <summary>
    ///// 中毒
    ///// </summary>
    //public short inPoison;

    ///// <summary>
    ///// 麻痹
    ///// </summary>
    //public short inNumb;

    //public short inQuiet;

    //public short inStone;

    //public short inDark;

    ///// <summary>
    ///// 混乱
    ///// </summary>
    //public short inConfuse;

    //public short outPoison;

    //public short outNumb;

    //public short outQuiet;

    //public short outStone;

    //public short outDark;

    //public short outConfuse;

    //public short effct1;

    //public short effect2;

    //public ushort damy_a;

    //public ushort damy_b;

    //public ushort damy_C;

    public uint bmpID;
}
