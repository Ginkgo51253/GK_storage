﻿
using System.Runtime.InteropServices;

/// <summary>
/// Sprite动画的寻址信息，从文件中读取
/// </summary>
[StructLayout(LayoutKind.Sequential)]
public struct AnimationAddrInfo {

    /// <summary>
    /// Animation编号
    /// </summary>
    public uint animationID;

    /// <summary>
    /// 该Animation在spr.bin文件中的偏移值（即地址）
    /// </summary>
    public uint offset;

    /// <summary>
    /// 角色的动作数量
    /// </summary>
    public ushort animeCount;

}
