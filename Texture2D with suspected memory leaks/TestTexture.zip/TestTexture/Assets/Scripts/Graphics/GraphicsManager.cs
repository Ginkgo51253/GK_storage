﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UniRx;
using UnityEngine;
using Object = UnityEngine.Object;

/// <summary>
/// 图形管理器，负责向表现层提供补丁图片资源
/// </summary>
public static class GraphicsManager
{
    private static SpriteDataLoader s_SpriteDataLoader;

    private static Palette s_CurrentPalette;

    private static Dictionary<uint, Sprite> s_AnimationSpriteCache = new Dictionary<uint, Sprite>();

    private static IDisposable s_PreloadAction;

    public static void Preload()
    {
        s_SpriteDataLoader = new SpriteDataLoader();
        if (!GlobalDefine.newMethod)
        {
            s_SpriteDataLoader.Load(GlobalDefine.BIN_PATH_OLD);
        }
        else
        {
            s_SpriteDataLoader.Load(GlobalDefine.BIN_PATH);
        }
        Application.quitting += Dispose;
        s_CurrentPalette = Palette.normal;
    }

    public static void StartPreLoad(Stopwatch stopwatch)
    {
        //if (s_PreloadAction == null)
        {
            s_PreloadAction = Observable.FromCoroutine(() => PreloadSpecialAnim(stopwatch)).Subscribe();
        }
    }

    private static IEnumerator PreloadSpecialAnim(Stopwatch stopwatch)
    {
        ControlMode.Log("预加载开始");
        stopwatch.Restart();
        var animDatas = s_SpriteDataLoader.animationDatas;
        int type = 3;
        for (uint i = GraphicsDefine.ANI_ID_START; i <= 100235; i += 5)
        {
            //站立 -> 5
            LoadAnimSprite(animDatas[i - GraphicsDefine.ANI_ID_START], type, i);
            yield return new WaitForEndOfFrame();
        }
        for (uint i = 101001; i <= 101119; i++)
        {
            //站立 -> 5
            LoadAnimSprite(animDatas[i - GraphicsDefine.ANI_ID_START], type, i);
            yield return new WaitForEndOfFrame();
        }
        //LoadAnimSprite(animDatas[101001 - GraphicsDefine.ANI_ID_START], type, 101001);
        //yield return new WaitForEndOfFrame();
        //for (uint i = 1; i < 6115; i++)
        //{
        //    var mappingInfo = SpriteMappingInfo.Create(animDatas[100235- GraphicsDefine.ANI_ID_START].fileIndex, i);
        //    var spriteData = GetAnimSpriteData(mappingInfo);
        //    GetSprite(spriteData);
        //}
        //yield return new WaitForEndOfFrame();
        stopwatch.Stop();
        ControlMode.Log("预加载完毕");
        ControlMode.Log("预加载耗时：" + stopwatch.ElapsedTicks + "Ticks");
        //ControlMode.Log("Sprite数量:" + s_AnimationSpriteCache.Count);
        //ControlMode.Log("Texture内存:" + Texture.currentTextureMemory);
        //Resources.UnloadUnusedAssets();
        //GC.Collect();
    }

    private static uint m_TempIndex = 0;

    public static Sprite LoadAnimFirstSprite(uint animID)
    {
        var animDatas = s_SpriteDataLoader.animationDatas;
        var animData = animDatas[animID - GraphicsDefine.ANI_ID_START];
        if (!animData.IsValid())
        {
            return null;
        }
        var animInfo = animData.animationList;
        var frameInfos = animInfo[0].frameList;
        var mappingInfo = SpriteMappingInfo.Create(animData.fileIndex, frameInfos[0].spriteID + m_TempIndex);
        var spriteData = GetAnimSpriteData(mappingInfo);
        m_TempIndex++;
        return GetSprite(spriteData);
    }

    public static void LoadAnimAllSprite(uint animID)
    {
        var animDatas = s_SpriteDataLoader.animationDatas;
        var animData = animDatas[animID - GraphicsDefine.ANI_ID_START];
        if (!animData.IsValid())
        {
            return;
        }
        var animList = animData.animationList;
        for (int j = 0; j < animList.Length; j++)
        {
            var frameInfos = animList[j].frameList;
            for (int i = 0; i < frameInfos.Length; i++)
            {
                var mappingInfo = SpriteMappingInfo.Create(animData.fileIndex, frameInfos[i].spriteID);
                var spriteData = GetAnimSpriteData(mappingInfo);
                GetSprite(spriteData);
            }
        }
    }

    private static AnimationInfo[,] m_AnimationInfos = new AnimationInfo[8, 13];

    private static void LoadAnimSprite(AnimationData animData, int type, uint animID)
    {
        if (!animData.IsValid())
        {
            return;
        }
        //var animList = animData.animationList;
        //int typeCount = animList.Length / 8;
        int spriteCount = 0;
        //for (int j = 0; j < animList.Length; j += typeCount)
        //{
        //    var frameInfos = animList[j].frameList;
        //    for (int i = 0; i < frameInfos.Length; i++)
        //    {
        //        var mappingInfo = SpriteMappingInfo.Create(animData.fileIndex, frameInfos[i].spriteID);
        //        //UnityEngine.Debug.LogError("图片号：" + frameInfos[i].spriteID);
        //        var spriteData = GetAnimSpriteData(mappingInfo);
        //        Sprite sp = GetSprite(spriteData);
        //        if (sp != null)
        //        {
        //            spriteCount++;
        //        }
        //    }
        //}

        for (int i = 0; i < animData.animationCount; i++)
        {
            var aniInfo = animData.animationList[i];
            if (aniInfo.header.type >= 13)
            {
                continue;
            }
            m_AnimationInfos[aniInfo.header.direction, aniInfo.header.type] = aniInfo;
        }

        for (int i = 0; i < 8; i++)
        {
            var framInfos = m_AnimationInfos[i, type].frameList;
            //UnityEngine.Debug.LogError("动作：" + type + "帧数：" + framInfos.Length);
            for (int j = 0; j < framInfos.Length; j++)
            {
                var mappingInfo = SpriteMappingInfo.Create(animData.fileIndex, framInfos[j].spriteID);
                //UnityEngine.Debug.LogError("动作：" + i + "图片号：" + framInfos[j].spriteID);
                var spriteData = GetAnimSpriteData(mappingInfo);
                Sprite sp = GetSprite(spriteData);
                if (sp != null)
                {
                    spriteCount++;
                }
            }
        }

        //UnityEngine.Debug.LogError("动画号：" + animID + "图片数：" + spriteCount);
    }

    public static Sprite GetSprite(SpriteData spriteData)
    {
        uint key = spriteData.mappingInfo.ToUInt32();
        s_AnimationSpriteCache.TryGetValue(key, out Sprite sprite);
        if (sprite == null)
        {
            sprite = s_SpriteDataLoader.GetSprite(spriteData, s_CurrentPalette);
            if (sprite != null)
            {
                s_AnimationSpriteCache[key] = sprite;
            }
        }
        return sprite;
    }

    public static SpriteData GetAnimSpriteData(SpriteMappingInfo mappingInfo)
    {
        return s_SpriteDataLoader.animSpriteDataDict[mappingInfo.fileIndex][mappingInfo.spriteID];
    }

    private static void CleanSpriteDictionary(ref Dictionary<uint, Sprite> dict)
    {
        if (dict == null)
            return;
        var e = dict.Values.GetEnumerator();
        while (e.MoveNext())
        {
            var sprite = e.Current;
            if (sprite != null)
            {
                Object.Destroy(sprite.texture);
                Object.Destroy(sprite);
                sprite = null;
            }
        }
        dict.Clear();
    }

    public static void Clean()
    {
        s_PreloadAction?.Dispose();
        s_PreloadAction = null;
        CleanSpriteDictionary(ref s_AnimationSpriteCache);
    }

    public static void Dispose()
    {
        Clean();
        s_SpriteDataLoader?.Dispose();
    }
}