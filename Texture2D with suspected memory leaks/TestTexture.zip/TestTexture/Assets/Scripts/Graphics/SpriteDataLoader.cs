﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using Unity.Collections;
using UnityEngine;
using Object = UnityEngine.Object;

public class SpriteDataLoader : IDisposable
{
    /// <summary>
    /// 1024KB的解码缓冲区
    /// </summary>
    private const int DECODE_BUFFER_CAPCITY = 1048576;

    /// <summary>
    /// 512*512的图片颜色缓冲区
    /// </summary>
    private const int COLOR_BUFFER_CAPCITY = 262144;

    /// <summary>
    /// SpriteAddrInfo在bin文件中的所占数据大小
    /// </summary>
    private int SPRITEADDRINFO_DATA_SIZE = 81;

    public bool isLoaded { get; private set; }

    /// <summary>
    /// 静态图片和动画图片分开索引
    /// </summary>
    public Dictionary<int, SpriteData[]> pictSpriteDataDict { get; } = new Dictionary<int, SpriteData[]>();

    public Dictionary<int, SpriteData[]> animSpriteDataDict { get; } = new Dictionary<int, SpriteData[]>();

    public AnimationData[] animationDatas { get; } = new AnimationData[GraphicsDefine.MAX_ANI_COUNT];

    private SpriteMappingInfo[] m_MapSpriteTable = new SpriteMappingInfo[GraphicsDefine.MAX_MAPPED_SPRITE_COUNT];

    private Color32[] m_ColorBuffer;

    private string m_FileSearchPattern;

    private string m_AdrnBinFileName, m_SprBinFileName, m_RealBinFileName, m_SprAdrnBinFileName;

    private List<string> m_RealBinFileList = new List<string>();

    private IntPtr m_SpriteAddrInfoPtr, m_AnimationAddrInfoPtr, m_AnimationHeaderPtr, m_FrameInfoPtr;

    private byte[] m_SpriteAddrInfoBuffer, m_SpriteAddrEffectiveInfoBuffer, m_AnimationAddrInfoBuffer, m_AnimationHeaderBuffer, m_FrameInfoBuffer;

    private int m_SpriteAddrInfoBufferSize, m_AnimationAddrInfoBufferSize, m_AnimationHeaderBufferSize, m_FrameInfoBufferSize;

    private Stream[] m_RealBinFileStreamArr;

    private SimpleBuffer m_SpriteDecodeBuffer;

    public SpriteDataLoader()
    {
        if (!GlobalDefine.newMethod)
        {
            SPRITEADDRINFO_DATA_SIZE = 80;
        }
        else
        {
            SPRITEADDRINFO_DATA_SIZE = 81;
        }
        m_FileSearchPattern = $"*{GlobalDefine.BIN_FILE_EXT}";
#if !IOS_APP_STORE
        m_AdrnBinFileName = $"adrn{GlobalDefine.BIN_FILE_EXT}";
        m_RealBinFileName = $"real{GlobalDefine.BIN_FILE_EXT}";
        m_SprBinFileName = $"spr{GlobalDefine.BIN_FILE_EXT}";
        m_SprAdrnBinFileName = $"spradrn{GlobalDefine.BIN_FILE_EXT}";
#else
        m_AdrnBinFileName = $"a{GlobalDefine.BIN_FILE_EXT}";
        m_RealBinFileName = $"r{GlobalDefine.BIN_FILE_EXT}";
        m_SprBinFileName = $"s{GlobalDefine.BIN_FILE_EXT}";
        m_SprAdrnBinFileName = $"sa{GlobalDefine.BIN_FILE_EXT}";
#endif
        m_ColorBuffer = new Color32[COLOR_BUFFER_CAPCITY];
        m_SpriteDecodeBuffer = new SimpleBuffer(DECODE_BUFFER_CAPCITY);
        m_SpriteAddrInfoBufferSize = ConvertUtils.SizeOf<SpriteAddrInfo>();//80
        if (!GlobalDefine.newMethod)
        {
            m_SpriteAddrInfoBufferSize -= 4;
        }
        m_SpriteAddrInfoBuffer = new byte[SPRITEADDRINFO_DATA_SIZE];
        m_SpriteAddrEffectiveInfoBuffer = new byte[m_SpriteAddrInfoBufferSize];//40 SpirteAddrInfo有效数据
        m_AnimationAddrInfoBufferSize = ConvertUtils.SizeOf<AnimationAddrInfo>();//12
        m_AnimationAddrInfoBuffer = new byte[m_AnimationAddrInfoBufferSize];
        m_AnimationHeaderBufferSize = ConvertUtils.SizeOf<AnimationHeader>();//12
        m_AnimationHeaderBuffer = new byte[m_AnimationHeaderBufferSize];
        m_FrameInfoBufferSize = ConvertUtils.SizeOf<FrameInfo>();//10
        m_FrameInfoBuffer = new byte[m_FrameInfoBufferSize];
    }

    public void Load(string rootPath)
    {
        isLoaded = false;
        m_RealBinFileList.Clear();
        DirectoryInfo dirInfo = new DirectoryInfo(rootPath);
        m_SpriteAddrInfoPtr = Marshal.AllocHGlobal(m_SpriteAddrInfoBufferSize);
        m_AnimationAddrInfoPtr = Marshal.AllocHGlobal(m_AnimationAddrInfoBufferSize);
        m_AnimationHeaderPtr = Marshal.AllocHGlobal(m_AnimationHeaderBufferSize);
        m_FrameInfoPtr = Marshal.AllocHGlobal(m_FrameInfoBufferSize);
        TraversalDirectory(dirInfo);
        Marshal.FreeHGlobal(m_FrameInfoPtr);
        Marshal.FreeHGlobal(m_AnimationHeaderPtr);
        Marshal.FreeHGlobal(m_AnimationAddrInfoPtr);
        Marshal.FreeHGlobal(m_SpriteAddrInfoPtr);
        CleanBuffer();
        m_RealBinFileStreamArr = new FileStream[m_RealBinFileList.Count];
        m_RealBinFileStreamArr[0] = OpenRealBinStream(m_RealBinFileList[0]);
#if DEVELOP
        Debug.Log($"图片资源加载器初始化完毕，补丁数量：{m_RealBinFileList.Count.ToString()}");
#endif
    }

    private FileStream OpenRealBinStream(string realBinPath)
    {
        return new FileStream(realBinPath, FileMode.Open, FileAccess.Read, FileShare.Read);
    }

    /// <summary>
    /// 遍历目录，加载文件
    /// </summary>
    private void TraversalDirectory(DirectoryInfo dirInfo)
    {
        var dirInfos = dirInfo.GetDirectories();
        var fileInfos = dirInfo.GetFiles(m_FileSearchPattern);
        if (fileInfos.Length > 0)
        {
            string adrnBinPath = Path.Combine(dirInfo.FullName, m_AdrnBinFileName);
            string realBinPath = Path.Combine(dirInfo.FullName, m_RealBinFileName);
            string sprBinPath = Path.Combine(dirInfo.FullName, m_SprBinFileName);
            string sprAdrnBinPath = Path.Combine(dirInfo.FullName, m_SprAdrnBinFileName);
            FileInfo adrnFileInfo = new FileInfo(adrnBinPath);
            FileInfo sprBinFileInfo = new FileInfo(sprBinPath);
            FileInfo sprAdrnBinFileInfo = new FileInfo(sprAdrnBinPath);
            bool isAnim = sprBinFileInfo.Exists && sprAdrnBinFileInfo.Exists;
            int realBinFileIndex = -1;
            bool needDecryption = dirInfo.FullName.Contains("EncryptionSAEE");
            if (adrnFileInfo.Exists && File.Exists(realBinPath))
            {
                m_RealBinFileList.Add(realBinPath);
                realBinFileIndex = m_RealBinFileList.Count - 1;
                FileStream adrnBinFs = adrnFileInfo.Open(FileMode.Open, FileAccess.Read, FileShare.Read);
                SpriteAddrInfo sprAddr;
                //防止ID溢出，预留100个数组元素
                int sprAddrInfoCount = (int)(adrnBinFs.Length / SPRITEADDRINFO_DATA_SIZE) + 100;
                if (isAnim)
                {
                    animSpriteDataDict[realBinFileIndex] = new SpriteData[sprAddrInfoCount];
                }
                else
                {
                    pictSpriteDataDict[realBinFileIndex] = new SpriteData[sprAddrInfoCount];
                }
                while (true)
                {
                    int result = adrnBinFs.Read(m_SpriteAddrInfoBuffer, 0, SPRITEADDRINFO_DATA_SIZE);
                    if (result == 0) break;
                    if (needDecryption) GraphicsUtils.DecryptionBin(m_SpriteAddrInfoBuffer);
                    SpriteAddrTakeEffectiveValue(m_SpriteAddrInfoBuffer, m_SpriteAddrEffectiveInfoBuffer);
                    sprAddr = ConvertUtils.BytesToObject<SpriteAddrInfo>(m_SpriteAddrInfoPtr, m_SpriteAddrEffectiveInfoBuffer, m_SpriteAddrInfoBufferSize);
                    var mapID = sprAddr.mapSpriteInfo.bmpID;
                    if (mapID != 0)
                    {
                        if ((mapID >= 12802 && mapID <= 12811) || (mapID >= 10132 && mapID <= 10136))
                        {
                            sprAddr.mapSpriteInfo.hit = (ushort)(300 + (sprAddr.mapSpriteInfo.hit % 100));
                        }
                    }
                    SpriteData spriteData = new SpriteData
                    {
                        addrInfo = sprAddr,
                        mappingInfo = new SpriteMappingInfo
                        {
                            spriteID = sprAddr.bitmapID,
                            fileIndex = realBinFileIndex
                        }
                    };
                    try
                    {
                        if (isAnim)
                        {
                            animSpriteDataDict[realBinFileIndex][sprAddr.bitmapID] = spriteData;
                        }
                        else
                        {
                            pictSpriteDataDict[realBinFileIndex][sprAddr.bitmapID] = spriteData;
                        }
                    }
                    catch
                    {
#if DEVELOP
                        Debug.LogError($"ID：{sprAddr.bitmapID.ToString()}加载失败 文件名：{adrnFileInfo.FullName} 图片数量：{sprAddrInfoCount.ToString()}");
#endif
                    }
                    m_MapSpriteTable[sprAddr.mapSpriteInfo.bmpID] = spriteData.mappingInfo;
                }
                adrnBinFs.Dispose();
            }
            if (isAnim)
            {
                FileStream sprBinFs = sprBinFileInfo.Open(FileMode.Open, FileAccess.Read, FileShare.Read);
                FileStream sprAdrnBinFs = sprAdrnBinFileInfo.Open(FileMode.Open, FileAccess.Read, FileShare.Read);
                AnimationAddrInfo addrInfo;
                AnimationHeader aniHeader;
                FrameInfo fraInfo;
                while (true)
                {
                    int result = sprAdrnBinFs.Read(m_AnimationAddrInfoBuffer, 0, m_AnimationAddrInfoBufferSize);//Length: 4596
                    if (result == 0) break;
                    if (needDecryption) GraphicsUtils.DecryptionBin(m_AnimationAddrInfoBuffer);
                    addrInfo = ConvertUtils.BytesToObject<AnimationAddrInfo>(m_AnimationAddrInfoPtr, m_AnimationAddrInfoBuffer, m_AnimationAddrInfoBufferSize);
                    uint sid = addrInfo.animationID - GraphicsDefine.ANI_ID_START;
                    if (sid >= GraphicsDefine.MAX_ANI_COUNT)
                        break;
                    var aniData = new AnimationData
                    {
                        fileIndex = realBinFileIndex,
                        animationCount = addrInfo.animeCount,
                        animationList = new AnimationInfo[addrInfo.animeCount]
                    };
                    sprBinFs.Seek(addrInfo.offset, SeekOrigin.Begin);
                    for (int i = 0; i < aniData.animationCount; i++)
                    {
                        sprBinFs.Read(m_AnimationHeaderBuffer, 0, m_AnimationHeaderBufferSize);
                        if (needDecryption)
                            GraphicsUtils.DecryptionBin(m_AnimationHeaderBuffer);
                        aniHeader = ConvertUtils.BytesToObject<AnimationHeader>(m_AnimationHeaderPtr, m_AnimationHeaderBuffer, m_AnimationHeaderBufferSize);
                        var aniInfo = new AnimationInfo
                        {
                            header = aniHeader,
                            frameList = new FrameInfo[aniHeader.frameCount]
                        };
                        for (int j = 0; j < aniHeader.frameCount; j++)
                        {
                            sprBinFs.Read(m_FrameInfoBuffer, 0, m_FrameInfoBufferSize);
                            if (needDecryption)
                                GraphicsUtils.DecryptionBin(m_FrameInfoBuffer);
                            fraInfo = ConvertUtils.BytesToObject<FrameInfo>(m_FrameInfoPtr, m_FrameInfoBuffer, m_FrameInfoBufferSize);
                            aniInfo.frameList[j] = fraInfo;
                        }
                        aniData.animationList[i] = aniInfo;
                    }
                    animationDatas[sid] = aniData;
                }
                sprAdrnBinFs.Dispose();
                sprBinFs.Dispose();
            }
        }
        if (dirInfos.Length > 0)
        {
            for (int i = 0; i < dirInfos.Length; i++)
            {
                var di = dirInfos[i];
                TraversalDirectory(di);
            }
        }
    }

    /// <summary>
    /// 获取SpriteAddrInfo用到的数据
    /// </summary>
    /// <param name="sources"></param>
    /// <param name="result"></param>
    private void SpriteAddrTakeEffectiveValue(byte[] sources, byte[] result)
    {
        var sourcesLength = sources.Length;
        for (int i = 0; i < sourcesLength; i++)
        {
            if (i < 36)//前36位有在使用
            {
                result[i] = sources[i];
            }
            else if (i >= 76)//最后五位有在使用
            {
                result[i - 40] = sources[i];
            }
        }
    }

    /// <summary>
    /// 清理读取bin文件的一些字段，初始化以后这些字段没有再使用在这里进行清理
    /// </summary>
    private void CleanBuffer()
    {
        m_FileSearchPattern = m_AdrnBinFileName = m_RealBinFileName = m_SprBinFileName = m_SprAdrnBinFileName = null;
        Array.Clear(m_SpriteAddrInfoBuffer, 0, SPRITEADDRINFO_DATA_SIZE);
        m_SpriteAddrInfoBuffer = null;
        Array.Clear(m_SpriteAddrEffectiveInfoBuffer, 0, m_SpriteAddrInfoBufferSize);
        m_SpriteAddrEffectiveInfoBuffer = null;
        Array.Clear(m_AnimationAddrInfoBuffer, 0, m_AnimationAddrInfoBufferSize);
        m_AnimationAddrInfoBuffer = null;
        Array.Clear(m_AnimationHeaderBuffer, 0, m_AnimationHeaderBufferSize);
        m_AnimationHeaderBuffer = null;
        Array.Clear(m_FrameInfoBuffer, 0, m_FrameInfoBufferSize);
        m_FrameInfoBuffer = null;
    }

    private byte[] m_Buffer = new byte[1024 * 8];

    public byte[] GetBuffer(SpriteData spriteData, out int dataLen, out byte compressFlag)
    {
        compressFlag = 0;
        dataLen = 0;
        if (!spriteData.addrInfo.IsValid())
        {
            return null;
        }
        int fileIndex = spriteData.mappingInfo.fileIndex;
        var fs = m_RealBinFileStreamArr[fileIndex];
        if (fs == null)
        {
            fs = OpenRealBinStream(m_RealBinFileList[fileIndex]);
            m_RealBinFileStreamArr[fileIndex] = fs;
        }
        fs.Seek(spriteData.addrInfo.address, SeekOrigin.Begin);
        if (!GlobalDefine.newMethod)
        {
            if (GraphicsUtils.Decode(fs, ref m_SpriteDecodeBuffer, out compressFlag))
            {
                if (m_SpriteDecodeBuffer.position == 0)
                    return null;
                dataLen = m_SpriteDecodeBuffer.position;
                return m_SpriteDecodeBuffer.GetBuffer();
            }
            return null;
        }
        else
        {
            dataLen = spriteData.addrInfo.size;
            if (m_Buffer.Length < dataLen)
            {
                Array.Resize(ref m_Buffer, m_Buffer.Length * 2);
            }
            fs.Read(m_Buffer, 0, dataLen);
            return m_Buffer;
        }
    }

    /// <summary>
    /// 获取图片的像素颜色信息
    /// </summary>
    /// <param name="spriteData"></param>
    /// <param name="palette"></param>
    /// <returns></returns>
    public Color32[] GetPixels32(SpriteData spriteData, out int colorCount, Palette palette)
    {
        colorCount = 0;
        var dataBuffer = GetBuffer(spriteData, out int dataLen, out byte compressFlag);
        if (dataBuffer != null)
        {
            colorCount = spriteData.addrInfo.width * spriteData.addrInfo.height;
            if (colorCount > m_ColorBuffer.Length)
            {
                GraphicsUtils.ResizeBuffer(ref m_ColorBuffer, colorCount);
#if DEVELOP
                Debug.LogWarning($"重新调整颜色缓冲区大小->{m_ColorBuffer.Length.ToString()}");
#endif
            }
            if (compressFlag < 16)
            {
                var paletteColors = palette.colors;
                for (int i = 0; i < colorCount; i++)
                {
                    m_ColorBuffer[i] = paletteColors[dataBuffer[i]];
                }
                return m_ColorBuffer;
            }
            else
            {
                if (compressFlag == 32)
                {
                    Color32 color = new Color32();
                    for (int i = 0; i < colorCount; i++)
                    {
                        int cur = i * 4;
                        color.b = dataBuffer[cur + 0];
                        color.g = dataBuffer[cur + 1];
                        color.r = dataBuffer[cur + 2];
                        color.a = dataBuffer[cur + 3];
                        m_ColorBuffer[i] = color;
                    }
                }
                else if (compressFlag == 16)
                {
                    Color32 color = new Color32();
                    for (int i = 0; i < colorCount; i += 2)
                    {
                        var colorValue = BitConverter.ToInt16(dataBuffer, i);
                        color.r = (byte)(colorValue & 0xF800);
                        color.g = (byte)(colorValue & 0x07E0);
                        color.b = (byte)(colorValue & 0x001F);
                        color.a = byte.MaxValue;
                        m_ColorBuffer[i] = color;
                    }
                }
            }
        }
        return m_ColorBuffer;
    }

    public Texture2D GetTexture(SpriteData spriteData, Palette palette)
    {
        Texture2D texture = null;
        try
        {
            if (!GlobalDefine.newMethod)
            {
                var colors = GetPixels32(spriteData, out int colorCount, palette);
                if (colorCount == 0)
                    return null;
                int w = spriteData.addrInfo.width;
                int h = spriteData.addrInfo.height;
                texture = new Texture2D(w, h, TextureFormat.ARGB32, false)
                {
                    //解决黑线问题
                    wrapMode = TextureWrapMode.Clamp,
                };
                texture.SetPixels32(0, 0, w, h, colors);
                texture.Apply(false, true);
            }
            else
            {
                byte[] buffer = GetBuffer(spriteData, out int dataLen, out byte compressFlag);
                if (buffer == null)
                {
                    return null;
                }
                int w = spriteData.addrInfo.width;
                int h = spriteData.addrInfo.height;
                if (spriteData.addrInfo.textureFormat == 0)
                {
                    spriteData.addrInfo.textureFormat = 12;
                }
                texture = new Texture2D(w, h, (TextureFormat)spriteData.addrInfo.textureFormat, false);
                using (var nativeArray = new NativeArray<byte>(dataLen, Allocator.Temp, NativeArrayOptions.UninitializedMemory))
                {
                    NativeArray<byte>.Copy(buffer, 0, nativeArray, 0, dataLen);
                    texture.LoadRawTextureData(nativeArray);
                    texture.Apply(false, true);
                }
            }
#if UNITY_EDITOR
            texture.name = spriteData.mappingInfo.ToUInt32().ToString();
#endif
        }
        catch (Exception ex)
        {
            Debug.LogException(ex);
        }
        return texture;
    }

    public Sprite GetSprite(SpriteData spriteData, Palette palette)
    {
        var texture = GetTexture(spriteData, palette);
        if (texture != null)
        {
            return Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), spriteData.addrInfo.GetPivot(), GraphicsDefine.DISTANCE_PIXEL_RATIO, 0, SpriteMeshType.FullRect, Vector4.zero, false);
        }
        return null;
    }

    #region IDisposable Support

    private bool disposedValue = false; // 要检测冗余调用

    protected virtual void Dispose(bool disposing)
    {
        if (!disposedValue)
        {
            if (disposing)
            {
                try
                {
                    for (int i = 0; i < m_RealBinFileStreamArr.Length; i++)
                    {
                        m_RealBinFileStreamArr[i]?.Dispose();
                    }
                }
                catch { }
            }
            disposedValue = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
    }

    #endregion IDisposable Support
}

public struct SpriteData
{
    public SpriteMappingInfo mappingInfo;

    public SpriteAddrInfo addrInfo;
}

/// <summary>
/// 图片映射结构
/// 唯一ID使用一个无符号长整型通过位运算得到
/// 低20位表示spriteID，最大值为1048575
/// 高12位表示fileIndex，最大值为4095
/// </summary>
public struct SpriteMappingInfo
{
    private const int BIT_OFFSET = 20;

    private const int HEX_OFFSET = 0xFFFFF;

    public int fileIndex;

    public uint spriteID;

    public uint ToUInt32()
    {
        return (uint)fileIndex << BIT_OFFSET | spriteID;
    }

    public void FromUInt32(uint value)
    {
        spriteID = value & HEX_OFFSET;
        fileIndex = (int)(value >> BIT_OFFSET & HEX_OFFSET);
    }

    public static SpriteMappingInfo Create(int fIndex, uint sprID)
    {
        return new SpriteMappingInfo
        {
            fileIndex = fIndex,
            spriteID = sprID
        };
    }

    public bool IsValid()
    {
        return spriteID != 0;
    }
}