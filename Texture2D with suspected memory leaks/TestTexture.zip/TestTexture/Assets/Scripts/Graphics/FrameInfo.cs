﻿using System.Runtime.InteropServices;

/// <summary>
/// 一帧动作的具体信息
/// （经测试，该结构体的对齐方式为1byte对齐，C#默认是4byte对齐）
/// </summary>
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct FrameInfo {

    /// <summary>
    /// 图片编号
    /// </summary>
    public uint spriteID;

    /// <summary>
    /// 图片显示时的x偏移量
    /// </summary>
    public short posX;

    /// <summary>
    /// 图片显示时的y偏移量
    /// </summary>
    public short posY;

    /// <summary>
    /// 小于10000代表音效编号
    /// 大于等于10000小于10100代表要显示伤害效果，数字或其他效果
    /// 大于等于10100代表连击
    /// </summary>
    public ushort soundID;

    public SoundIDType GetSoundIDType() {
        if (soundID == 0) {
            return SoundIDType.None;
        }
        else if (soundID < 10000) {
            return SoundIDType.Sound;
        }
        else if (soundID >= 10000 && soundID < 10100) {
            return SoundIDType.DamageEffect;
        }
        else {
            return SoundIDType.ContinueAttack;
        }
    }

}

public enum SoundIDType {
    None,
    Sound,
    DamageEffect,
    ContinueAttack
}
