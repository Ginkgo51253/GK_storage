﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Runtime.InteropServices;
using UnityEngine;

/// <summary>
/// 图形工具类
/// </summary>
public static class GraphicsUtils
{
    private const byte BIT_CMP = 0x80;
    private const byte BIT_ZERO = 0x40;
    private const byte BIT_REP_LARG = 0x10;
    private const byte BIT_REP_LARG2 = 0x20;

    /// <summary>
    /// 512KB大小的缓冲区
    /// </summary>
    private const int DEFAULT_BUFFER_CAPCITY = 524288;

    private static byte[] s_ZlibBuffer;
    private static byte[] s_IntBuffer;
    private static int s_HeaderBufferSize;
    private static byte[] s_InputBuffer;
    private static BMPDataHeader s_Header;

    private static Dictionary<byte, byte> s_Decryption;

    static GraphicsUtils()
    {
        s_InputBuffer = new byte[DEFAULT_BUFFER_CAPCITY];
        s_ZlibBuffer = new byte[DEFAULT_BUFFER_CAPCITY];
        s_HeaderBufferSize = ConvertUtils.SizeOf<BMPDataHeader>();
        s_Header.id = new byte[2];
        s_IntBuffer = new byte[4];
        s_Decryption = new Dictionary<byte, byte>
        {
            { 3, 138 },
            { 18, 33 },
            { 33, 183 },
            { 48, 63 },
            { 63, 123 },
            { 78, 198 },
            { 93, 153 },
            { 108, 78 },
            { 123, 228 },
            { 138, 18 },
            { 153, 93 },
            { 168, 213 },
            { 183, 108 },
            { 198, 3 },
            { 213, 48 },
            { 228, 168 }
        };
    }

    public static void DecryptionBin(byte[] array)
    {
        if (s_Decryption != null)
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] % 15 == 3 && s_Decryption.ContainsKey(array[i]))
                {
                    array[i] = s_Decryption[array[i]];
                }
            }
        }
    }

    public static void ResizeBuffer<T>(ref T[] arr, int newSize)
    {
        if (arr == null)
            return;
        int twiceSize = arr.Length * 2;
        int size = newSize > twiceSize ? newSize : twiceSize;
        Array.Resize(ref arr, size);
    }

    public static bool Decode(Stream input, ref SimpleBuffer outBuffer, out byte compressType)
    {
        outBuffer.Reset();
        input.Read(s_Header.id, 0, 2);
        compressType = s_Header.compressFlag = (byte)input.ReadByte();
        //结构体数据对齐，需要偏移1位
        input.Seek(1, SeekOrigin.Current);
        input.Read(s_IntBuffer, 0, 4);
        s_Header.width = BitConverter.ToInt32(s_IntBuffer, 0);
        input.Read(s_IntBuffer, 0, 4);
        s_Header.height = BitConverter.ToInt32(s_IntBuffer, 0);
        input.Read(s_IntBuffer, 0, 4);
        s_Header.size = BitConverter.ToInt32(s_IntBuffer, 0);
        //B,D
        if (s_Header.id[0] != 82 || s_Header.id[1] != 68)
        {
            return false;
        }
        if (s_Header.compressFlag == 0)
        {
            int len = s_Header.width * s_Header.height;
            byte[] buffer = new byte[len];
            input.Read(buffer, 0, len);
            outBuffer.Write(buffer, 0, len);
            return true;
        }

        try
        {
            int bytesToRead = s_Header.size - s_HeaderBufferSize;
            if (bytesToRead > s_InputBuffer.Length)
            {
                ResizeBuffer(ref s_InputBuffer, bytesToRead);
            }
            input.Read(s_InputBuffer, 0, bytesToRead);
            int len = s_Header.width * s_Header.height * 4;
            //此处检测缓冲区越界情况
            outBuffer.CheckCapcity(len);
            if (compressType >= 16)
            {
                using (var compressStream = new MemoryStream(s_InputBuffer, 2, bytesToRead))
                {
                    using (var decompressStream = new DeflateStream(compressStream, CompressionMode.Decompress))
                    {
                        if (len > s_ZlibBuffer.Length)
                        {
                            ResizeBuffer(ref s_ZlibBuffer, len);
                        }
                        decompressStream.Read(s_ZlibBuffer, 0, len);
                        outBuffer.Write(s_ZlibBuffer, 0, len);
                    }
                }
                return true;
            }
            else
            {
                int indexInput = 0;
                byte idx;
                byte repData;
                int cnt;
                while (indexInput < bytesToRead)
                {
                    idx = s_InputBuffer[indexInput++];
                    if ((idx & BIT_CMP) != 0)
                    {
                        if ((idx & BIT_ZERO) != 0)
                        {
                            repData = 0;
                        }
                        else
                        {
                            repData = s_InputBuffer[indexInput++];
                        }
                        if ((idx & BIT_REP_LARG2) != 0)
                        {
                            cnt = (idx & 0x0f) << 16;
                            cnt |= (s_InputBuffer[indexInput]) << 8;
                            indexInput++;
                            cnt |= s_InputBuffer[indexInput++];
                        }
                        else if ((idx & BIT_REP_LARG) != 0)
                        {
                            cnt = (idx & 0x0f) << 8;
                            cnt |= s_InputBuffer[indexInput++];
                        }
                        else
                        {
                            cnt = (idx & 0x0f);
                        }
                        for (int i = 0; i < cnt; i++)
                        {
                            outBuffer.WriteByte(repData);
                        }
                    }
                    else
                    {
                        if ((idx & BIT_REP_LARG) != 0)
                        {
                            cnt = (idx & 0x0f) << 8;
                            cnt |= s_InputBuffer[indexInput++];
                        }
                        else
                        {
                            cnt = idx & 0x0f;
                        }
                        if (cnt >= 0xfffff)
                        {
                            return false;
                        }
                        for (int i = 0; i < cnt; i++)
                        {
                            outBuffer.WriteByte(s_InputBuffer[indexInput++]);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Debug.LogException(ex);
            return false;
        }
        return true;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct BMPDataHeader
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public byte[] id;

        public byte compressFlag;
        public int width;
        public int height;
        public int size;
    }
}

public class SimpleBuffer
{
    private int m_Position = 0;

    public int position
    {
        get
        {
            return m_Position;
        }
    }

    private byte[] m_Buffer;

    public SimpleBuffer(int capcity)
    {
        m_Buffer = new byte[capcity];
    }

    /// <summary>
    ///为了保证速度，缓冲区的大小需要预先指定，调用频繁的地方不进行越界检查，因此尽可能留的大一些
    ///如果一定要进行越界检查，可以手动调用CheckCapcity方法
    /// </summary>
    /// <param name="b"></param>
    public void WriteByte(byte b)
    {
        m_Buffer[m_Position++] = b;
    }

    public void Write(byte[] data, int index, int len)
    {
        Array.Copy(data, index, m_Buffer, m_Position, len);
        m_Position += len;
    }

    public void CheckCapcity(int newLen)
    {
        int newSize = m_Position + newLen;
        if (newSize > m_Buffer.Length)
        {
            GraphicsUtils.ResizeBuffer(ref m_Buffer, newSize);
#if DEVELOP
            Debug.LogWarning($"重新调整缓冲区大小->{m_Buffer.Length.ToString()}");
#endif
        }
    }

    public void Reset()
    {
        m_Position = 0;
    }

    public byte[] GetBuffer()
    {
        return m_Buffer;
    }

    public byte[] GetData()
    {
        byte[] data = new byte[m_Position];
        Array.Copy(m_Buffer, data, m_Position);
        return data;
    }
}