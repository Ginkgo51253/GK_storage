﻿using UnityEngine;
using System.Runtime.InteropServices;
using UnityEngine.Rendering;
using System.Collections.Generic;
using UnityEditor;
using UniRx;
using System.Collections;
using System;
using System.Threading;

/// <summary>
/// 这一步的操作主要是将退化四边形的数据通过ComputeBuffer传入到材质参数中
/// 并且只将描边粗细暴露给用户
/// 这里只进行了数据传递操作，没有进行顶点、边类型的鉴定
/// </summary>
[ExecuteInEditMode]
[RequireComponent(typeof(SkinnedMeshRenderer))]
public class OutlineManager : MonoBehaviour
{
    [Header("必要参数")]
    [Range(0, 0.01f)]
    public float edgeWidth = 0.01f;               // 描边的粗细
    [Range(0, 0.01f)]
    public float normalOffset = 0.001f;           // 描边延法线位移量
    [Range(-1, 1)]
    public float creaseFilter = 0;                // 折边描绘阈值
    public Color edgeColor;                       // 折边的颜色
    public Material prefab_material;              // 预置材质，用于实例化
    public DegradedRectangles degraded_rectangles;// 退化四边形资源文件

    private Mesh bake_mesh;                       // 用于接收动态网格
    private Material material;                    // 动态网格用到的描边材质，由预置材质实例化生成
    private SkinnedMeshRenderer mesh_renderer;
    private CommandBuffer command_buffer;         // 指令缓存
    private List<Vector3> mesh_vertices;          // 网格顶点，用来接收动态网格的顶点信息
    private MaterialBufferManager buffer_manager; // 材质缓存管理器
    private List<Camera> cameras;                 // 用来清空指令缓存
    private int degraded_rectangles_count = 0;    // 退化四边形的个数
    private bool is_visible = false;// 该动态网格是否可见，利用unity消息控制网格的可见性标识符
    private CameraEvent camera_event = CameraEvent.BeforeForwardAlpha;////CameraEvent.AfterForwardOpaque;

    private IDisposable disposable;//交付给协程计算，用于防止进程卡死
    private Thread thread;

    private void OnEnable()
    {
        if (prefab_material == null)//自动加载描边材质
        {
            UnityEditor.VersionControl.Asset edgeMat = new UnityEditor.VersionControl.Asset("Assets/DependenceBox/MyEdge.mat");
            prefab_material = (Material)edgeMat.Load();//这里获取的是源材质，因为在后面会对原材质进行一次实例化拷贝
        }

        if (prefab_material == null || degraded_rectangles == null)
        {//退化四边形与预制的材质均是必要的
            return;
        }

        ReleaseBuffer();//释放缓存，重新计算
        UpdateDegradedRectangle();
        bake_mesh = new Mesh();
        material = Instantiate(prefab_material);//由预制材质实例化生成
        mesh_renderer = GetComponent<SkinnedMeshRenderer>();
        mesh_vertices = new List<Vector3>();
        command_buffer = new CommandBuffer();
        buffer_manager = new MaterialBufferManager(degraded_rectangles.mesh, degraded_rectangles.degraded_rectangles, material);//用一个自定义类存储和管理缓存
        degraded_rectangles_count = buffer_manager.GetLines().count;//计算退化四边形的个数
        cameras = new List<Camera>();
        Camera.onPreCull += DrawWithCamera;//这个委托挂载后 相当于每帧的相机都会去执行这个委托
        command_buffer.name = "Cartoon Line";// 让描边同时在Scene视图和Game视图显示
    }

    private void DrawWithCamera(Camera camera)
    {
        mesh_renderer.BakeMesh(bake_mesh);//第一步，将新的网格对象存入原本的网格组件
        bake_mesh.GetVertices(mesh_vertices);//第二步，从网格上取出顶点集
        buffer_manager.GetVertices().SetData(mesh_vertices);//第三步，将顶点集送入计算缓存

        if (camera)
        {//如果相机对象存在
            if (!cameras.Contains(camera))
            {
                cameras.Add(camera);//将相机添加至列表中
                camera.AddCommandBuffer(camera_event, command_buffer);//为相机添加指令，位置在渲染不透明对象之后（因为描边对象一定是不透明几何体）
            }

            command_buffer.Clear();//指令缓存清空
            if (is_visible)
            { // 模型可见时才进行描边
                command_buffer.DrawProcedural(
                    transform.localToWorldMatrix,//4维的矩阵可以表示该对象的位移、旋转、缩放变换
                    material, //该指令作用的材质
                    0, //该指令作用的着色器pass，-1代表全部
                    MeshTopology.Points,
                    degraded_rectangles_count
                    );
                //Graphics.ExecuteCommandBuffer(command_buffer);
                material.SetFloat("EdgeWidth", edgeWidth);//将描边宽度输入到材质参数中
                material.SetFloat("NormalOffset", normalOffset);//将描边延法线位移量输入到材质参数中
                material.SetFloat("CreaseFilter", creaseFilter);//将折边阈值输入到材质参数中
                material.SetColor("EdgeColor", edgeColor);//将描边颜色输入到材质参数中
                buffer_manager.SetBuffer();//将参数写入缓存
            }
        }
    }

    private void OnDestroy()
    {
        ReleaseBuffer();
    }

    private void OnDisable()
    {
        ReleaseBuffer();
    }

    /// <summary>
    /// 清空缓存区
    /// </summary>
    private void ReleaseBuffer()
    {
        if (cameras != null)
        {
            for (int i = 0; i < cameras.Count; i++)
            {
                var camera = cameras[i];
                if (camera != null && command_buffer != null)
                {
                    camera.RemoveCommandBuffer(camera_event, command_buffer);//将挂载在相机上的缓冲区移除
                }
            }
        }

        if (command_buffer != null) command_buffer.Release();
        if (buffer_manager != null) buffer_manager.Release();

        buffer_manager = null;
        command_buffer = null;

        Camera.onPreCull -= DrawWithCamera;
    }

    void OnBecameVisible()
    {
        is_visible = true;
    }

    void OnBecameInvisible()
    {
        is_visible = false;
    }

    /// <summary>
    /// 思路是
    /// 在需要进行描边的几何体上挂载这份脚本
    /// 右键点击“生成退化四边形资源”
    /// 然后脚本会去找到对象根
    /// </summary>
    [ContextMenu("生成退化四边形资源")]
    private void GenerateDegradedRectangle()
    {
        Transform root = transform;
        while (root.parent != null)
        {
            root = root.parent;
        }//遍历找到根节点
        string prefabPath = PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(root.gameObject);//预制体根目录
        if (prefabPath == null)
        {
            Debug.LogWarning("本对象不是预制体，计算不会开始！");
            return;
        }
        else if (transform.GetComponent<SkinnedMeshRenderer>() == null)
        {
            Debug.LogWarning("本对象不包含SkinnedMeshRenderer，计算不会开始！");
            return;
        }
        else
        {
            string folderPath = prefabPath.Substring(0, prefabPath.LastIndexOf(root.gameObject.name));//项目根目录文件夹
            if (disposable == null)
            {
                DegradedRectangles degradedRectangles = ScriptableObject.CreateInstance<DegradedRectangles>();
                AssetDatabase.CreateAsset(degradedRectangles, folderPath + transform.GetComponent<SkinnedMeshRenderer>().sharedMesh.name + ".asset");
                degradedRectangles.mesh = transform.GetComponent<SkinnedMeshRenderer>().sharedMesh;
                disposable = Observable.FromCoroutine(() => GenerateDegradedRectangleAsyn(degradedRectangles.GenerateDegradedRectangle)).Subscribe(_ =>
                {
                    degraded_rectangles = degradedRectangles;//协程执行完毕后自动将当前使用的退化四边形更换为新产生的退化四边形
                    degradedRectangles.OutputDegradedRectangle();//将退化四边形数据写入到本地
                });
            }
            else
            {
                Debug.LogWarning("线程已经在执行了 Hash = " + GetHashCode());
            }
        }
    }

    [ContextMenu("刷新退化四边形资源")]
    private void UpdateDegradedRectangle()
    {
        if(degraded_rectangles!=null && (degraded_rectangles.mesh == null || degraded_rectangles.degraded_rectangles.Count == 0))
        {
            degraded_rectangles.InputDegradedRectangle();
        }
    }

    /// <summary>
    /// 计算和生成退化四边形数据
    /// </summary>
    /// <param name="func"></param>
    /// <returns></returns>
    private IEnumerator GenerateDegradedRectangleAsyn(Action func)
    {
        Debug.LogWarning("2秒后开始计算退化四边形数据，计算过程可能会花费数分钟 Hash = " + GetHashCode());
        yield return new WaitForSecondsRealtime(2);
        func.Invoke();
        Debug.LogWarning("退化四边形数据计算完毕！Hash = " + GetHashCode());
        disposable = null;
        yield break;
    }
}

/// <summary>
/// ComputeBuffer比较多，新建一个类来专门进行管理
/// 这一步不是必要的，但确实增强了可读性
/// </summary>
public class MaterialBufferManager
{
    private Material material;

    private ComputeBuffer vertices;
    private ComputeBuffer normals;
    private ComputeBuffer uvs;
    private ComputeBuffer degraded_rectangles;

    public MaterialBufferManager(Mesh mesh, List<DegradedRectangle> degraded_rectangles, Material material)
    {
        //Vector3[] vertices = mesh.vertices;//使用mesh.vertexCount替代实现
        Vector3[] normals = mesh.normals;
        Vector2[] uvs = mesh.uv;

        //将需要写入到着色器的参数申请ComputeBuffer空间
        //三个参数分别代表总参数数量、单个参数占用的空间大小、缓存类型（不过一般用默认）
        this.normals = new ComputeBuffer(normals.Length, 12, ComputeBufferType.Default);// normals中每个元素都是3个4位的float, 所以是3 * 4 = 12
        this.uvs = new ComputeBuffer(uvs.Length, 8, ComputeBufferType.Default);
        this.degraded_rectangles = new ComputeBuffer(degraded_rectangles.Count, Marshal.SizeOf(typeof(DegradedRectangle)), ComputeBufferType.Default);
        this.vertices = new ComputeBuffer(mesh.vertexCount, 12, ComputeBufferType.Default);

        //写入uv、法线、退化四边形数据
        this.uvs.SetData(uvs);
        this.normals.SetData(normals);
        this.degraded_rectangles.SetData(degraded_rectangles);

        // SetBuffer只需一次，后续直接操作ComputeBuffer即可
        this.material = material;
        material.SetBuffer("_Normals", this.normals);
        material.SetBuffer("_Uvs", this.uvs);
        material.SetBuffer("_DegradedRectangles", this.degraded_rectangles);
        material.SetBuffer("_Vertices", this.vertices);
    }

    /// <summary>
    /// 写入到着色器缓存中的参数
    /// </summary>
    public void SetBuffer()
    {
        material.SetBuffer("_Normals", normals);
        material.SetBuffer("_Uvs", uvs);
        material.SetBuffer("_DegradedRectangles", degraded_rectangles);
        material.SetBuffer("_Vertices", vertices);
    }

    ~MaterialBufferManager()
    {
        Release();
    }

    public ComputeBuffer GetVertices()
    {
        return vertices;
    }

    public ComputeBuffer GetNormals()
    {
        return normals;
    }

    public ComputeBuffer GetUvs()
    {
        return uvs;
    }

    public ComputeBuffer GetLines()
    {
        return degraded_rectangles;
    }

    /// <summary>
    /// 清空缓存数据
    /// </summary>
    public void Release()
    {
        if (vertices != null) vertices.Release();
        if (normals != null) normals.Release();
        if (uvs != null) uvs.Release();
        if (degraded_rectangles != null) degraded_rectangles.Release();

        vertices = null;
        normals = null;
        uvs = null;
        degraded_rectangles = null;
    }
}