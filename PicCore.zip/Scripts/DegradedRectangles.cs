﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using UnityEditor;
using UnityEngine;

[CreateAssetMenu(fileName = "DegradedRectanglesData", menuName = "Degraded Rectangles")]
public class DegradedRectangles : ScriptableObject
{
    public Mesh mesh;
    public List<DegradedRectangle> degraded_rectangles;

    /// <summary>
    /// 用于计算和导出退化四边形数据
    /// </summary>
    [ContextMenu("Generate Degraded Rectangle")]
    public void GenerateDegradedRectangle()
    {
        if (mesh == null)
        {
            Debug.LogError("mesh cannot be null");
            return;
        }

        int[] triangles = mesh.triangles;//获取网格上的三角面
        Vector3[] vertices = mesh.vertices;//获取网格上的顶点

        // 遍历Mesh.triangles来找到所有退化四边形，要求无重复
        var custom_lines = new List<MeshLine>();
        int length = triangles.Length / 3;
        for (int i = 0; i < length; i++)
        {
            //Mesh下的三角面使用顶点编号来记录构成面的三个点
            int vertex1_index = triangles[i * 3];
            int vertex2_index = triangles[i * 3 + 1];
            int vertex3_index = triangles[i * 3 + 2];

            AddCustomLine(vertex1_index, vertex2_index, vertex3_index, vertices, custom_lines);//添加三角图元vertex1和vertex2构成的退化四边形（或叫边）
            AddCustomLine(vertex2_index, vertex3_index, vertex1_index, vertices, custom_lines);//添加三角图元vertex2和vertex3构成的退化四边形（或叫边）
            AddCustomLine(vertex3_index, vertex1_index, vertex2_index, vertices, custom_lines);//添加三角图元vertex3和vertex1构成的退化四边形（或叫边）
        }

        //拷贝和存储退化四边形数据
        degraded_rectangles = new List<DegradedRectangle>(custom_lines.Count);
        for (int i = 0; i < custom_lines.Count; i++)
        {
            degraded_rectangles.Add(custom_lines[i].degraded_rectangle);
        }
        Debug.Log("成功生产退化四边形");
    }

    /// <summary>
    /// 导出退化四边形数据到本地文件
    /// 导出文件会在同级目录下
    /// </summary>
    [ContextMenu("Output Data")]
    public void OutputDegradedRectangle()
    {
        string prefabPath = AssetDatabase.GetAssetPath(this);//资源文件根目录
        //string folderPath = prefabPath.Substring(0, prefabPath.LastIndexOf(this.name));//项目根目录文件夹
        string filePath = prefabPath + ".txt";//项目资源文件

        AssetDatabase.TryGetGUIDAndLocalFileIdentifier(mesh, out string guid, out long localid);
        string meshData = guid + " " + localid + "\n";
        File.WriteAllText(filePath, meshData);

        string[] degraded_rectanglesStr = new string[degraded_rectangles.Count];
        for (int i = 0; i < degraded_rectangles.Count; i++)
        {
            degraded_rectanglesStr[i] = "";
            degraded_rectanglesStr[i] += degraded_rectangles[i].vertex1 + " ";
            degraded_rectanglesStr[i] += degraded_rectangles[i].vertex2 + " ";
            degraded_rectanglesStr[i] += degraded_rectangles[i].triangle1_vertex3 + " ";
            degraded_rectanglesStr[i] += degraded_rectangles[i].triangle2_vertex3 + " ";
        }
        File.AppendAllLines(filePath, degraded_rectanglesStr);

        Debug.LogWarning("导出退化四边形数据完成");
    }

    /// <summary>
    /// 导入退化四边形数据到本地文件
    /// 导入文件需要在同级目录下
    /// </summary>
    [ContextMenu("Input Data")]
    public void InputDegradedRectangle()
    {
        string prefabPath = AssetDatabase.GetAssetPath(this);//资源文件根目录
        string filePath = prefabPath + ".txt";//项目资源文件

        string[] strData;
        try
        {
            strData = File.ReadAllLines(filePath);
        }
        catch
        {
            Debug.LogWarning("资源文件找不到");
            return;
        }
        if (degraded_rectangles != null)
        {
            degraded_rectangles.Clear();
        }
        else
        {
            degraded_rectangles = new List<DegradedRectangle>();
        }
        string[] guidAndlocalid = strData[0].Split(' ');
        string guid = guidAndlocalid[0];
        long localid = long.Parse(guidAndlocalid[1]);

        UnityEngine.Object[] theObjects = AssetDatabase.LoadAllAssetsAtPath(AssetDatabase.GUIDToAssetPath(guid));
        foreach (var theObject in theObjects)
        {
            AssetDatabase.TryGetGUIDAndLocalFileIdentifier(theObject, out string theGuid, out long theLocalID);
            if (localid.Equals(theLocalID))
            {
                mesh = (Mesh)theObject;
                break;
            }
        }

        for (int i = 1; i < strData.Length; i++)
        {
            string[] nums = strData[i].Split(' ');
            DegradedRectangle newDR = new DegradedRectangle();
            newDR.vertex1 = int.Parse(nums[0]);
            newDR.vertex2 = int.Parse(nums[1]);
            newDR.triangle1_vertex3 = int.Parse(nums[2]);
            newDR.triangle2_vertex3 = int.Parse(nums[3]);
            degraded_rectangles.Add(newDR);
        }
    }

    private void AddCustomLine(int vertex1Index, int vertex2Index, int vertex3Index, Vector3[] meshVertices, List<MeshLine> customLines)
    {
        Vector3 point1 = meshVertices[vertex1Index];//获取顶点1
        Vector3 point2 = meshVertices[vertex2Index];//获取顶点2
        MeshLine customLine = new MeshLine(point1, point2);//使用顶点构造边
        if (!customLines.Contains(customLine))
        {
            //第一次遍历到该边时
            customLine.degraded_rectangle = new DegradedRectangle();//构建退化四边形
            customLine.degraded_rectangle.vertex1 = vertex1Index;//公共边1的顶点1
            customLine.degraded_rectangle.vertex2 = vertex2Index;//公共边2的顶点2
            customLine.degraded_rectangle.triangle1_vertex3 = vertex3Index;//面1的顶点
            customLine.degraded_rectangle.triangle2_vertex3 = -1;//面2的顶点，先预留，等重复遍历到该边的时候再补
            customLines.Add(customLine);
        }
        else
        {
            //重复遍历到该边，此时的面一定不是之前的面，用于补全面2的顶点
            int i = customLines.IndexOf(customLine);//获取退化四边形
            DegradedRectangle rectangle = customLines[i].degraded_rectangle;
            if (rectangle.triangle2_vertex3 == -1)
            {
                rectangle.triangle2_vertex3 = vertex3Index;//补全面2的顶点
                customLines[i].degraded_rectangle = rectangle;
            }
        }
    }
    private class MeshLine
    {
        public Vector3 point1;
        public Vector3 point2;
        public DegradedRectangle degraded_rectangle;

        public MeshLine(Vector3 point1, Vector3 point2)
        {
            this.point1 = point1;
            this.point2 = point2;
        }

        public static bool operator ==(MeshLine line1, MeshLine line2)
        {
            return line1.Equals(line2);
        }

        public static bool operator !=(MeshLine line1, MeshLine line2)
        {
            return !line1.Equals(line2);
        }

        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            MeshLine line2 = (MeshLine)obj;

            if (point1 == line2.point1 && point2 == line2.point2)
            {
                return true;
            }

            if (point1 == line2.point2 && point2 == line2.point1)
            {
                return true;
            }

            return false;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("point1: {0}\npoint2: {1}\nindex.point1: {2}\nindex.point2: {3}\nindex.face_point1: {4}\nindex.face_point2: {5}", point1, point2, degraded_rectangle.vertex1, degraded_rectangle.vertex2, degraded_rectangle.triangle1_vertex3, degraded_rectangle.triangle2_vertex3);
        }
    }

}

//退化四边形，实例化用于在unity查看内部参数信息
[System.Serializable]
public struct DegradedRectangle
{
    public int vertex1;// 构成边的顶点1的索引
    public int vertex2;// 构成边的顶点2的索引
    public int triangle1_vertex3;// 边所在三角面1的顶点3索引
    public int triangle2_vertex3;// 边所在三角面2的顶点3索引
}