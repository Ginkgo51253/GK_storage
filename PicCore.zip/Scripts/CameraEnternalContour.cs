﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
public class CameraEnternalContour : MonoBehaviour
{
    public Material theMaterial1;
    public Material theMaterial2;
    public CameraRenderChoice cameraRenderChoice = CameraRenderChoice.default_2560x1920;

    private Camera testCamera;
    private DepthTextureMode testCameraDepthTextureMode = DepthTextureMode.DepthNormals;
    private RenderTexture activeTextureCopy;
    private RenderTexture tempTexture1;
    private RenderTexture finRenderTexture;
    private Texture2D thisTex;

    public static readonly int[] width = { 2560, 256, 5120 };//图片长度
    public static readonly int[] height = { 1920, 192, 3840 };//图片宽度
    public static readonly TextureFormat textureFormat = TextureFormat.ARGB32;//24位rgb带alpha通道，即argb32

    private void OnEnable()
    {
        testCamera = GetComponent<Camera>();

        UnityEditor.VersionControl.Asset mat1 = new UnityEditor.VersionControl.Asset("Assets/DependenceBox/MyDepthToArea.mat");
        UnityEditor.VersionControl.Asset mat2 = new UnityEditor.VersionControl.Asset("Assets/DependenceBox/MyExternalContour.mat");
        theMaterial1 = new Material((Material)mat1.Load());
        theMaterial2 = new Material((Material)mat2.Load());

        activeTextureCopy = new RenderTexture(width[(int)cameraRenderChoice], height[(int)cameraRenderChoice], 24);
        tempTexture1 = new RenderTexture(width[(int)cameraRenderChoice], height[(int)cameraRenderChoice], 24);
        finRenderTexture = new RenderTexture(width[(int)cameraRenderChoice], height[(int)cameraRenderChoice], 24);//创建一个RenderTexture对象,即创建画布
        thisTex = new Texture2D(width[(int)cameraRenderChoice], height[(int)cameraRenderChoice], TextureFormat.ARGB32, false);//创建一个Texture2对象，用于保存Render Texture信息
    }

    /// <summary>
    /// 让当前相机绘制深度法线图
    /// </summary>
    [ContextMenu("DepthNormalMode")]
    private void SetCameraRenderDepthAndNormalTexture()
    {
        testCamera.depthTextureMode = DepthTextureMode.DepthNormals;
    }

    /// <summary>
    /// 这个方法可以取出相机当前渲染的画面
    /// 然后做一定的处理再次输出
    /// 这个方法可能可以做一些拓展性的改写
    /// </summary>
    /// <param name="source">数据源</param>
    /// <param name="destination">目标</param>
    private void OnRenderObject()
    {
        if (GetComponent<Camera>().activeTexture != null && theMaterial1 != null && theMaterial2 != null)//防止相机将图像直接渲染到scene视图
        {
            if (testCamera.depthTextureMode != testCameraDepthTextureMode)
            {
                testCamera.depthTextureMode = testCameraDepthTextureMode;
                Debug.LogWarning("相机深度材质模式："+ testCameraDepthTextureMode.ToString());
            }
            Graphics.Blit(testCamera.activeTexture, activeTextureCopy);
            //第一份材质用于生成区域
            Graphics.Blit(activeTextureCopy, tempTexture1, theMaterial1);//testCamera.activeTexture//RenderTexture.active
            theMaterial2.SetTexture("_ExtraTex", tempTexture1);
            //第二份材质用于生成原图和描边
            Graphics.Blit(activeTextureCopy, finRenderTexture, theMaterial2);
            //将原图与两次运算生成的图像输出至常规相机输出
            Graphics.Blit(finRenderTexture, testCamera.activeTexture);
        }
    }

    /// <summary>
    /// 让当前相机临时绘制一张图片（不包含打点处理的原图）
    /// </summary>
    [ContextMenu("DoRender")]
    public void DoRender()
    {
        RenderTexture.active = finRenderTexture;//设置当前激活的RenderTexture的捕获对象为指定画布//renderTexture2//finRenderTexture//testCamera.activeTexture
        thisTex.ReadPixels(new Rect(0, 0, width[(int)cameraRenderChoice], height[(int)cameraRenderChoice]), 0, 0);//从当前激活的视口读取像素
        testCamera.targetTexture = null;//重置截图相机的targetTexture
        RenderTexture.active = null;//关闭RenderTexture的激活状态
        thisTex.Apply();
        WritePNG(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\\", DateTime.Now.ToString("HHmmssffff") + ".png", thisTex);//写入PNG图片
    }

    /// <summary>
    /// 写入PNG图片
    /// </summary>
    /// <param name="pngName"></param>
    /// <param name="pngTex"></param>
    private static void WritePNG(string pathName, string pngName, Texture2D pngTex)
    {
        byte[] bytes = pngTex.EncodeToPNG();//将纹理数据，转换成一个png图片
        File.WriteAllBytes(pathName + pngName, bytes);//写入数据
    }
}
