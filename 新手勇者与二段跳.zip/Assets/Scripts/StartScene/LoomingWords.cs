﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-11-07 14:36:24
 * @LastEditors: Ginkgo银杏
 * @LastEditTime: 2020-11-09 16:24:06
 * @Description: 设置一个令标题字符渐入渐出的特效状态
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\StartScene\LoomingWords.cs
 */
using UnityEngine;
using UnityEngine.UI;

public class LoomingWords : MonoBehaviour
{
    private float x=0;
    public float deltx;
    void Awake()
    {
        deltx=0.02f;
    }
    void FixedUpdate()
    {
        x+=deltx;
        if(x>=2){
            x=0;
        }
        Color color=gameObject.GetComponent<Text>().color;
        color.a=getColor(x);
        gameObject.GetComponent<Text>().color=color;
    }

    private float getColor(float x){
        if(x<1&&x>=0){
            return x/2+0.5f;
        }else if(x>=1&&x<=2){
            return (2-x)/2+0.5f;
        }else{
            return 0.5f;
        }
    }
}
