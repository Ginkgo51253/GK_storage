﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-11-07 14:22:48
 * @LastEditors: Ginkgo银杏
 * @LastEditTime: 2020-11-09 16:24:48
 * @Description: 用于设置一个点击事件，使游戏点击后进入主游戏界面
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\StartScene\SwitchToMainScene.cs
 */

using UnityEngine;
using UnityEngine.SceneManagement;
using DataController;
public class SwitchToMainScene : MonoBehaviour
{
    Data data;
    void Awake()
    {
        data=StaticData.GetInitData();//获取数据控制对象
    }
    void Update()
    {
        if(Input.anyKey){//如果检测到任何输入
            SceneManager.LoadSceneAsync("Main");
            data.init();
        }
    }
}
