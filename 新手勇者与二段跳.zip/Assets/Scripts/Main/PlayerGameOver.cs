﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-11-05 17:05:57
 * @LastEditors: Ginkgo银杏
 * @LastEditTime: 2020-11-09 16:21:50
 * @Description: 用于判断玩家到达边界，设置游戏结束状态，并显示游戏结束信息
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\Main\PlayerGameOver.cs
 */
using UnityEngine;
using DataController;

public class PlayerGameOver : MonoBehaviour
{
    private Data data;//静态对象实体
    void Awake()
    {
        data=StaticData.GetInitData();//获取数据控制对象
    }

    // Update is called once per frame
    void Update()
    {
        if(!data.isgameover){
            if(gameObject.transform.position.x<=-10.5){
                data.isgameover=true;//将游戏进行标识符设置为游戏结束
                data.renewScores();//获取游戏分数列表
                data.insertScore(data.getScoreString());//将本局游戏得分插入到分数列表中
                data.setScores();//将游戏得分写入本地文件                
                GameObject newgameobject=Resources.Load<GameObject>("GameOverMessage");
                //将预制实例化(所有修改操作无法对预制实现，需要将预制实例化才能正常使用)，第二个参数用于指定对象的父对象
                newgameobject=Instantiate(newgameobject,GameObject.Find("/Canvas").transform);
            }
        }
    }
}
