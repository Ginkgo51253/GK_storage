﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-10-27 13:36:10
 * @LastEditTime: 2020-11-09 16:17:05
 * @LastEditors: Ginkgo银杏
 * @Description: 控制玩家进行跳跃操作的脚本（这也是玩家对游戏角色进行控制的唯一方式）
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\Main\PlayerDoubleJump.cs
 */
using UnityEngine;
using DataController;

//表示玩家对象的跳跃状态枚举对象
public enum status{
    ground,air1,air2
}

public class PlayerDoubleJump : MonoBehaviour
{
    public status jumpstatus;//玩家跳跃状态
    [Range(0,40)]
    public float jumpspeed;//玩家跳跃速度，编辑器中设置一个0-30的拖动窗调节速度
    [Range(0,24)]
    public int doublejumpdelay;//玩家二段跳延迟
    private Data data;//静态对象实体
    Animator newanimator;//动画对象
    //函数与数据的初始化
    void Awake()
    {
        //Debug.Log("This is <PlayerDoubleJump>");//脚本调用提示
        jumpstatus=status.ground;//玩家初始跳跃状态为在地面上
        jumpspeed=20;//玩家初始跳跃速度为15
        doublejumpdelay=12;
        //脚本解决方法，设置玩家二段跳间隔事件
        time=0;
        timeactive=false;
        //获取数据控制对象
        data=StaticData.GetInitData();
        //获取对象上的animator组件对象
        newanimator=gameObject.GetComponent<Animator>();
    }
    
    private int time;//用于控制二段跳间隔的计时器
    private bool timeactive;//控制计时器是否启用的参数

    //等待固定刷新的更新与检测
    void FixedUpdate()
    {
        if(!data.isgameover){
            if(timeactive==true){//帧计时器
                time++;
            }
            if(Input.anyKey && jumpstatus==status.ground && timeactive==false)//如果帧计时器未启用且玩家状态为可起跳
            {
                jumpstatus=status.air1;//玩家状态设置为一段跳
                timeactive=true;//启用帧计时器
                setPlayerSpeed(jumpspeed);//设置玩家y轴速度
                newanimator.SetBool("playerjump",true);
            }
            if(Input.anyKey && jumpstatus==status.air1 && time>=doublejumpdelay){//如果帧计时器超过跳跃限制延迟且状态为一段跳
                jumpstatus=status.air2;//玩家状态设置为二段跳
                setPlayerSpeed(jumpspeed);//设置玩家y轴速度
            }
        }
    }

    /**
     * @description: 设置玩家速度（这个方法用于重新设置玩家的y轴速度）
     * @param {float speed:玩家的速度}
     * @return {*}
     */
    private void setPlayerSpeed(float speed){
        Vector3 v3=gameObject.GetComponent<Rigidbody2D>().velocity;
        v3.y=speed;
        gameObject.GetComponent<Rigidbody2D>().velocity=v3;
    }

    /**
     * @description: 找到了可以落脚的位置，重新设置可以跳跃的状态
     * @param {*}
     * @return {*}
     */
    private void isGrounded(){
        time=0;//重置帧计数器
        timeactive=false;//禁用帧计数器
        jumpstatus=status.ground;//玩家状态设置为落地
        newanimator.SetBool("playerjump",false);
    }

    /**
     * @Author: Ginkgo银杏
     * @description: 当玩家对象上的触发器边缘碰撞箱碰撞到对象时，说明玩家到达地面
     * @param {*}
     * @return {*}
     */
    void OnTriggerEnter2D(Collider2D collider)
    {
        isGrounded();
    }

    //用于动画计时的三个参数
    private bool checktime=false;//是否启用动画计时
    private float maxtime=0.5f;//设置修改延迟（为0.5秒）
    private float temptime=0;//计时参数
    /**
     * @Author: Ginkgo银杏
     * @description: 计时对象置于更新函数中，启用时计时，计时结束修改动画参数
     * @param {*}
     * @return {*}
     */
    void Update()
    {
        if(checktime){
            temptime+=Time.deltaTime;
            if(temptime>=maxtime){
                checktime=false;
                newanimator.SetBool("playerattack",false);
                temptime=0;
            }
        }
    }
    /**
     * @Author: Ginkgo银杏
     * @description: 这个函数在敌人对象中被指明调用
     * @param {*}
     * @return {*}
     */
    void playerAttack(){
        newanimator.SetBool("playerattack",true);
        checktime=true;
    }
}
