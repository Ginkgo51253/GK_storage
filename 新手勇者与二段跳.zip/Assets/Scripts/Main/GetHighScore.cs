﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-11-07 10:19:10
 * @LastEditors: Ginkgo银杏
 * @LastEditTime: 2020-11-09 16:20:15
 * @Description: 用于获取和设置游戏时UI左上角显示的游戏最高得分
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\Main\GetHighScore.cs
 */

using UnityEngine;
using UnityEngine.UI;
using DataController;

public class GetHighScore : MonoBehaviour
{
    private Data data;//静态对象实体
    void Awake()
    {
        data=StaticData.GetInitData();//获取数据控制对象
        gameObject.GetComponent<Text>().text="hi score "+data.getHighScore("No1");
    }
}
