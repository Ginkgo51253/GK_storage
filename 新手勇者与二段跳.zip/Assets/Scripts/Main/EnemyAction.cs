﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-11-04 16:44:22
 * @LastEditors: Ginkgo银杏
 * @LastEditTime: 2020-11-09 16:18:38
 * @Description: 设置敌人碰撞到玩家对象状态变为不再启用
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\Main\EnemyAction.cs
 */
using UnityEngine;
using DataController;

public class EnemyAction : MonoBehaviour
{
    private Data data;//静态对象实体
    void Awake()
    {
        data=StaticData.GetInitData();//获取数据控制对象
    }
    /**
     * @Author: Ginkgo银杏
     * @description: 需要敌人以触发器形式的碰撞体来进行实现
     * @param {Collision2D collision:碰撞触发时对方对象}
     * @return {*}
     */
    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.tag == "Player"){
            gameObject.SetActive(false);
            data.addScore(10000);
            collider.SendMessage("playerAttack");
        }
    }
}
