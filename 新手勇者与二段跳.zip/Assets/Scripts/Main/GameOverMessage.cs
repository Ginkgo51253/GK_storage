﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-11-07 11:56:15
 * @LastEditors: Ginkgo银杏
 * @LastEditTime: 2020-11-09 16:22:28
 * @Description: 用于显示游戏结束时的提示信息，同时设置一个点击查看最高分的事件
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\Main\GameOverMessage.cs
 */
using UnityEngine;
using UnityEngine.UI;
using DataController;

public class GameOverMessage : MonoBehaviour
{
    private Data data;
    void Awake()
    {
        data=StaticData.GetInitData();//获取数据控制对象
    }
    void Update()
    {
        if(Input.anyKey){//如果检测到任何输入
            GameObject newgameobject=Resources.Load<GameObject>("HighScoreMessage");
            //将预制实例化(所有修改操作无法对预制实现，需要将预制实例化才能正常使用)，第二个参数用于指定对象的父对象
            newgameobject=Instantiate(newgameobject,GameObject.Find("/Canvas").transform);
            string[] scores=data.getScores();
            string str="HighScore\n";
            int count=0;
            foreach(string temp in scores){
                str+=temp+"\n";
                count++;
            }
            newgameobject.GetComponent<Text>().text=str;
            Destroy(gameObject,0);
        }
    }
}
