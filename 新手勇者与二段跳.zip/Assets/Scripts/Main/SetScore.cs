﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-11-05 16:46:53
 * @LastEditors: Ginkgo银杏
 * @LastEditTime: 2020-11-09 16:22:36
 * @Description: 用于获取数据存储对象中的得分信息并加以显示
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\Main\SetScore.cs
 */
using UnityEngine;
using UnityEngine.UI;
using DataController;

public class SetScore : MonoBehaviour
{
    private Data data;//静态对象实体
    void Awake()
    {
        data=StaticData.GetInitData();//获取数据控制对象
    }
    void FixedUpdate()
    {
        gameObject.GetComponent<Text>().text=data.getScoreString();
    }
}
