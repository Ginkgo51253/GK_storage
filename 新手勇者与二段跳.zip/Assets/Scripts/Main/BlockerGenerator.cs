﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-10-29 10:32:53
 * @LastEditTime: 2020-11-07 10:38:29
 * @LastEditors: Ginkgo银杏
 * @Description: 自动生成和管理阻挡物的脚本
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\BlockerGenerator.cs
 */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DataController;

public class BlockerGenerator : MonoBehaviour
{
    private Data data;//静态对象实体
    private List<BlockObject> blockObjects;//生成绘制链表
    private Hashtable blockPool;//生成对象池哈希表
    void Awake()
    {
        Debug.Log("This is <BlockerGenerator>");//脚本调用提示
        data=StaticData.GetInitData();//获取数据控制对象
        blockPool=new Hashtable();
        blockObjects=new List<BlockObject>();
        speed=0.12f;
        finalspeed=getSpeed(speed);//速度初始化
    }

    void Update()
    {
        if(data.checkwall==true){//地面移动提示需要生成新的阻挡物
            data.checkwall=false;
            if(getRandomBool(0.3f)){//设置生成时有70%概率不会产生阻挡物
                string name="Blocker0"+getRandomNumber(8);
                BlockObject blockObject=getFromHashTable(name);
                initGameObject(blockObject);
                blockObjects.Add(blockObject);
            }
        }
    }

    [Range(0,0.2f)]
    public float speed;
    private float finalspeed;
    void FixedUpdate()
    {
        if(blockObjects.Count>0&&blockObjects[0].getGameObject().transform.position.x<=-15){
            recycleToHashTable(blockObjects[0]);
            blockObjects.RemoveAt(0);
        }
        if(!data.isgameover){
            foreach(BlockObject blockObject in blockObjects){
                Vector3 v3 = blockObject.getGameObject().transform.position;
                v3.x-=finalspeed;
                blockObject.getGameObject().transform.position = v3;
            }
        }
    }

    /**
     * @description: 获取随机选项 
     * @param {int key:输入选项数量}
     * @return {int 随机返回一个选项}
     */
    int getRandomNumber(int max){
        return (int)(Random.value*max)+1;
    }

    /**
     * @description: 根据概率计算概率结果
     * @param {float rate:返回true的概率(rate应当输入在0-1之间，当大于1时恒定返回真，当小于0时恒定返回假)}
     * @return {bool 布尔型概率结果}
     */
    bool getRandomBool(float rate){
        return (Random.value)<rate;
    }

    /**
     * @description:从哈希表中获取对象
     * 如果对象在哈希表中不存在，则从资源列表中提取并创建对象，最后存入到绘制链表中
     * @param {string key:检索哈希表的键}
     * @return {BlockObject 获取到的封装对象}
     */
    private BlockObject getFromHashTable(string key){
        BlockObject tempObject;
        if(!blockPool.ContainsKey(key)){//如果没在哈希表中找到这个键
            tempObject=changeGameObjectToBlockObject(getObjectFromAsset(key));//根据键名称从资源区建立这个对象
        }else{
            List<BlockObject> templist=(List<BlockObject>)blockPool[key];
            if(templist.Count<=0){//如果在哈希表中找到键但值的链表为空
                tempObject=changeGameObjectToBlockObject(getObjectFromAsset(key));//根据键名称从资源区建立这个对象
            }else{//如果在哈希表中找到键且值的链表为非空,则取出第一个元素
                tempObject=templist[0];
                templist.RemoveAt(0);
            }
        }
        return tempObject;
    }

    /**
     * @description: 回收对象到哈希表中
     * 当绘制链表中有对象不存在在视野中时，将其从绘制链表中取出，并尝试存入哈希表中
     * 如果哈希表中不存在这个对象的存储区，创建存储区并存入
     * @param {BlockObject blockObject:一个完整的阻挡物对象}
     * @return {*}
     */
    private void recycleToHashTable(BlockObject blockObject){
        if(!blockPool.ContainsKey(blockObject.getCode())){//如果哈希表中没找到要加入对象的对象池
            List<BlockObject> templist=new List<BlockObject>();
            blockPool.Add(blockObject.getCode(),templist);//为哈希表添加存放这个对象的链表对象池
            ((List<BlockObject>)blockPool[blockObject.getCode()]).Add(blockObject);
        }else{//如果哈希表中找到了要加入对象的对象池
            ((List<BlockObject>)blockPool[blockObject.getCode()]).Add(blockObject);
        }
        GameObject blockerpool = GameObject.Find("BlockerPool");//在对象表中查找BlockerPool对象
        blockObject.getGameObject().transform.parent=blockerpool.transform;
        blockObject.getGameObject().SetActive(false);
    }

    /**
     * @description: 初始化游戏对象
     * @param {BlockObject blockObject:获取到的游戏阻挡物对象}
     * @return {*}
     */
    private void initGameObject(BlockObject blockObject){
        switch(blockObject.getCode()){//根据对象的名称设置初始位置，由于是随机选取几个位置中的一个，因此具体数值需要在代码中体现
            case "Blocker01":
                switch(getRandomNumber(2)){
                    case 1:blockObject.getGameObject().transform.position=new Vector3(9,-0.12f,0);break;
                    case 2:blockObject.getGameObject().transform.position=new Vector3(9,2.418f,0);break;
                }
                data.wallcountdown+=1;
                break;
            case "Blocker02":
                switch(getRandomNumber(2)){
                    case 1:blockObject.getGameObject().transform.position=new Vector3(9,1.16f,0);break;
                    case 2:blockObject.getGameObject().transform.position=new Vector3(9,3.698f,0);break;
                }
                data.wallcountdown+=1;
                break;
            case "Blocker03":
                blockObject.getGameObject().transform.position=new Vector3(9,1.16f,0);
                data.wallcountdown+=2;
                break;
            case "Blocker04":
                switch(getRandomNumber(2)){
                    case 1:blockObject.getGameObject().transform.position=new Vector3(9,-0.12f,0);break;
                    case 2:blockObject.getGameObject().transform.position=new Vector3(9,2.418f,0);break;
                }
                data.wallcountdown+=2;
                break;
            case "Blocker05":
                switch(getRandomNumber(2)){
                    case 1:blockObject.getGameObject().transform.position=new Vector3(9,1.16f,0);break;
                    case 2:blockObject.getGameObject().transform.position=new Vector3(9,5f,0);break;
                }
                data.wallcountdown+=2;
                break;
            case "Blocker06":
                blockObject.getGameObject().transform.position=new Vector3(9,-1.4f,0);
                data.wallcountdown+=1;
                break;
            case "Blocker07":
                blockObject.getGameObject().transform.position=new Vector3(9,1.16f,0);
                data.wallcountdown+=3;
                break;
            case "Blocker08":
                switch(getRandomNumber(2)){
                    case 1:blockObject.getGameObject().transform.position=new Vector3(9,1.16f,0);break;
                    case 2:blockObject.getGameObject().transform.position=new Vector3(9,5f,0);break;
                }
                data.wallcountdown+=4;
                break;
            default:break;//识别到异常名称，不作处理
        }
        blockObject.getGameObject().transform.parent=gameObject.transform;//将父对象设置为当前对象（Blocker）
        blockObject.getGameObject().SetActive(true);
    }

    /**
     * @description: 从资源文件中寻找并获取对象
     * @param {string key:需要找寻的游戏对象对应的哈希键}
     * @return {*}
     */
    private GameObject getObjectFromAsset(string key){//从这里获取的是未经过封装的unity游戏对象
        GameObject newgameobject=Resources.Load<GameObject>(key);
        //将预制实例化(所有修改操作无法对预制实现，需要将预制实例化才能正常使用)，第二个参数用于指定对象的父对象
        newgameobject=Instantiate(newgameobject,gameObject.transform);
        newgameobject.name=key;//重设对象名称，否则在实例化过程中会将名字标注为clone
        return newgameobject;
    }

    /**
     * @description: 将GameObject对象封装为Blockobject
     * @param {GameObject newgameobject:新生成的游戏对象}
     * @return {BlockObject 封装好的游戏对象}
     */
    private BlockObject changeGameObjectToBlockObject(GameObject newgameobject){
        BlockObject newblockobject = new BlockObject(newgameobject.name,newgameobject);
        return newblockobject;
    }

    /**
     * @description: 将速度参数换算为真实应该使用的速度
     * @param {float speed:速度参数，由地面移动定义}
     * @return {float 换算出来的速度}
     */
    private float getSpeed(float speed){
        float temp = 0;
        while(temp<data.getBlockLength()){
            temp+=speed;
        }
        return speed*data.getBlockLength()/temp;
    }
}
