﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-10-28 10:48:35
 * @LastEditTime: 2020-11-09 16:18:10
 * @LastEditors: Ginkgo银杏
 * @Description: 数据保存于控制脚本
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\Main\DataController.cs
 */
//这不是monobehavior，只是个单纯存储数据的对象
namespace DataController{
    public static class StaticData
    {//用于建立单例
        private static Data instance;

        public static Data GetInitData()
        {
            if (instance == null)
            {
                instance = new Data();
            }
            return StaticData.instance;
        }
    }

    public class Data
    {
        /**
         * @Author: Ginkgo银杏
         * @description: 构造函数，用于数值初始化
         * @param {*}
         * @return {*}
         */
        public Data(){
            init();
        }

        public void init(){
            checkwall=false;
            wallcountdown=0;
            checkenemy=false;
            enemycountdown=40;
            blocklength=1.28f;
            score="000000000";
            isgameover=false;
            renewIni();
            if(highscores==null){
                highscores=new string[5];
            }
        }
        public bool checkwall;//用于标记是否应当生成新的阻拦物
        public int wallcountdown;//用于控制阻拦物生成间隔
        public bool checkenemy;//用于标记是否应当生成新的敌人
        public int enemycountdown;//用于控制敌人生成的间隔.
        private float blocklength;//单位块长度
        public void setBlockLength(float blocklength){
            this.blocklength=blocklength;
        }
        public float getBlockLength(){
            return this.blocklength;
        }

        private string score;//游戏记分
        /**
         * @Author: Ginkgo银杏
         * @description: 将int型的游戏得分转换为游戏内显示的string型得分
         * @param {*int score:int型的游戏得分}
         * @return {*string:string型得分}
         */
        public void setScore(int score){
            string temp=score.ToString();
            while(temp.Length<9){
                temp="0"+temp;
            }
            this.score=temp;
        }
        public string getScoreString(){//获取string型游戏得分
            return this.score;
        }
        public int getScoreInt(){//获取int型游戏得分
            return int.Parse(this.score);
        }
        public void addScore(int score){//为游戏得分加分（对int型进行数据处理）
            setScore(getScoreInt()+score);
        }

        public bool isgameover;//游戏结束标识符

        private INIParser ini;//文件操作对象
        public string getHighScore(string no)//获取存储的游戏指定分数
        {
            return ini.ReadValue("HighScore", no, "000000000");
        }
        public void setHighScore(string no,string score){//存储指定游戏分数（这个方法是写入内存，需要调用renew以写入外存）
            ini.WriteValue("HighScore",no,score);
        }
        /**
         * @Author: Ginkgo银杏
         * @description: 刷新ini对象，如果它没有建立就new一个ini，否则将他关闭后再打开
         * @param {*}
         * @return {*}
         */
        public void renewIni(){
            if(ini!=null){
                ini.Close();
                ini.Open("./HighScore.ini");
            }else{
                ini = new INIParser();
                ini.Open("./HighScore.ini");
            }
        }
        private string[] highscores;//用于存储在数据对象中的游戏得分字符串数组
        public void renewScores(){//从外存中读取数据到highscores中
            for(int i=0;i<5;i++){
                highscores[i]=getHighScore("No"+(i+1));
            }
        }
        public string[] getScores(){//获取数据对象中字符串数组
            return highscores;
        }
        public void setScores(){//将数据对象中字符串数组写入到外存中
            for(int i=0;i<5;i++){
                setHighScore("No"+(i+1),highscores[i]);
            }
            renewIni();
        }
        public void insertScore(string newscore){//将新获取的得分数据插入到数据对象的字符串数组中
            string score=newscore;
            string temp;
            for(int i=0;i<5;i++){
                if(int.Parse(highscores[i])<int.Parse(score)){
                    temp=highscores[i];
                    highscores[i]=score;
                    score=temp;
                }
            }
        }
    }
}