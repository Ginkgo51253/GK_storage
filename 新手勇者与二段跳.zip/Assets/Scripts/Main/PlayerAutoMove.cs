﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-10-27 13:10:04
 * @LastEditTime: 2020-11-09 16:20:35
 * @LastEditors: Ginkgo银杏
 * @Description: 玩家在抵达最初x轴位置前会一直自动向右移动
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\Main\PlayerAutoMove.cs
 */
using UnityEngine;
using DataController;

//判断与tag为wall的对象发生碰撞的状态枚举对象
public enum hitwall{
    ishitwall,nothitwall
}

public class PlayerAutoMove : MonoBehaviour
{
    public Vector3 playeroriginposition;//玩家初始位置
    public hitwall hitstatus;//玩家碰撞到tag为wall对象的状态表
    [Range(0,10)]
    public float playerspeed;//玩家移动速度，编辑器中设置一个0-10的拖动窗调节速度
    private Data data;
    //函数与数据的初始化
    void Awake()
    {
        //Debug.Log("This is <PlayerAutoMove>");//脚本调用提示
        //获取当前对象的初始位置（以这个位置为基准来设置玩家移动的最远距离）
        playeroriginposition = gameObject.transform.position;
        //设置玩家的默认移动速度
        playerspeed=4.5f;
        //设置玩家默认的碰撞（wall）状态
        hitstatus=hitwall.nothitwall;
        //脚本解决方法，防止卡住的寄存对象
        playerlastposition = gameObject.transform.position;
        playersecondlastposition=gameObject.transform.position;
        //获取数据控制对象
        data=StaticData.GetInitData();
    }

    //由于是系统控制的玩家运动，因此可以使用fixedupdate来进行绘制
    private Vector3 playerlastposition;//记录的最后一帧位置
    private Vector3 playersecondlastposition;//记录的倒数第二帧位置
    void FixedUpdate()
    {
        if(!data.isgameover){
            Vector3 playercurrentposition=gameObject.transform.position;
            if(hitstatus==hitwall.nothitwall){//状态为未与wall碰撞，则必不会被阻挡
                //根据玩家当前位置状态进行速度赋值
                if(gameObject.transform.position.x<=playeroriginposition.x){
                    setPlayerSpeed(playerspeed);
                }else{
                    setPlayerSpeed(0);
                }
            }
            if(hitstatus==hitwall.ishitwall){//状态为与wall碰撞，则可能会发生阻挡
                if(playerlastposition.x<playercurrentposition.x){//检测寄存帧位置x是否在当前帧位置x的左侧
                    if(gameObject.transform.position.x<=playeroriginposition.x){//如果是，则表示未被阻挡，正常进行速度赋值
                        setPlayerSpeed(playerspeed);
                    }else{
                        setPlayerSpeed(0);
                    }
                }else{//如果不是，则表示被阻挡，速度归零以保证正常受到重力作用下落
                    setPlayerSpeed(0);
                }
            }
            playerlastposition=playersecondlastposition;
            playersecondlastposition=playercurrentposition;
        }
    }

    //设置玩家速度（这个方法用于重新设置玩家的x轴速度）
    private void setPlayerSpeed(float speed){
        Vector3 v3=gameObject.GetComponent<Rigidbody2D>().velocity;
        v3.x=speed;
        gameObject.GetComponent<Rigidbody2D>().velocity=v3;
    }

    //检测进入到碰撞体（wall），可能会发生阻挡
    private void OnCollisionEnter2D(Collision2D collision){
        if(collision.gameObject.tag=="Wall"){
            hitstatus=hitwall.ishitwall;
        }
    }

    //检测进入到碰撞体（wall），可能会发生阻挡
    private void OnCollisionStay2D(Collision2D collision){
        if(collision.gameObject.tag=="Wall"){
            hitstatus=hitwall.ishitwall;
        }
    }

    //检测离开碰撞体（wall），不可能发生阻挡
    private void OnCollisionExit2D(Collision2D collision) {
        if(collision.gameObject.tag=="Wall"){
            hitstatus=hitwall.nothitwall;
        }
    }
}
