﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-11-07 14:06:29
 * @LastEditors: Ginkgo银杏
 * @LastEditTime: 2020-11-09 16:23:01
 * @Description: 设置一个点击回到主页的点击事件
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\Main\SwitchToStartScene.cs
 */

using UnityEngine;
using UnityEngine.SceneManagement;

public class SwitchToStartScene : MonoBehaviour
{
    private bool inputactive;
    void Awake()
    {
        inputactive=false;
    }

    private float maxtime=1f;
    private float temptime=0;
    void Update()
    {
        if(!inputactive){
            temptime+=Time.deltaTime;
            if(temptime>maxtime){
                inputactive=true;
            }
        }
        if(inputactive&&Input.anyKey){//如果检测到任何输入
            SceneManager.LoadSceneAsync("StartScene");
        }
    }
}
