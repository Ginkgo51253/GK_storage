﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-11-03 11:30:43
 * @LastEditTime: 2020-11-07 15:24:55
 * @LastEditors: Ginkgo银杏
 * @Description: 用于生成敌人
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\Main\EnemyGenerator.cs
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DataController;

public class EnemyGenerator : MonoBehaviour
{
    private Data data;//静态对象实体
    private List<BlockObject> blockObjects;//生成绘制链表
    private Hashtable blockPool;//生成对象池哈希表
    void Awake()
    {
        Debug.Log("This is <EnemyGenerator>");//脚本调用提示
        data=StaticData.GetInitData();//获取数据控制对象
        blockPool=new Hashtable();
        blockObjects=new List<BlockObject>();
        speed=0.12f;
        finalspeed=getSpeed(speed);//速度初始化
    }

    void Update()
    {
        if(data.checkenemy==true){//地面移动提示需要生成新的阻挡物
            data.checkenemy=false;
            if(getRandomBool(0.5f)){//设置生成时有50%概率不会产生阻挡物
                string name="Enemy0"+getRandomNumber(3);
                BlockObject blockObject=getFromHashTable(name);
                initGameObject(blockObject);
                blockObjects.Add(blockObject);
            }
        }
    }

    [Range(0,0.2f)]
    public float speed;
    private float finalspeed;
    void FixedUpdate()
    {
        
        if(blockObjects.Count>0&&blockObjects[0].getGameObject().transform.position.x<=-15){
            recycleToHashTable(blockObjects[0]);
            blockObjects.RemoveAt(0);
        }
        if(!data.isgameover){
            foreach(BlockObject blockObject in blockObjects){
                Vector3 v3 = blockObject.getGameObject().transform.position;
                v3.x-=finalspeed;
                blockObject.getGameObject().transform.position = v3;
            }
        }
    }

    /**
     * @description: 获取随机选项 
     * @param {int key:输入选项数量}
     * @return {int 随机返回一个选项}
     */
    int getRandomNumber(int max){
        return (int)(Random.value*max)+1;
    }

    /**
     * @description: 根据概率计算概率结果
     * @param {float rate:返回true的概率(rate应当输入在0-1之间，当大于1时恒定返回真，当小于0时恒定返回假)}
     * @return {bool 布尔型概率结果}
     */
    bool getRandomBool(float rate){
        return (Random.value)<rate;
    }

    /**
     * @description:从哈希表中获取对象
     * 如果对象在哈希表中不存在，则从资源列表中提取并创建对象，最后存入到绘制链表中
     * @param {string key:检索哈希表的键}
     * @return {BlockObject 获取到的封装对象}
     */
    private BlockObject getFromHashTable(string key){
        BlockObject tempObject;
        if(!blockPool.ContainsKey(key)){//如果没在哈希表中找到这个键
            tempObject=changeGameObjectToBlockObject(getObjectFromAsset(key));//根据键名称从资源区建立这个对象
        }else{
            List<BlockObject> templist=(List<BlockObject>)blockPool[key];
            if(templist.Count<=0){//如果在哈希表中找到键但值的链表为空
                tempObject=changeGameObjectToBlockObject(getObjectFromAsset(key));//根据键名称从资源区建立这个对象
            }else{//如果在哈希表中找到键且值的链表为非空,则取出第一个元素
                tempObject=templist[0];
                templist.RemoveAt(0);
            }
        }
        return tempObject;
    }

    /**
     * @description: 回收对象到哈希表中
     * 当绘制链表中有对象不存在在视野中时，将其从绘制链表中取出，并尝试存入哈希表中
     * 如果哈希表中不存在这个对象的存储区，创建存储区并存入
     * @param {BlockObject blockObject:一个完整的阻挡物对象}
     * @return {*}
     */
    private void recycleToHashTable(BlockObject blockObject){
        if(!blockPool.ContainsKey(blockObject.getCode())){//如果哈希表中没找到要加入对象的对象池
            List<BlockObject> templist=new List<BlockObject>();
            blockPool.Add(blockObject.getCode(),templist);//为哈希表添加存放这个对象的链表对象池
            ((List<BlockObject>)blockPool[blockObject.getCode()]).Add(blockObject);
        }else{//如果哈希表中找到了要加入对象的对象池
            ((List<BlockObject>)blockPool[blockObject.getCode()]).Add(blockObject);
        }
        GameObject enemypool = GameObject.Find("EnemyPool");//在对象表中查找BlockerPool对象
        blockObject.getGameObject().transform.parent=enemypool.transform;
        blockObject.getGameObject().SetActive(false);
    }

    /**
     * @description: 初始化游戏对象
     * @param {BlockObject blockObject:获取到的游戏敌人对象}
     * @return {*}
     */
    private void initGameObject(BlockObject blockObject){
        blockObject.getGameObject().transform.position=new Vector3(
            9+data.getBlockLength()/2,getInitHeight()+data.getBlockLength()/2+0.05f,0) ;
        data.enemycountdown=20;
        blockObject.getGameObject().transform.parent=gameObject.transform;//将父对象设置为当前对象（Blocker）
        blockObject.getGameObject().SetActive(true);
    }

    /**
     * @description: 从资源文件中寻找并获取对象
     * @param {string key:需要找寻的游戏对象对应的哈希键}
     * @return {*}
     */
    private GameObject getObjectFromAsset(string key){//从这里获取的是未经过封装的unity游戏对象
        GameObject newgameobject=Resources.Load<GameObject>(key);
        //将预制实例化(所有修改操作无法对预制实现，需要将预制实例化才能正常使用)，第二个参数用于指定对象的父对象
        newgameobject=Instantiate(newgameobject,gameObject.transform);
        newgameobject.name=key;//重设对象名称，否则在实例化过程中会将名字标注为clone
        return newgameobject;
    }

    /**
     * @description: 将GameObject对象封装为Blockobject
     * @param {GameObject newgameobject:新生成的游戏对象}
     * @return {BlockObject 封装好的游戏对象}
     */
    private BlockObject changeGameObjectToBlockObject(GameObject newgameobject){
        BlockObject newblockobject = new BlockObject(newgameobject.name,newgameobject);
        return newblockobject;
    }

    /**
     * @description: 将速度参数换算为真实应该使用的速度
     * @param {float speed:速度参数，由地面移动定义}
     * @return {float 换算出来的速度}
     */
    private float getSpeed(float speed){
        float temp = 0;
        while(temp<data.getBlockLength()){
            temp+=speed;
        }
        return speed*data.getBlockLength()/temp;
    }

    /**
     * @Author: Ginkgo银杏
     * @description: 使用射线在(9.5,6)处寻找可以生成敌人的落脚位置
     * @param {*}
     * @return {float 获取的射线碰撞位置坐标的高度（y轴）}
     */
    private float getInitHeight(){
        RaycastHit2D hit = Physics2D.Raycast(new Vector3(9.5f,6,0), new Vector3(0,-1,0));
        if (hit.collider != null)
        {
            return hit.point.y;
        }else{
            return 0f;
        }
    }
}
