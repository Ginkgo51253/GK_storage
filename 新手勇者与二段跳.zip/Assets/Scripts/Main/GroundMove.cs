﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-10-27 10:23:39
 * @LastEditTime: 2020-11-09 16:20:26
 * @LastEditors: Ginkgo银杏
 * @Description: 控制地面进行动画移动的脚本
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\Main\GroundMove.cs
 */
using UnityEngine;
using DataController;

public class GroundMove : MonoBehaviour
{
    [Range(0,0.2f)]
    public float speed;
    private float offset;
    Data data;//静态对象实体

    private Vector3 originvector3;//用于寄存原始地面位置
    void Awake()
    {
        //Debug.Log("This is <GroundMove>");
        offset=0;//偏移初始化
        speed=0.12f;//速度初始化
        originvector3=gameObject.transform.position;//标记地面原始位置
        data=StaticData.GetInitData();//获取数据控制对象
    }

    void FixedUpdate()
    {
        if(!data.isgameover){
            offset+=speed;//设置地面偏移量
            Vector3 v3 = originvector3;
            v3.x-=offset;
            if(offset>=data.getBlockLength()){//当地面偏移量达到极值（1.28为本demo方框宽度）
                offset=0;
                if(data.wallcountdown<=0){//阻挡物生成逻辑
                    data.checkwall=true;
                }else{
                    data.wallcountdown--;
                }

                if(data.enemycountdown<=0){//敌人生成逻辑
                    data.checkenemy=true;
                }else{
                    data.enemycountdown--;
                }
                data.setScore(data.getScoreInt()+1);
            }
            gameObject.transform.position=v3;
        }
    }
}
