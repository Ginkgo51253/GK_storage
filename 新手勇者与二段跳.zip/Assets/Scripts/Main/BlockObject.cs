﻿/*
 * @Author: Ginkgo银杏
 * @Date: 2020-10-29 13:54:10
 * @LastEditTime: 2020-11-09 16:18:30
 * @LastEditors: Ginkgo银杏
 * @Description: 记录对象类型和对象的封装对象
 * @FilePath: \新手勇者与二段跳\Assets\Scripts\Main\BlockObject.cs
 */
using UnityEngine;

public class BlockObject
{
    private string code;
    private GameObject gameObject;
    public BlockObject(string code,GameObject gameObject){
        this.code=code;
        this.gameObject=gameObject;
    }

    public string getCode(){
        return this.code;
    }

    public GameObject getGameObject(){
        return this.gameObject;
    }
}
