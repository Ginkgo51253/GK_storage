package com.company;

public class Main {

    public static void main(String[] args) {

        //WordRebuild重要测试
        String str1 = "查询学生姓名";
        String str2 = "select 学生姓名 from 学生表";

        MainFunction MF = new MainFunction();
        MF.funSQLConnection("sa", "123456", "localhost:1433", "SQLconnection");
        MF.funMain(str1, str2);
        MF.showAllWords();

        /*
        //SqlCut数据库SQL语句划分
        SqlCut SC=new SqlCut();
        SC.haveKeyWord(str2);
        SC.addList();

        //自然语言分隔
        WordsList WL=new WordsList();
        WL.cutIntoWords(SC.markedWords,str1);

        //SqlConnection连接数据库
        SqlConnection SQL=new SqlConnection();
        //SqlConnection.getConnection();
        SqlConnection.getConnection("sa","123456","localhost:1433","SQLconnection");

        //NotePad记录可替换单词的笔记本
        NotePad NP=new NotePad();
        NP.addNotes(SC.markedWords,SC.whereKeyWord1,SC.fromList,SQL);

        //WordsRebuild语句重构
        WordsRebuild WR=new WordsRebuild();
        WR.mainWordRebuildAll(SC,WL,NP);
        WR.showAllWords();
        */
    }
}
